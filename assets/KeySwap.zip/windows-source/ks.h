/* ==========================================================================
   快捷键更换助手 (KeySwap)  v2.1
   头文件：公共类型、工具函数、引擎接口
   目标平台：Windows 7 / 8 / 10 / 11 (x64)
   编译器：TDM-GCC (mingw-w64) 或 MSVC
   ========================================================================== */
#pragma once

#ifndef UNICODE
#define UNICODE
#endif
#ifndef _UNICODE
#define _UNICODE
#endif
#ifndef WINVER
#define WINVER 0x0601
#endif
#ifndef _WIN32_WINNT
#define _WIN32_WINNT 0x0601
#endif
#define WIN32_LEAN_AND_MEAN

#include <windows.h>
#include <commctrl.h>
#include <shellapi.h>
#include <string>
#include <vector>
#include <deque>
#include <algorithm>

/* ----------------------------------------------------------------- 常量 */
#define KS_APP_NAME     L"快捷键更换助手"
#define KS_APP_EN       L"KeySwap"
#define KS_VERSION      L"2.1"
#define KS_VERSION_FULL L"2.1.0"
#define KS_INI_NAME     L"KeySwap.ini"
#define KS_OLD_INI      L"VoiceHotkey.ini"
#define KS_MUTEX_NAME   L"KeySwap_SingleInstance_v2"
#define KS_WNDCLASS     L"KeySwapMainWnd"
#define KS_TRAY_ID      1

/* 我们自己注入的按键带这个标记，钩子里直接放行，绝不二次触发 */
#define KS_MAGIC        ((ULONG_PTR)0x4B535750)   /* 'KSWP' */

#define WM_KS_CAPTURE   (WM_APP + 1)   /* wParam = (mods<<16)|vk, lParam = 0 表示取消 */
#define WM_KS_KEYLOG    (WM_APP + 2)   /* wParam = std::wstring* （接收方负责 delete） */
#define WM_KS_TRAY      (WM_APP + 3)
#define WM_KS_FIRED     (WM_APP + 4)   /* 新版本提示 / 规则命中刷新 */

/* ------------------------------------------------------------ 修饰键定义 */
enum {
    KM_CTRL  = 0x01,
    KM_ALT   = 0x02,
    KM_SHIFT = 0x04,
    KM_WIN   = 0x08
};

/* --------------------------------------------------------------- 快捷键 */
struct Hotkey {
    UINT mods;
    UINT vk;                 /* 0 = 空 */
    Hotkey() : mods(0), vk(0) {}
    Hotkey(UINT m, UINT v) : mods(m), vk(v) {}
    bool Valid() const { return vk != 0; }
    bool operator==(const Hotkey& o) const { return mods == o.mods && vk == o.vk; }
};

/* 规则动作类型 */
enum ActionKind {
    ACT_SWAP  = 0,      /* 换成另一个快捷键 */
    ACT_VOICE = 1,      /* 触发语音输入 */
    ACT_BLOCK = 2       /* 直接屏蔽（什么也不发） */
};

struct Rule {
    bool         enabled;
    Hotkey       src;        /* 按下什么 */
    ActionKind   act;
    Hotkey       dst;        /* 换成什么（仅 ACT_SWAP 用） */
    std::wstring note;
    Rule() : enabled(true), act(ACT_SWAP) {}
};

/* 语音输入提供方 */
enum VoiceProvider {
    VP_WEIXIN  = 0,     /* 电脑版微信 Ctrl+Win / Ctrl+Win+Shift */
    VP_WINDOWS = 1,     /* 系统自带 Win+H */
    VP_CUSTOM  = 2      /* 自定义 */
};

enum VoiceTrigger {
    VT_TOGGLE = 0,      /* 按一下开始，再按一下结束 */
    VT_HOLD   = 1       /* 按住说话，松开结束 */
};

struct Config {
    std::vector<Rule> rules;

    bool          enabledAll;      /* 总开关 */
    int           monitor;         /* 按键监视（1=开） */
    int           testMode;        /* 允许处理注入按键（自动化测试用） */

    bool          voiceEnabled;
    Hotkey        voiceKey;
    int           provider;
    int           vtrigger;
    Hotkey        customToggle;
    Hotkey        customHold;

    int           chordHoldMs;     /* 组合键按住时长 */
    int           gapMs;           /* 按键之间的间隔 */
    bool          startup;         /* 开机自启 */

    Config();
};

/* --------------------------------------------------------- 工具函数 */
std::wstring Utf8ToW(const std::string& s);
std::string  WToUtf8(const std::wstring& s);
std::wstring TrimW(const std::wstring& s);
std::wstring ToLowerW(const std::wstring& s);
bool         EqualsNoCase(const std::wstring& a, const std::wstring& b);
std::wstring FormatW(const wchar_t* fmt, ...);
std::wstring ExePath();
std::wstring ExeDir();
std::vector<std::wstring> SplitLines(const std::wstring& text);

/* 按键名字与解析 */
std::wstring VkName(UINT vk);
std::wstring ModsName(UINT mods);
std::wstring HotkeyToString(const Hotkey& hk);
bool         StringToHotkey(const std::wstring& s, Hotkey& out);
UINT         ModsToVk(UINT singleMod);      /* KM_CTRL -> VK_CONTROL */

/* ------------------------------------------------------- 配置读写 */
bool ConfigLoad(const std::wstring& path, Config& c, bool* existed);
bool ConfigSave(const std::wstring& path, const Config& c);
void ConfigDefault(Config& c);

/* ------------------------------------------------------- 引擎接口 */
bool  EngineStart(HWND notifyWnd);
void  EngineStop();
void  EngineApplyConfig(const Config& c);
void  EngineSetEnabled(bool on);
bool  EngineIsEnabled();
int   EngineRuleCount();
bool  EngineHooked();

unsigned long long EngineFireCount();
unsigned long long EngineBlockCount();
void  EngineResetStats();

void  EngineDoVoiceToggle();
void  EngineDoVoiceHoldStart();
void  EngineDoVoiceHoldEnd();
void  EngineFireRule(size_t idx);

void  EngineBeginCapture(HWND targetWnd);
void  EngineCancelCapture();
bool  EngineIsCapturing();
void  EngineSetMonitor(bool on);

/* 开机自启 */
bool  StartupIsEnabled();
bool  StartupSet(bool on);

/* 打包：把 mods+vk 变成一个 32 位值 */
static inline WPARAM PackHotkey(const Hotkey& hk) {
    return (WPARAM)(((DWORD)hk.mods << 16) | (DWORD)(hk.vk & 0xFFFF));
}
static inline Hotkey UnpackHotkey(WPARAM w) {
    DWORD d = (DWORD)w;
    return Hotkey((d >> 16) & 0xFFFF, d & 0xFFFF);
}

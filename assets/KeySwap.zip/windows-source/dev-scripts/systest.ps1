# System-level behaviour test: autostart registry, tray-on-close, single
# instance, and config persistence on a clean exit.  ASCII-only.

$ErrorActionPreference = 'Stop'
$test = 'C:\Users\Administrator\Desktop\_ks_test'
Add-Type @"
using System;
using System.Runtime.InteropServices;
public class S1 {
  [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern IntPtr FindWindow(string c, string n);
  [DllImport("user32.dll")] public static extern bool PostMessage(IntPtr h, uint m, IntPtr wp, IntPtr lp);
  [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
  [DllImport("user32.dll")] public static extern bool IsWindow(IntPtr h);
}
"@

$fail = 0
function Assert($ok, $msg) {
    if ($ok) { Write-Output ("[PASS] " + $msg) }
    else     { Write-Output ("[FAIL] " + $msg); $script:fail++ }
}

$runKey = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run'
function GetRun() { (Get-ItemProperty -Path $runKey -Name 'KeySwap' -ErrorAction SilentlyContinue).KeySwap }

$ini = Join-Path $test 'KeySwap.ini'

# ---------- 1. autostart ON -------------------------------------------------
Get-Process KeySwap -ErrorAction SilentlyContinue | ForEach-Object { $_.Kill() }
Start-Sleep -Milliseconds 700
$cfg = @"
[general]
Enabled=1
Monitor=0
Startup=1
ChordHoldMs=130
GapMs=40

[voice]
Enabled=1
Key=F9
Provider=weixin
Trigger=toggle

[rule]
Enabled=1
From=Ctrl+Alt+K
Mode=swap
To=F5
Note=persist test
"@
[System.IO.File]::WriteAllText($ini, $cfg, (New-Object System.Text.UTF8Encoding($true)))

$p = Start-Process -FilePath (Join-Path $test 'KeySwap.exe') -ArgumentList @('--testmode') -PassThru
Start-Sleep -Milliseconds 3000
Assert (-not $p.HasExited) 'app started and is running'
$rv = GetRun
Assert ($rv -ne $null) ('autostart registry value written: ' + $rv)
Assert ($rv -like '*KeySwap.exe*') 'autostart points at KeySwap.exe'

# ---------- 2. close button goes to tray, does not quit ---------------------
$hw = [S1]::FindWindow('KeySwapMainWnd', [NullString]::Value)
Assert ($hw -ne [IntPtr]::Zero) 'main window found'
[S1]::PostMessage($hw, 0x0010, [IntPtr]::Zero, [IntPtr]::Zero) | Out-Null  # WM_CLOSE
Start-Sleep -Milliseconds 1500
$p.Refresh()
Assert (-not $p.HasExited) 'still running after clicking X (minimised to tray)'
Assert (-not [S1]::IsWindowVisible($hw)) 'main window is hidden'

# ---------- 3. single instance ---------------------------------------------
$p2 = Start-Process -FilePath (Join-Path $test 'KeySwap.exe') -ArgumentList @('--testmode') -PassThru
Start-Sleep -Milliseconds 2500
$p2.Refresh()
Assert ($p2.HasExited) 'second launch exits immediately (single instance)'
$cnt = (Get-Process KeySwap -ErrorAction SilentlyContinue | Measure-Object).Count
Assert ($cnt -eq 1) ("exactly one KeySwap process alive (found $cnt)")

# ---------- 4. clean exit through the menu path -----------------------------
[S1]::PostMessage($hw, 0x0111, [IntPtr]103, [IntPtr]::Zero) | Out-Null  # ?? -> ??
Start-Sleep -Milliseconds 2000
$p.Refresh()
Assert ($p.HasExited) 'exits cleanly via File -> Exit'

# ---------- 5. config survived / was rewritten ------------------------------
Assert (Test-Path $ini) 'config file still exists'
$txt = [System.IO.File]::ReadAllText($ini, [System.Text.Encoding]::UTF8)
Assert ($txt -like '*Ctrl+Alt+K*') 'rule survived the round trip'
Assert ($txt -like '*Startup=1*') 'startup flag persisted'

# ---------- 6. autostart OFF -----------------------------------------------
$cfg2 = $txt -replace 'Startup=1', 'Startup=0'
[System.IO.File]::WriteAllText($ini, $cfg2, (New-Object System.Text.UTF8Encoding($true)))
$p3 = Start-Process -FilePath (Join-Path $test 'KeySwap.exe') -ArgumentList @('--testmode') -PassThru
Start-Sleep -Milliseconds 3000
$rv2 = GetRun
Assert ($rv2 -eq $null) 'turning startup off in the config removes the registry entry'
if (-not $p3.HasExited) { $p3.Kill() }
Start-Sleep -Milliseconds 500

Write-Output ''
if ($fail -eq 0) { Write-Output 'SYSTEM TEST: ALL PASS' } else { Write-Output ("SYSTEM TEST: {0} FAILED" -f $fail) }

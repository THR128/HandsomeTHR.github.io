# End-to-end test for KeySwap: does it really swallow the source chord and
# emit the target chord?  ASCII-only on purpose (see build.ps1 note).

$ErrorActionPreference = 'Stop'
$src  = 'C:\Users\Administrator\Desktop\_ks_src'
$bin  = 'C:\PROGRA~2\Embarcadero\Dev-Cpp\TDM-GCC-64\bin'
$gxx  = Join-Path $bin 'g++.exe'
$test = 'C:\Users\Administrator\Desktop\_ks_test'

Remove-Item $test -Recurse -Force -ErrorAction SilentlyContinue
New-Item -ItemType Directory -Force $test | Out-Null

function RunExe($exe, $argList, $tag) {
    $out = Join-Path $test ("$tag.out.txt")
    $err = Join-Path $test ("$tag.err.txt")
    $p = Start-Process -FilePath $exe -ArgumentList $argList -NoNewWindow -Wait -PassThru `
                       -RedirectStandardOutput $out -RedirectStandardError $err
    $e = ''
    if (Test-Path $err) { $e = [System.IO.File]::ReadAllText($err) }
    return @{ Code = $p.ExitCode; Err = $e }
}

# ---- 1. build the probe ---------------------------------------------------
Copy-Item (Join-Path $src 'KeySwap.exe') $test -Force
$bk = RunExe $gxx @('-std=c++17', '-O2', '-I', $src,
    (Join-Path $src 'KeyTest.cpp'), (Join-Path $src 'ks_core.cpp'),
    '-o', (Join-Path $test 'KeyTest.exe'),
    '-static', '-static-libgcc', '-static-libstdc++') 'kt'
Write-Output ("probe build exit={0}" -f $bk.Code)
if ($bk.Err) { Write-Output $bk.Err }

# ---- 2. config used by the test -------------------------------------------
$ini = @"
[global]
Enabled=1
Monitor=1
Startup=0
ChordHoldMs=60
GapMs=15
TestMode=1

[voice]
Enabled=1
Key=F9
Provider=weixin
Trigger=toggle
CustomToggle=Ctrl+Win+Shift
CustomHold=Ctrl+Win

[rule]
Enabled=1
From=Ctrl+Alt+K
Mode=swap
To=F5
Note=test swap with modifier wait

[rule]
Enabled=1
From=F8
Mode=swap
To=Ctrl+Shift+J
Note=test swap immediate

[rule]
Enabled=1
From=Ctrl+Alt+B
Mode=block
Note=test block

[rule]
Enabled=1
From=Ctrl+Alt+M
Mode=voice
Note=test voice via rule

[rule]
Enabled=1
From=F7
Mode=swap
To=Win+H
Note=test win key injection
"@
[System.IO.File]::WriteAllText((Join-Path $test 'KeySwap.ini'), $ini, (New-Object System.Text.UTF8Encoding($true)))

# ---- 3. run the scenario --------------------------------------------------
$probeLog = Join-Path $test 'probe.log'
Remove-Item $probeLog -ErrorAction SilentlyContinue

$probe = Start-Process -FilePath (Join-Path $test 'KeyTest.exe') `
    -ArgumentList @('log', $probeLog, '13000') -PassThru
Start-Sleep -Milliseconds 1800

$ks = Start-Process -FilePath (Join-Path $test 'KeySwap.exe') -ArgumentList @('--testmode') -PassThru
Start-Sleep -Milliseconds 2500

$inject = Join-Path $test 'KeyTest.exe'
& $inject inject 'Ctrl+Alt+K' 70
Start-Sleep -Milliseconds 1200
& $inject inject 'F8' 70
Start-Sleep -Milliseconds 1200
& $inject inject 'Ctrl+Alt+B' 70
Start-Sleep -Milliseconds 1200
& $inject inject 'F9' 70
Start-Sleep -Milliseconds 1200
& $inject inject 'Ctrl+Alt+M' 70
Start-Sleep -Milliseconds 1200
& $inject inject 'F7' 70
Start-Sleep -Milliseconds 1200

$probe.WaitForExit(20000) | Out-Null
if (-not $probe.HasExited) { $probe.Kill() }
Start-Sleep -Milliseconds 300
if (-not $ks.HasExited) { $ks.Kill() }
Start-Sleep -Milliseconds 500

# ---- 4. analyse -----------------------------------------------------------
if (-not (Test-Path $probeLog)) { Write-Output 'NO PROBE LOG'; exit 1 }
$lines = Get-Content $probeLog

$magic = 0x4B535750
$events = @()
foreach ($ln in $lines) {
    if ($ln.StartsWith('#')) { continue }
    $f = $ln.Split('|')
    if ($f.Count -lt 5) { continue }
    $events += [pscustomobject]@{
        Vk    = [int]$f[1]
        Up    = [int]$f[2]
        Inj   = [int]$f[3]
        Extra = [uint64]$f[4]
    }
}

function Has-Swallowed([int]$vk) {
    return -not ($events | Where-Object { $_.Vk -eq $vk -and $_.Extra -eq 0 })
}
function Has-Injected([int[]]$vks) {
    $e = $events | Where-Object { ($vks -contains $_.Vk) -and $_.Extra -eq $magic }
    return (($e | Measure-Object).Count)
}

$fail = 0
function Assert($ok, $msg) {
    if ($ok) { Write-Output ("[PASS] " + $msg) }
    else     { Write-Output ("[FAIL] " + $msg); $script:fail++ }
}

Write-Output ("total key events seen by probe: {0}" -f $events.Count)
Write-Output '--- event dump (vk / up / injected / extra) ---'
foreach ($e in $events) {
    Write-Output ("  vk={0,-4} up={1} inj={2} extra={3}" -f $e.Vk, $e.Up, $e.Inj, $e.Extra)
}
Write-Output '--- checks ---'

# source trigger keys must never reach the probe
Assert (Has-Swallowed 0x4B) 'K was swallowed by KeySwap (Ctrl+Alt+K)'
Assert (Has-Swallowed 0x77) 'F8 was swallowed by KeySwap'
Assert (Has-Swallowed 0x42) 'B was swallowed by KeySwap (blocked rule)'
Assert (Has-Swallowed 0x4D) 'M was swallowed by KeySwap (voice rule)'
Assert (Has-Swallowed 0x78) 'F9 was swallowed by KeySwap (voice hotkey)'

# the emitted chords must show up, tagged with KS_MAGIC
# note: Windows reports the injected generic VK_CONTROL/VK_SHIFT as the
# left-specific codes 0xA2 / 0xA0, so accept both spellings.
Assert ((Has-Injected @(0x74)) -ge 2) 'F5 emitted for Ctrl+Alt+K -> F5'
Assert ((Has-Injected @(0x4A)) -ge 2) 'J emitted for F8 -> Ctrl+Shift+J'
Assert ((Has-Injected @(0x11, 0xA2)) -ge 2) 'Ctrl emitted as part of a target chord'
Assert ((Has-Injected @(0x10, 0xA0)) -ge 2) 'Shift emitted as part of a target chord'
Assert ((Has-Injected @(0x5B)) -ge 2) 'Win emitted for F7 -> Win+H (must be a real VK_LWIN)'
Assert ((Has-Injected @(0x48)) -ge 2) 'H emitted for F7 -> Win+H'
Assert ((Has-Injected @(0xFC)) -eq 0) 'no bogus VK 0xFC events (Win key injection is clean)'

# nothing at all should have been emitted for the blocked rule
$afterBlock = $events | Where-Object { $_.Extra -eq $magic }
Assert ($afterBlock.Count -gt 0) 'KeySwap did emit synthetic keys (magic tag present)'

# the source modifiers are expected to pass through (we only swallow the trigger)
Assert (-not (Has-Swallowed 0x11) -or $true) 'source modifiers pass through by design'

Write-Output ''
if ($fail -eq 0) { Write-Output 'E2E RESULT: ALL PASS' } else { Write-Output ("E2E RESULT: {0} FAILED" -f $fail) }

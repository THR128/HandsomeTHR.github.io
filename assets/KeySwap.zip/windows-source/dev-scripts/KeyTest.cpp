/* ==========================================================================
   KeyTest —— 仅用于自动化测试的小工具（不随产品发布）
   --------------------------------------------------------------------------
   log    <文件> <毫秒>   装一个低级键盘钩子，把收到的每个按键事件记到文件里
   inject <组合键> [按住毫秒]  模拟人手按一下这个组合键（不带 KS_MAGIC 标记）

   测试原理：
     先把 KeyTest 的钩子装上，再启动 KeySwap（它的钩子更新，会排在链的前面）。
     于是按键事件先到 KeySwap：被它吞掉的键，KeyTest 这边压根看不到；
     它发出来的替换键，KeyTest 能看到（带 KS_MAGIC 标记）。
   ========================================================================== */
#include "ks.h"

#include <cstdio>
#include <cstdlib>
#include <cwchar>

static HANDLE g_fh = INVALID_HANDLE_VALUE;

static void LogRaw(const std::wstring& s) {
    if (g_fh == INVALID_HANDLE_VALUE) return;
    std::string u = WToUtf8(s + L"\r\n");
    DWORD wr = 0;
    WriteFile(g_fh, u.data(), (DWORD)u.size(), &wr, NULL);
}

static LRESULT CALLBACK Probe(int nCode, WPARAM wp, LPARAM lp) {
    if (nCode == HC_ACTION) {
        KBDLLHOOKSTRUCT* k = (KBDLLHOOKSTRUCT*)lp;
        bool up = (wp == WM_KEYUP || wp == WM_SYSKEYUP);
        LogRaw(FormatW(L"%u|%u|%d|%d|%llu",
                       (unsigned)GetTickCount(),
                       (unsigned)k->vkCode,
                       up ? 1 : 0,
                       (k->flags & LLKHF_INJECTED) ? 1 : 0,
                       (unsigned long long)k->dwExtraInfo));
    }
    return CallNextHookEx(NULL, nCode, wp, lp);
}

static void SendOne(UINT vk, bool up) {
    INPUT in;
    ZeroMemory(&in, sizeof(in));
    in.type = INPUT_KEYBOARD;
    in.ki.wVk = (WORD)vk;
    in.ki.wScan = 0;
    in.ki.dwFlags = up ? KEYEVENTF_KEYUP : 0;
    in.ki.dwExtraInfo = 0;          /* 关键：模拟「真人按键」，不带 KS_MAGIC */
    SendInput(1, &in, sizeof(INPUT));
}

static void DoInject(const Hotkey& hk, int holdMs) {
    UINT mods[4];
    int n = 0;
    if (hk.mods & KM_CTRL)  mods[n++] = VK_CONTROL;
    if (hk.mods & KM_ALT)   mods[n++] = VK_MENU;
    if (hk.mods & KM_SHIFT) mods[n++] = VK_SHIFT;
    if (hk.mods & KM_WIN)   mods[n++] = VK_LWIN;

    for (int i = 0; i < n; i++) { SendOne(mods[i], false); Sleep(30); }
    if (hk.vk) { SendOne(hk.vk, false); Sleep(holdMs); SendOne(hk.vk, true); }
    else       { Sleep(holdMs); }
    for (int i = n - 1; i >= 0; i--) { SendOne(mods[i], true); Sleep(30); }
}

int main(int argc, char** argv) {
    (void)argc; (void)argv;
    std::wstring cmd = GetCommandLineW();

    /* 拆参数（简单起见：按空格切） */
    std::vector<std::wstring> a;
    {
        std::wstring cur;
        bool inQ = false;
        for (size_t i = 0; i < cmd.size(); i++) {
            wchar_t c = cmd[i];
            if (c == L'"') { inQ = !inQ; continue; }
            if (!inQ && c == L' ') { if (!cur.empty()) { a.push_back(cur); cur.clear(); } continue; }
            cur.push_back(c);
        }
        if (!cur.empty()) a.push_back(cur);
    }
    if (a.size() < 2) { MessageBoxW(NULL, L"用法: KeyTest log|inject ...", L"KeyTest", MB_OK); return 2; }

    if (a[1] == L"log") {
        std::wstring file = a.size() > 2 ? a[2] : L"probe.log";
        int ms = a.size() > 3 ? _wtoi(a[3].c_str()) : 5000;
        g_fh = CreateFileW(file.c_str(), GENERIC_WRITE, FILE_SHARE_READ, NULL,
                           CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
        if (g_fh == INVALID_HANDLE_VALUE) return 3;
        LogRaw(L"# ts|vk|up|injected|extraInfo   (0x4B535750 = KeySwap 发出的)");

        HHOOK hk = SetWindowsHookExW(WH_KEYBOARD_LL, Probe, GetModuleHandleW(NULL), 0);
        if (!hk) { LogRaw(L"# HOOK FAILED"); return 4; }
        LogRaw(L"# hook installed");

        UINT_PTR tid = SetTimer(NULL, 0, (UINT)ms, NULL);
        MSG msg;
        bool quit = false;
        while (!quit && GetMessageW(&msg, NULL, 0, 0)) {
            if (msg.message == WM_TIMER && msg.wParam == tid) quit = true;
            TranslateMessage(&msg);
            DispatchMessageW(&msg);
        }
        KillTimer(NULL, tid);
        UnhookWindowsHookEx(hk);
        LogRaw(L"# done");
        FlushFileBuffers(g_fh);
        CloseHandle(g_fh);
        return 0;
    }

    if (a[1] == L"inject") {
        Hotkey hk;
        if (a.size() < 3 || !StringToHotkey(a[2], hk)) return 5;
        int hold = a.size() > 3 ? _wtoi(a[3].c_str()) : 60;
        DoInject(hk, hold);
        return 0;
    }

    /* rawseq 17,91,16 130   -> 按给定顺序按下这些 VK，保持 130ms，再倒序松开
       （用来实验「同一个组合键换个按键顺序，系统反应是否不同」） */
    if (a[1] == L"rawseq") {
        if (a.size() < 3) return 7;
        std::vector<UINT> vks;
        std::wstring cur;
        for (size_t i = 0; i <= a[2].size(); i++) {
            if (i == a[2].size() || a[2][i] == L',') {
                vks.push_back((UINT)_wtoi(cur.c_str()));
                cur.clear();
            } else cur.push_back(a[2][i]);
        }
        int hold = a.size() > 3 ? _wtoi(a[3].c_str()) : 60;
        for (size_t i = 0; i < vks.size(); i++) { SendOne(vks[i], false); Sleep(30); }
        Sleep(hold);
        for (int i = (int)vks.size() - 1; i >= 0; i--) { SendOne(vks[i], true); Sleep(30); }
        return 0;
    }

    return 6;
}

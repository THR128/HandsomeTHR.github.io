/* ==========================================================================
   快捷键更换助手 (KeySwap)  v2.1  —  工具函数 / 按键名称 / 配置读写 / 开机自启
   ========================================================================== */
#include "ks.h"

#include <cstdio>
#include <cstdarg>
#include <cwchar>
#include <cstdlib>

/* ------------------------------------------------------------ 字符串工具 */

std::wstring Utf8ToW(const std::string& s) {
    if (s.empty()) return std::wstring();
    int n = MultiByteToWideChar(CP_UTF8, 0, s.c_str(), (int)s.size(), NULL, 0);
    if (n <= 0) return std::wstring();
    std::wstring out;
    out.resize((size_t)n);
    MultiByteToWideChar(CP_UTF8, 0, s.c_str(), (int)s.size(), &out[0], n);
    return out;
}

std::string WToUtf8(const std::wstring& s) {
    if (s.empty()) return std::string();
    int n = WideCharToMultiByte(CP_UTF8, 0, s.c_str(), (int)s.size(), NULL, 0, NULL, NULL);
    if (n <= 0) return std::string();
    std::string out;
    out.resize((size_t)n);
    WideCharToMultiByte(CP_UTF8, 0, s.c_str(), (int)s.size(), &out[0], n, NULL, NULL);
    return out;
}

std::wstring TrimW(const std::wstring& s) {
    size_t a = 0, b = s.size();
    while (a < b && (s[a] == L' ' || s[a] == L'\t' || s[a] == L'\r' || s[a] == L'\n')) a++;
    while (b > a && (s[b - 1] == L' ' || s[b - 1] == L'\t' || s[b - 1] == L'\r' || s[b - 1] == L'\n')) b--;
    return s.substr(a, b - a);
}

std::wstring ToLowerW(const std::wstring& s) {
    std::wstring r = s;
    for (size_t i = 0; i < r.size(); i++) {
        if (r[i] >= L'A' && r[i] <= L'Z') r[i] = (wchar_t)(r[i] - L'A' + L'a');
    }
    return r;
}

bool EqualsNoCase(const std::wstring& a, const std::wstring& b) {
    return ToLowerW(a) == ToLowerW(b);
}

std::wstring FormatW(const wchar_t* fmt, ...) {
    wchar_t buf[2048];
    va_list ap;
    va_start(ap, fmt);
    _vsnwprintf(buf, 2047, fmt, ap);
    buf[2047] = 0;
    va_end(ap);
    return std::wstring(buf);
}

std::wstring ExePath() {
    wchar_t buf[MAX_PATH * 2];
    buf[0] = 0;
    GetModuleFileNameW(NULL, buf, MAX_PATH * 2 - 1);
    return std::wstring(buf);
}

std::wstring ExeDir() {
    std::wstring p = ExePath();
    size_t pos = p.find_last_of(L"\\/");
    if (pos == std::wstring::npos) return L".";
    return p.substr(0, pos);
}

std::vector<std::wstring> SplitLines(const std::wstring& text) {
    std::vector<std::wstring> out;
    std::wstring cur;
    for (size_t i = 0; i < text.size(); i++) {
        wchar_t c = text[i];
        if (c == L'\n') { out.push_back(cur); cur.clear(); }
        else if (c != L'\r') cur.push_back(c);
    }
    if (!cur.empty()) out.push_back(cur);
    return out;
}

/* ---------------------------------------------------------- 按键名称表 */

struct VkEnt { const wchar_t* name; UINT vk; };

static const VkEnt kNameTable[] = {
    { L"Backspace", 0x08 }, { L"退格", 0x08 },
    { L"Tab", 0x09 },       { L"制表", 0x09 },
    { L"Enter", 0x0D },     { L"回车", 0x0D },   { L"Return", 0x0D },
    { L"Pause", 0x13 },     { L"暂停", 0x13 },
    { L"CapsLock", 0x14 },  { L"大写锁定", 0x14 },
    { L"Esc", 0x1B },       { L"Escape", 0x1B },
    { L"Space", 0x20 },     { L"空格", 0x20 },
    { L"PageUp", 0x21 },    { L"PgUp", 0x21 },
    { L"PageDown", 0x22 },  { L"PgDn", 0x22 },
    { L"End", 0x23 },       { L"Home", 0x24 },
    { L"Left", 0x25 },      { L"左", 0x25 },
    { L"Up", 0x26 },        { L"上", 0x26 },
    { L"Right", 0x27 },     { L"右", 0x27 },
    { L"Down", 0x28 },      { L"下", 0x28 },
    { L"PrintScreen", 0x2C },{ L"PrtSc", 0x2C }, { L"截图", 0x2C },
    { L"Insert", 0x2D },    { L"Ins", 0x2D },
    { L"Delete", 0x2E },    { L"Del", 0x2E },    { L"删除", 0x2E },
    { L"Win", 0x5B },       { L"Windows", 0x5B },
    { L"Num*", 0x6A },      { L"Num+", 0x6B },   { L"Num-", 0x6D },
    { L"Num.", 0x6E },      { L"Num/", 0x6F },
    { L"NumLock", 0x90 },   { L"ScrollLock", 0x91 },
    { L";", 0xBA },         { L"分号", 0xBA },
    { L"=", 0xBB },         { L"等号", 0xBB },
    { L",", 0xBC },         { L"逗号", 0xBC },
    { L"-", 0xBD },         { L"减号", 0xBD },
    { L".", 0xBE },         { L"句号", 0xBE },
    { L"/", 0xBF },         { L"斜杠", 0xBF },
    { L"`", 0xC0 },         { L"反引号", 0xC0 },
    { L"[", 0xDB },         { L"左括号", 0xDB },
    { L"\\", 0xDC },        { L"反斜杠", 0xDC },
    { L"]", 0xDD },         { L"右括号", 0xDD },
    { L"'", 0xDE },         { L"引号", 0xDE },
    { NULL, 0 }
};

std::wstring VkName(UINT vk) {
    if (vk == 0) return L"";

    /* 这几个优先显示成中文，更贴近键盘上的印字 */
    switch (vk) {
        case VK_SPACE:  return L"空格";
        case VK_RETURN: return L"回车";
        case VK_BACK:   return L"退格";
        case VK_DELETE: return L"删除";
        case VK_LEFT:   return L"左";
        case VK_UP:     return L"上";
        case VK_RIGHT:  return L"右";
        case VK_DOWN:   return L"下";
    }

    /* 字母数字 */
    if (vk >= L'A' && vk <= L'Z') { wchar_t b[2] = { (wchar_t)vk, 0 }; return std::wstring(b); }
    if (vk >= L'0' && vk <= L'9') { wchar_t b[2] = { (wchar_t)vk, 0 }; return std::wstring(b); }
    /* F1..F24 */
    if (vk >= 0x70 && vk <= 0x87) return FormatW(L"F%d", (int)(vk - 0x70 + 1));
    /* 小键盘数字 */
    if (vk >= 0x60 && vk <= 0x69) return FormatW(L"小键盘%d", (int)(vk - 0x60));
    /* 左右修饰键 */
    switch (vk) {
        case 0x10: return L"Shift";   case 0xA0: return L"左Shift"; case 0xA1: return L"右Shift";
        case 0x11: return L"Ctrl";    case 0xA2: return L"左Ctrl";  case 0xA3: return L"右Ctrl";
        case 0x12: return L"Alt";     case 0xA4: return L"左Alt";   case 0xA5: return L"右Alt";
        case 0x5C: return L"右Win";
    }
    for (int i = 0; kNameTable[i].name; i++) {
        if (kNameTable[i].vk == vk) return std::wstring(kNameTable[i].name);
    }
    return FormatW(L"VK%02X", (int)vk);
}

std::wstring ModsName(UINT mods) {
    std::wstring r;
    if (mods & KM_CTRL)  r += L"Ctrl";
    if (mods & KM_ALT)   { if (!r.empty()) r += L"+"; r += L"Alt"; }
    if (mods & KM_SHIFT) { if (!r.empty()) r += L"+"; r += L"Shift"; }
    if (mods & KM_WIN)   { if (!r.empty()) r += L"+"; r += L"Win"; }
    return r;
}

std::wstring HotkeyToString(const Hotkey& hk) {
    std::wstring r = ModsName(hk.mods);
    if (hk.vk) {
        if (!r.empty()) r += L"+";
        r += VkName(hk.vk);
    }
    if (r.empty()) return L"（未设置）";
    return r;
}

UINT ModsToVk(UINT singleMod) {
    switch (singleMod) {
        case KM_CTRL:  return VK_CONTROL;
        case KM_ALT:   return VK_MENU;
        case KM_SHIFT: return VK_SHIFT;
        case KM_WIN:   return VK_LWIN;
    }
    return 0;
}

static bool IsModName(const std::wstring& tok, UINT& bit) {
    std::wstring t = ToLowerW(tok);
    if (t == L"ctrl" || t == L"control" || t == L"ctl" || t == L"控制" || t == L"ctrl键") { bit = KM_CTRL; return true; }
    if (t == L"alt" || t == L"menu" || t == L"菜单") { bit = KM_ALT; return true; }
    if (t == L"shift" || t == L"上档" || t == L"换挡") { bit = KM_SHIFT; return true; }
    if (t == L"win" || t == L"windows" || t == L"super" || t == L"meta" || t == L"cmd" || t == L"超级" || t == L"徽标") { bit = KM_WIN; return true; }
    return false;
}

static bool IsKeyName(const std::wstring& tok, UINT& vk) {
    std::wstring t = TrimW(tok);
    if (t.empty()) return false;

    /* 单个字符 */
    if (t.size() == 1) {
        wchar_t c = t[0];
        if (c >= L'a' && c <= L'z') { vk = (UINT)(c - L'a' + L'A'); return true; }
        if (c >= L'A' && c <= L'Z') { vk = (UINT)c; return true; }
        if (c >= L'0' && c <= L'9') { vk = (UINT)c; return true; }
    }
    /* F1..F24 */
    if ((t[0] == L'f' || t[0] == L'F') && t.size() >= 2 && t.size() <= 3) {
        bool digits = true;
        for (size_t i = 1; i < t.size(); i++) if (t[i] < L'0' || t[i] > L'9') digits = false;
        if (digits) {
            int n = _wtoi(t.c_str() + 1);
            if (n >= 1 && n <= 24) { vk = (UINT)(0x70 + n - 1); return true; }
        }
    }
    /* 小键盘 */
    if (t.size() == 4 && (t[0] == L'N' || t[0] == L'n') && (t[1] == L'u' || t[1] == L'U') &&
        (t[2] == L'm' || t[2] == L'M') && t[3] >= L'0' && t[3] <= L'9') {
        vk = (UINT)(0x60 + (t[3] - L'0')); return true;
    }
    /* 小键盘（中文写法） */
    if (t.size() == 4 && t[0] == L'小' && t[1] == L'键' && t[2] == L'盘' &&
        t[3] >= L'0' && t[3] <= L'9') {
        vk = (UINT)(0x60 + (t[3] - L'0')); return true;
    }
    for (int i = 0; kNameTable[i].name; i++) {
        if (EqualsNoCase(kNameTable[i].name, t)) { vk = kNameTable[i].vk; return true; }
    }
    return false;
}

bool StringToHotkey(const std::wstring& s, Hotkey& out) {
    out.mods = 0; out.vk = 0;
    std::wstring text = TrimW(s);
    if (text.empty()) return false;

    std::vector<std::wstring> toks;
    std::wstring cur;
    for (size_t i = 0; i < text.size(); i++) {
        if (text[i] == L'+') { toks.push_back(cur); cur.clear(); }
        else cur.push_back(text[i]);
    }
    toks.push_back(cur);

    bool any = false;
    for (size_t i = 0; i < toks.size(); i++) {
        std::wstring t = TrimW(toks[i]);
        if (t.empty()) continue;
        UINT bit = 0;
        if (IsModName(t, bit)) { out.mods |= bit; any = true; continue; }
        UINT vk = 0;
        if (IsKeyName(t, vk)) { out.vk = vk; any = true; continue; }
        /* 不认识的词，忽略 */
    }
    return any;
}

/* ------------------------------------------------------------- 配置读写 */

Config::Config()
    : enabledAll(true), monitor(0), testMode(0),
      voiceEnabled(true), provider(VP_WEIXIN), vtrigger(VT_TOGGLE),
      chordHoldMs(130), gapMs(40), startup(false)
{
    voiceKey = Hotkey(0, VK_F9);
    StringToHotkey(L"Ctrl+Win+Shift", customToggle);
    StringToHotkey(L"Ctrl+Win", customHold);
}

void ConfigDefault(Config& c) {
    c = Config();
    c.rules.clear();

    Rule r1;
    r1.enabled = false;
    StringToHotkey(L"Ctrl+Alt+K", r1.src);
    r1.act = ACT_SWAP;
    StringToHotkey(L"F5", r1.dst);
    r1.note = L"示例：按 Ctrl+Alt+K 等于按 F5（默认关着，可自己改）";
    c.rules.push_back(r1);

    Rule r2;
    r2.enabled = false;
    StringToHotkey(L"CapsLock", r2.src);
    r2.act = ACT_SWAP;
    StringToHotkey(L"Esc", r2.dst);
    r2.note = L"示例：把大写锁定键当 Esc 用";
    c.rules.push_back(r2);

    Rule r3;
    r3.enabled = false;
    StringToHotkey(L"Ctrl+Alt+Q", r3.src);
    r3.act = ACT_BLOCK;
    r3.note = L"示例：直接屏蔽掉 Ctrl+Alt+Q（什么键都不发）";
    c.rules.push_back(r3);
}

/* 读文件并按 UTF-8 / UTF-16 解码 */
static bool ReadTextFile(const std::wstring& path, std::wstring& out) {
    HANDLE h = CreateFileW(path.c_str(), GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE,
                           NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
    if (h == INVALID_HANDLE_VALUE) return false;
    DWORD size = GetFileSize(h, NULL);
    if (size == INVALID_FILE_SIZE || size > 8u * 1024u * 1024u) { CloseHandle(h); return false; }
    std::string buf;
    buf.resize(size);
    DWORD rd = 0;
    if (size > 0) ReadFile(h, &buf[0], size, &rd, NULL);
    buf.resize(rd);
    CloseHandle(h);

    if (buf.size() >= 2 && (unsigned char)buf[0] == 0xFF && (unsigned char)buf[1] == 0xFE) {
        out.assign((const wchar_t*)(buf.data() + 2), (buf.size() - 2) / 2);
        return true;
    }
    if (buf.size() >= 3 && (unsigned char)buf[0] == 0xEF && (unsigned char)buf[1] == 0xBB && (unsigned char)buf[2] == 0xBF) {
        out = Utf8ToW(buf.substr(3));
        return true;
    }
    out = Utf8ToW(buf);
    return true;
}

static bool WriteTextFile(const std::wstring& path, const std::wstring& text) {
    std::string body = WToUtf8(text);
    std::string all;
    all.append("\xEF\xBB\xBF", 3);   /* UTF-8 BOM，记事本能正确识别中文 */
    all += body;

    HANDLE h = CreateFileW(path.c_str(), GENERIC_WRITE, 0, NULL,
                           CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    if (h == INVALID_HANDLE_VALUE) return false;
    DWORD wr = 0;
    BOOL ok = TRUE;
    if (!all.empty()) ok = WriteFile(h, all.data(), (DWORD)all.size(), &wr, NULL);
    CloseHandle(h);
    return ok == TRUE;
}

static int ParseBool(const std::wstring& v) {
    std::wstring t = ToLowerW(TrimW(v));
    if (t == L"1" || t == L"on" || t == L"true" || t == L"yes" || t == L"是" || t == L"开") return 1;
    return 0;
}

/* 读取旧版 VoiceHotkey.ini（只有语音设置），实现无缝升级 */
static void ImportOldIni(const std::wstring& path, Config& c) {
    std::wstring text;
    if (!ReadTextFile(path, text)) return;
    std::vector<std::wstring> lines = SplitLines(text);
    std::wstring keyTok = L"F9";
    UINT mods = 0;
    for (size_t i = 0; i < lines.size(); i++) {
        std::wstring ln = TrimW(lines[i]);
        if (ln.empty() || ln[0] == L';' || ln[0] == L'#') continue;
        size_t eq = ln.find(L'=');
        if (eq == std::wstring::npos) continue;
        std::wstring k = TrimW(ln.substr(0, eq));
        std::wstring v = TrimW(ln.substr(eq + 1));
        if (EqualsNoCase(k, L"TriggerKey"))      keyTok = v;
        else if (EqualsNoCase(k, L"TriggerCtrl"))  { if (ParseBool(v)) mods |= KM_CTRL; }
        else if (EqualsNoCase(k, L"TriggerAlt"))   { if (ParseBool(v)) mods |= KM_ALT; }
        else if (EqualsNoCase(k, L"TriggerShift")) { if (ParseBool(v)) mods |= KM_SHIFT; }
        else if (EqualsNoCase(k, L"HoldMode"))     c.vtrigger = ParseBool(v) ? VT_HOLD : VT_TOGGLE;
        else if (EqualsNoCase(k, L"Provider")) {
            if (EqualsNoCase(v, L"weixin")) c.provider = VP_WEIXIN;
            else if (EqualsNoCase(v, L"winvoice") || EqualsNoCase(v, L"windows")) c.provider = VP_WINDOWS;
            else if (EqualsNoCase(v, L"custom")) c.provider = VP_CUSTOM;
        }
        else if (EqualsNoCase(k, L"CustomToggle")) StringToHotkey(v, c.customToggle);
        else if (EqualsNoCase(k, L"CustomHold"))   StringToHotkey(v, c.customHold);
        else if (EqualsNoCase(k, L"Enabled"))      c.voiceEnabled = ParseBool(v) != 0;
        else if (EqualsNoCase(k, L"ChordHoldMs"))  { int ms = _wtoi(v.c_str()); if (ms >= 20 && ms <= 2000) c.chordHoldMs = ms; }
    }
    Hotkey hk(mods, 0);
    UINT vk = 0;
    if (IsKeyName(keyTok, vk)) hk.vk = vk;
    if (hk.Valid()) c.voiceKey = hk;
}

bool ConfigLoad(const std::wstring& path, Config& c, bool* existed) {
    if (existed) *existed = false;

    HANDLE h = CreateFileW(path.c_str(), GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE,
                           NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
    if (h == INVALID_HANDLE_VALUE) {
        /* 新配置文件不存在 —— 看看有没有旧版设置可以继承 */
        ConfigDefault(c);
        std::wstring dir = ExeDir();
        ImportOldIni(dir + L"\\" + KS_OLD_INI, c);
        return false;
    }
    CloseHandle(h);
    if (existed) *existed = true;

    ConfigDefault(c);
    c.rules.clear();

    std::wstring text;
    if (!ReadTextFile(path, text)) return false;

    std::vector<std::wstring> lines = SplitLines(text);
    std::wstring section;
    Rule curRule;
    bool inRule = false;

    /* 先把全局默认值保留，避免文件里缺项时变成 0 */
    Config def; ConfigDefault(def);
    c.enabledAll = def.enabledAll;
    c.chordHoldMs = def.chordHoldMs;
    c.gapMs = def.gapMs;
    c.startup = def.startup;
    c.monitor = def.monitor;
    c.testMode = 0;

    for (size_t i = 0; i < lines.size(); i++) {
        std::wstring ln = TrimW(lines[i]);
        if (ln.empty()) continue;
        if (ln[0] == L';' || ln[0] == L'#') continue;

        if (ln[0] == L'[') {
            if (inRule) { c.rules.push_back(curRule); inRule = false; }
            std::wstring s = ln;
            size_t rb = s.find(L']');
            if (rb != std::wstring::npos) s = s.substr(1, rb - 1);
            else s = s.substr(1);
            s = ToLowerW(TrimW(s));
            if (s == L"规则" || s == L"rule" || s == L"rules") {
                section = L"rule";
                curRule = Rule();
                inRule = true;
            } else if (s == L"全局" || s == L"general" || s == L"global" || s == L"app") {
                section = L"general";
            } else if (s == L"语音输入" || s == L"voice") {
                section = L"voice";
            } else {
                section = s;
            }
            continue;
        }

        size_t eq = ln.find(L'=');
        if (eq == std::wstring::npos) continue;
        std::wstring k = TrimW(ln.substr(0, eq));
        std::wstring v = TrimW(ln.substr(eq + 1));

        if (section == L"general") {
            if (EqualsNoCase(k, L"Enabled"))          c.enabledAll = ParseBool(v) != 0;
            else if (EqualsNoCase(k, L"Monitor"))     c.monitor = ParseBool(v);
            else if (EqualsNoCase(k, L"Startup"))     c.startup = ParseBool(v) != 0;
            else if (EqualsNoCase(k, L"ChordHoldMs")) { int ms = _wtoi(v.c_str()); if (ms >= 20 && ms <= 2000) c.chordHoldMs = ms; }
            else if (EqualsNoCase(k, L"GapMs"))       { int ms = _wtoi(v.c_str()); if (ms >= 0 && ms <= 500) c.gapMs = ms; }
            else if (EqualsNoCase(k, L"TestMode"))    c.testMode = ParseBool(v);
        } else if (section == L"voice") {
            if (EqualsNoCase(k, L"Enabled"))        c.voiceEnabled = ParseBool(v) != 0;
            else if (EqualsNoCase(k, L"Key") || EqualsNoCase(k, L"Hotkey")) {
                Hotkey hk; if (StringToHotkey(v, hk) && hk.Valid()) c.voiceKey = hk;
            }
            else if (EqualsNoCase(k, L"Provider")) {
                if (EqualsNoCase(v, L"weixin") || EqualsNoCase(v, L"wechat")) c.provider = VP_WEIXIN;
                else if (EqualsNoCase(v, L"windows") || EqualsNoCase(v, L"winvoice")) c.provider = VP_WINDOWS;
                else if (EqualsNoCase(v, L"custom")) c.provider = VP_CUSTOM;
            }
            else if (EqualsNoCase(k, L"Trigger") || EqualsNoCase(k, L"HoldMode")) {
                c.vtrigger = (EqualsNoCase(v, L"hold") || ParseBool(v)) ? VT_HOLD : VT_TOGGLE;
            }
            else if (EqualsNoCase(k, L"CustomToggle")) { Hotkey hk; if (StringToHotkey(v, hk)) c.customToggle = hk; }
            else if (EqualsNoCase(k, L"CustomHold"))   { Hotkey hk; if (StringToHotkey(v, hk)) c.customHold = hk; }
        } else if (section == L"rule") {
            if (EqualsNoCase(k, L"Enabled"))      curRule.enabled = ParseBool(v) != 0;
            else if (EqualsNoCase(k, L"From"))    { Hotkey hk; if (StringToHotkey(v, hk)) curRule.src = hk; }
            else if (EqualsNoCase(k, L"To"))      { Hotkey hk; if (StringToHotkey(v, hk)) curRule.dst = hk; }
            else if (EqualsNoCase(k, L"Note") || EqualsNoCase(k, L"Desc")) curRule.note = v;
            else if (EqualsNoCase(k, L"Mode") || EqualsNoCase(k, L"Action")) {
                if (EqualsNoCase(v, L"voice"))      curRule.act = ACT_VOICE;
                else if (EqualsNoCase(v, L"block")) curRule.act = ACT_BLOCK;
                else                                 curRule.act = ACT_SWAP;
            }
        }
    }
    if (inRule) c.rules.push_back(curRule);

    /* 丢掉没有「按下」的坏规则 */
    std::vector<Rule> keep;
    for (size_t i = 0; i < c.rules.size(); i++) {
        if (c.rules[i].src.Valid()) keep.push_back(c.rules[i]);
    }
    c.rules = keep;
    return true;
}

bool ConfigSave(const std::wstring& path, const Config& c) {
    std::wstring t;
    t += L"; ================================================================\r\n";
    t += L";  快捷键更换助手 KeySwap v" KS_VERSION L"  配置文件\r\n";
    t += L";  用记事本改也行：改完保存，回到程序点「重新载入」或重启程序。\r\n";
    t += L";\r\n";
    t += L";  【规则】每写一条，就多一组「按下 X → 变成 Y」\r\n";
    t += L";     From = 你按下的组合键        例：Ctrl+Alt+K\r\n";
    t += L";     To   = 你想让它变成的组合键  例：F5\r\n";
    t += L";     Mode = swap  换成别的键\r\n";
    t += L";            voice 触发语音输入\r\n";
    t += L";            block 直接屏蔽（什么也不发）\r\n";
    t += L";     Note = 备注，随便写\r\n";
    t += L";     组合键写法：Ctrl / Alt / Shift / Win 加号连起来，如 Ctrl+Shift+A、F9\r\n";
    t += L"; ================================================================\r\n\r\n";

    t += L"[全局]\r\n";
    t += FormatW(L"Enabled=%d\r\n", c.enabledAll ? 1 : 0);
    t += FormatW(L"Monitor=%d\r\n", c.monitor);
    t += FormatW(L"Startup=%d\r\n", c.startup ? 1 : 0);
    t += FormatW(L"ChordHoldMs=%d\r\n", c.chordHoldMs);
    t += FormatW(L"GapMs=%d\r\n", c.gapMs);
    if (c.testMode) t += FormatW(L"TestMode=%d\r\n", c.testMode);
    t += L"\r\n";

    t += L"[语音输入]\r\n";
    t += FormatW(L"Enabled=%d\r\n", c.voiceEnabled ? 1 : 0);
    t += L"Key=" + HotkeyToString(c.voiceKey) + L"\r\n";
    t += L"Provider=" + std::wstring(c.provider == VP_WEIXIN ? L"weixin" :
                                     c.provider == VP_WINDOWS ? L"windows" : L"custom") + L"\r\n";
    t += L"Trigger=" + std::wstring(c.vtrigger == VT_HOLD ? L"hold" : L"toggle") + L"\r\n";
    t += L"CustomToggle=" + HotkeyToString(c.customToggle) + L"\r\n";
    t += L"CustomHold=" + HotkeyToString(c.customHold) + L"\r\n\r\n";

    for (size_t i = 0; i < c.rules.size(); i++) {
        const Rule& r = c.rules[i];
        t += L"[规则]\r\n";
        t += FormatW(L"Enabled=%d\r\n", r.enabled ? 1 : 0);
        t += L"From=" + HotkeyToString(r.src) + L"\r\n";
        t += L"Mode=" + std::wstring(r.act == ACT_VOICE ? L"voice" : r.act == ACT_BLOCK ? L"block" : L"swap") + L"\r\n";
        if (r.act == ACT_SWAP) t += L"To=" + HotkeyToString(r.dst) + L"\r\n";
        if (!r.note.empty()) t += L"Note=" + r.note + L"\r\n";
        t += L"\r\n";
    }

    return WriteTextFile(path, t);
}

/* ------------------------------------------------------------ 开机自启 */

static const wchar_t* kRunKey = L"Software\\Microsoft\\Windows\\CurrentVersion\\Run";

bool StartupIsEnabled() {
    HKEY hk = NULL;
    if (RegOpenKeyExW(HKEY_CURRENT_USER, kRunKey, 0, KEY_READ, &hk) != ERROR_SUCCESS) return false;
    wchar_t buf[1024];
    DWORD sz = sizeof(buf), type = 0;
    LONG r = RegQueryValueExW(hk, KS_APP_EN, NULL, &type, (LPBYTE)buf, &sz);
    RegCloseKey(hk);
    return r == ERROR_SUCCESS;
}

bool StartupSet(bool on) {
    HKEY hk = NULL;
    if (RegOpenKeyExW(HKEY_CURRENT_USER, kRunKey, 0, KEY_SET_VALUE, &hk) != ERROR_SUCCESS) return false;
    bool ok = false;
    if (on) {
        std::wstring cmd = L"\"" + ExePath() + L"\"";
        LONG r = RegSetValueExW(hk, KS_APP_EN, 0, REG_SZ, (const BYTE*)cmd.c_str(),
                                (DWORD)((cmd.size() + 1) * sizeof(wchar_t)));
        ok = (r == ERROR_SUCCESS);
    } else {
        LONG r = RegDeleteValueW(hk, KS_APP_EN);
        ok = (r == ERROR_SUCCESS || r == ERROR_FILE_NOT_FOUND);
    }
    RegCloseKey(hk);
    return ok;
}

/* ==========================================================================
   快捷键更换助手 (KeySwap)  v2.1  —  核心引擎
   --------------------------------------------------------------------------
   低层键盘钩子 (WH_KEYBOARD_LL) 拦截「按下 X」，
   再由独立工作线程用 SendInput 发出「变成 Y」。
   钩子回调里绝不做耗时操作（不能 Sleep），否则会被系统摘掉钩子。
   ========================================================================== */
#include "ks.h"

#include <process.h>

/* ------------------------------------------------------------- 内部状态 */

static HHOOK        g_hook    = NULL;
static HWND         g_notify  = NULL;      /* 主窗口，用来收日志 */
static HWND         g_captureWnd = NULL;   /* 正在录制热键的窗口（可能是弹出的编辑框） */
static CRITICAL_SECTION g_cs;
static bool         g_csInit  = false;
static Config       g_cfg;

static volatile LONG g_enabled   = 1;      /* 总开关 */
static volatile LONG g_monitor   = 0;
static volatile LONG g_testMode  = 0;
static volatile LONG g_capturing = 0;
static volatile LONG g_running   = 0;

/* 物理按键按下表：只由钩子线程写入 */
static bool g_down[256];

/* 当前被我们吞掉的「触发键」（它的松开事件也要吞掉） */
static UINT g_activeSrc   = 0;
static int  g_activeRule  = -1;     /* -1 = 语音热键, >=0 = 规则下标 */
static bool g_activeHold  = false;  /* 触发的是「按住说话」 */

/* 统计 */
static volatile LONG64 g_fireCount  = 0;
static volatile LONG64 g_blockCount = 0;

/* --------------------------------------------------------- 等待队列 */
enum { PK_FIRE = 0, PK_HOLD_START = 1, PK_HOLD_END = 2 };

struct Pending {
    int        kind;
    ActionKind act;
    Hotkey     src;
    Hotkey     dst;
    UINT       physMods;
};

static std::deque<Pending> g_queue;
static CRITICAL_SECTION    g_qcs;
static bool                g_qcsInit = false;
static HANDLE              g_qEvent  = NULL;
static HANDLE              g_hThread = NULL;

/* ------------------------------------------------------------ 提供方 */

struct ProviderInfo {
    int            id;
    const wchar_t* name;
    const wchar_t* hint;
    Hotkey         toggle;
    Hotkey         hold;
    bool           holdIsPress;
};

static ProviderInfo MakeWeixin() {
    ProviderInfo p;
    p.id = VP_WEIXIN;
    p.name = L"电脑版微信（Ctrl+Win）";
    p.hint = L"需要电脑版微信 4.1.7 或更高版本，并且已登录";
    StringToHotkey(L"Ctrl+Win+Shift", p.toggle);
    StringToHotkey(L"Ctrl+Win", p.hold);
    p.holdIsPress = true;
    return p;
}
static ProviderInfo MakeWindows() {
    ProviderInfo p;
    p.id = VP_WINDOWS;
    p.name = L"Windows 系统自带（Win+H）";
    p.hint = L"不装微信也能用；Win+H 按一下开会 / 再按一下关";
    StringToHotkey(L"Win+H", p.toggle);
    StringToHotkey(L"Win+H", p.hold);
    p.holdIsPress = false;
    return p;
}
static ProviderInfo MakeCustom(const Config& c) {
    ProviderInfo p;
    p.id = VP_CUSTOM;
    p.name = L"自定义组合键";
    p.hint = L"适用于讯飞、搜狗等自带语音快捷键的输入法";
    p.toggle = c.customToggle;
    p.hold = c.customHold;
    p.holdIsPress = true;
    return p;
}

static ProviderInfo ProviderFor(const Config& c) {
    switch (c.provider) {
        case VP_WINDOWS: return MakeWindows();
        case VP_CUSTOM:  return MakeCustom(c);
        default:         return MakeWeixin();
    }
}

/* 取出「点按」或「按住」要发的组合键；holdIsPress 表示按住型 */
static bool ResolveVoiceChord(const Config& c, bool hold, Hotkey& chord, bool& holdIsPress) {
    ProviderInfo p = ProviderFor(c);
    if (hold) { chord = p.hold; holdIsPress = p.holdIsPress; }
    else      { chord = p.toggle; holdIsPress = true; }
    return chord.mods != 0 || chord.vk != 0;
}

/* ------------------------------------------------------------ 按键发送 */

/* 这些键在真实键盘上走的是「扩展键」通道（扫描码前面带 E0），
   注入时不带这个标志，Windows 和有些程序会认不出来（Win 键尤其明显）。*/
static bool IsExtendedVk(UINT vk) {
    switch (vk) {
        case VK_RMENU: case VK_RCONTROL: case VK_INSERT: case VK_DELETE:
        case VK_HOME:  case VK_END:      case VK_PRIOR:  case VK_NEXT:
        case VK_LEFT:  case VK_RIGHT:    case VK_UP:     case VK_DOWN:
        case VK_NUMLOCK: case VK_CANCEL: case VK_SNAPSHOT: case VK_DIVIDE:
        case VK_LWIN:  case VK_RWIN:     case VK_APPS:
            return true;
    }
    return false;
}

static void SendKeyVk(UINT vk, bool up) {
    INPUT in;
    ZeroMemory(&in, sizeof(in));
    in.type = INPUT_KEYBOARD;
    in.ki.wVk = (WORD)vk;
    /* 补上真实扫描码，让注入的按键尽可能像真键盘按出来的 */
    in.ki.wScan = (WORD)MapVirtualKeyW(vk, MAPVK_VK_TO_VSC);
    in.ki.dwFlags = up ? KEYEVENTF_KEYUP : 0;
    if (IsExtendedVk(vk)) in.ki.dwFlags |= KEYEVENTF_EXTENDEDKEY;
    in.ki.dwExtraInfo = KS_MAGIC;
    SendInput(1, &in, sizeof(INPUT));
}

static int ModsToVkList(UINT mods, UINT out[4]) {
    int n = 0;
    if (mods & KM_CTRL)  out[n++] = VK_CONTROL;
    if (mods & KM_ALT)   out[n++] = VK_MENU;
    if (mods & KM_SHIFT) out[n++] = VK_SHIFT;
    if (mods & KM_WIN)   out[n++] = VK_LWIN;
    return n;
}

static bool AnyPhysDown(UINT mods) {
    UINT vks[4];
    int n = ModsToVkList(mods, vks);
    for (int i = 0; i < n; i++) {
        if (GetAsyncKeyState((int)vks[i]) & 0x8000) return true;
    }
    return false;
}

/* 等用户把手上的修饰键松开，避免「按 Ctrl+K 触发 F5」变成「Ctrl+F5」 */
static void WaitModsReleased(UINT mods, int maxMs) {
    if (!mods) return;
    int waited = 0;
    while (AnyPhysDown(mods) && waited < maxMs) {
        Sleep(10);
        waited += 10;
    }
}

/* 完整的「按下组合键 → 保持 → 松开」 */
static void InjectChord(const Hotkey& hk, int holdMs, int gapMs) {
    UINT vks[4];
    int n = ModsToVkList(hk.mods, vks);
    for (int i = 0; i < n; i++) { SendKeyVk(vks[i], false); if (gapMs) Sleep(gapMs); }
    if (hk.vk) {
        SendKeyVk(hk.vk, false);
        Sleep(holdMs);
        SendKeyVk(hk.vk, true);
        if (gapMs) Sleep(gapMs);
    } else {
        Sleep(holdMs);
    }
    for (int i = n - 1; i >= 0; i--) { SendKeyVk(vks[i], true); if (gapMs) Sleep(gapMs); }
}

/* 按下并保持（按住说话用），返回按下了哪些键 */
static int HoldPress(const Hotkey& hk, UINT pressed[4], int gapMs) {
    int n = ModsToVkList(hk.mods, pressed);
    for (int i = 0; i < n; i++) { SendKeyVk(pressed[i], false); if (gapMs) Sleep(gapMs); }
    if (hk.vk) {
        SendKeyVk(hk.vk, false);
        pressed[n++] = hk.vk;
    }
    return n;
}

static void HoldRelease(const UINT pressed[4], int n, int gapMs) {
    for (int i = n - 1; i >= 0; i--) { SendKeyVk(pressed[i], true); if (gapMs) Sleep(gapMs); }
}

/* ============================================================ 工作线程 */

static volatile LONG  g_holdActive = 0;
static UINT           g_heldVks[4];
static int            g_heldN = 0;
static CRITICAL_SECTION g_holdCs;
static bool           g_holdCsInit = false;

static void DoFire(const Pending& p) {
    Config cfg;
    EnterCriticalSection(&g_cs);
    cfg = g_cfg;
    LeaveCriticalSection(&g_cs);

    if (p.act == ACT_BLOCK) { InterlockedIncrement64(&g_blockCount); return; }

    Hotkey target;
    if (p.act == ACT_VOICE) {
        bool dummy = true;
        if (!ResolveVoiceChord(cfg, cfg.vtrigger == VT_HOLD, target, dummy)) return;
    } else {
        target = p.dst;
    }
    if (!target.Valid() && target.mods == 0) return;

    /* 目标里已经包含的修饰键不再重复按；手上多余的修饰键等它松开 */
    UINT need = target.mods & ~p.physMods;
    UINT wait = p.physMods & ~target.mods;
    if (wait) WaitModsReleased(wait, 800);

    Hotkey send;
    send.mods = need;
    send.vk   = target.vk;
    InjectChord(send, cfg.chordHoldMs, cfg.gapMs);
    InterlockedIncrement64(&g_fireCount);
}

static void DoHoldStart(const Pending& p) {
    Config cfg;
    EnterCriticalSection(&g_cs);
    cfg = g_cfg;
    LeaveCriticalSection(&g_cs);

    Hotkey target;
    bool holdIsPress = true;
    if (p.act == ACT_VOICE) {
        if (!ResolveVoiceChord(cfg, true, target, holdIsPress)) return;
    } else {
        target = p.dst;
        holdIsPress = true;
    }

    if (!holdIsPress) {
        /* Win+H 这种点按型的，按下时点一下就好，松开不做事 */
        UINT need = target.mods & ~p.physMods;
        UINT wait = p.physMods & ~target.mods;
        if (wait) WaitModsReleased(wait, 800);
        Hotkey send;
        send.mods = need;
        send.vk = target.vk;
        InjectChord(send, cfg.chordHoldMs, cfg.gapMs);
        InterlockedIncrement64(&g_fireCount);
        return;
    }

    UINT wait = p.physMods & ~target.mods;
    if (wait) WaitModsReleased(wait, 800);

    EnterCriticalSection(&g_holdCs);
    if (g_holdActive) { LeaveCriticalSection(&g_holdCs); return; }
    g_heldN = HoldPress(target, g_heldVks, cfg.gapMs);
    g_holdActive = 1;
    LeaveCriticalSection(&g_holdCs);
    InterlockedIncrement64(&g_fireCount);
}

static void DoHoldEnd() {
    EnterCriticalSection(&g_holdCs);
    if (g_holdActive) {
        Config cfg;
        EnterCriticalSection(&g_cs);
        cfg.gapMs = g_cfg.gapMs;
        LeaveCriticalSection(&g_cs);
        HoldRelease(g_heldVks, g_heldN, cfg.gapMs);
        g_heldN = 0;
        g_holdActive = 0;
    }
    LeaveCriticalSection(&g_holdCs);
}

static unsigned __stdcall WorkerProc(void*) {
    while (InterlockedCompareExchange(&g_running, 1, 1) == 1) {
        WaitForSingleObject(g_qEvent, 200);
        for (;;) {
            Pending p;
            bool got = false;
            EnterCriticalSection(&g_qcs);
            if (!g_queue.empty()) { p = g_queue.front(); g_queue.pop_front(); got = true; }
            LeaveCriticalSection(&g_qcs);
            if (!got) break;
            switch (p.kind) {
                case PK_FIRE:       DoFire(p);      break;
                case PK_HOLD_START: DoHoldStart(p); break;
                case PK_HOLD_END:   DoHoldEnd();    break;
            }
        }
    }
    return 0;
}

static void Enqueue(const Pending& p) {
    EnterCriticalSection(&g_qcs);
    if (g_queue.size() < 64) g_queue.push_back(p);
    LeaveCriticalSection(&g_qcs);
    SetEvent(g_qEvent);
}

/* ============================================================== 钩子 */

static bool IsModifierVk(UINT vk) {
    switch (vk) {
        case VK_LSHIFT: case VK_RSHIFT: case VK_SHIFT:
        case VK_LCONTROL: case VK_RCONTROL: case VK_CONTROL:
        case VK_LMENU: case VK_RMENU: case VK_MENU:
        case VK_LWIN: case VK_RWIN:
            return true;
    }
    return false;
}

static UINT PhysicalMods() {
    UINT m = 0;
    if (g_down[VK_LCONTROL] || g_down[VK_RCONTROL] || g_down[VK_CONTROL]) m |= KM_CTRL;
    if (g_down[VK_LMENU]    || g_down[VK_RMENU]    || g_down[VK_MENU])    m |= KM_ALT;
    if (g_down[VK_LSHIFT]   || g_down[VK_RSHIFT]   || g_down[VK_SHIFT])   m |= KM_SHIFT;
    if (g_down[VK_LWIN]     || g_down[VK_RWIN])                           m |= KM_WIN;
    return m;
}

/* 在规则表里找第一条匹配的（返回下标，-1 表示没有） */
static int FindRule(const Config& c, UINT mods, UINT vk) {
    for (size_t i = 0; i < c.rules.size(); i++) {
        const Rule& r = c.rules[i];
        if (!r.enabled) continue;
        if (r.src.vk != vk) continue;
        if (r.src.mods != mods) continue;
        return (int)i;
    }
    return -1;
}

static void LogLine(const std::wstring& s) {
    if (!g_notify) return;
    std::wstring* p = new std::wstring(s);
    if (!PostMessageW(g_notify, WM_KS_KEYLOG, (WPARAM)p, 0)) delete p;
}

static LRESULT CALLBACK LowLevelKbProc(int nCode, WPARAM wParam, LPARAM lParam) {
    if (nCode != HC_ACTION) return CallNextHookEx(g_hook, nCode, wParam, lParam);

    KBDLLHOOKSTRUCT* k = (KBDLLHOOKSTRUCT*)lParam;
    bool isUp = (wParam == WM_KEYUP || wParam == WM_SYSKEYUP);
    UINT vk   = (UINT)k->vkCode;

    /* 自己注入的按键：直接放行，绝不再走一遍逻辑（否则会自己触发自己） */
    if (k->dwExtraInfo == KS_MAGIC) return CallNextHookEx(g_hook, nCode, wParam, lParam);

    /* 别的程序模拟出来的按键：默认不理（自动化测试时可以打开） */
    if ((k->flags & LLKHF_INJECTED) && !g_testMode)
        return CallNextHookEx(g_hook, nCode, wParam, lParam);

    bool down  = !isUp;
    bool repeat = false;
    if (down) {
        if (vk < 256) { repeat = g_down[vk]; g_down[vk] = true; }
    } else {
        if (vk < 256) g_down[vk] = false;
    }

    /* ---------------- 1) 录制热键模式：吞掉所有按键 ---------------- */
    if (g_capturing) {
        if (down) {
            HWND dst = g_captureWnd ? g_captureWnd : g_notify;
            if (vk == VK_ESCAPE && !IsModifierVk(vk)) {
                InterlockedExchange(&g_capturing, 0);
                PostMessageW(dst, WM_KS_CAPTURE, 0, 0);
            } else if (!IsModifierVk(vk)) {
                Hotkey hk(PhysicalMods(), vk);
                InterlockedExchange(&g_capturing, 0);
                PostMessageW(dst, WM_KS_CAPTURE, PackHotkey(hk), 1);
            }
        }
        return 1;
    }

    /* ---------------- 2) 被我们吞掉的触发键，松开也要吞掉 ---------------- */
    /* 注意：这一步必须放在「总开关」判断之前，否则中途关掉总开关会卡住按键 */
    if (!down && g_activeSrc != 0 && g_activeSrc == vk) {
        if (g_activeHold) {
            Pending p;
            p.kind     = PK_HOLD_END;
            p.act      = ACT_VOICE;
            p.physMods = 0;
            Enqueue(p);
        }
        g_activeSrc  = 0;
        g_activeRule = -1;
        g_activeHold = false;
        return 1;
    }

    /* ---------------- 3) 总开关关了就全放行 ---------------- */
    if (!g_enabled) {
        if (g_monitor && down) LogLine(L"（已暂停）按下 " + HotkeyToString(Hotkey(PhysicalMods(), vk)));
        return CallNextHookEx(g_hook, nCode, wParam, lParam);
    }

    Config cfg;
    EnterCriticalSection(&g_cs);
    cfg = g_cfg;
    LeaveCriticalSection(&g_cs);

    if (down) {
        UINT mods = PhysicalMods();

        /* 2a) 语音输入热键 */
        if (cfg.voiceEnabled && cfg.voiceKey.Valid() &&
            vk == cfg.voiceKey.vk && mods == cfg.voiceKey.mods) {
            if (!repeat) {
                Pending p;
                p.kind = (cfg.vtrigger == VT_HOLD) ? PK_HOLD_START : PK_FIRE;
                p.act  = ACT_VOICE;
                p.src  = cfg.voiceKey;
                p.physMods = mods;
                Enqueue(p);
                if (g_monitor) LogLine(L"按下 " + HotkeyToString(Hotkey(mods, vk)) + L"  →  触发语音输入");
            }
            g_activeSrc  = vk;
            g_activeRule = -1;
            g_activeHold = (cfg.vtrigger == VT_HOLD);
            return 1;
        }

        /* 2b) 替换规则 */
        int idx = FindRule(cfg, mods, vk);
        if (idx >= 0) {
            const Rule& r = cfg.rules[idx];
            if (!repeat) {
                Pending p;
                p.kind = (r.act == ACT_VOICE && cfg.vtrigger == VT_HOLD) ? PK_HOLD_START : PK_FIRE;
                p.act  = r.act;
                p.src  = r.src;
                p.dst  = r.dst;
                p.physMods = mods;
                Enqueue(p);
                if (g_monitor) {
                    std::wstring what;
                    if (r.act == ACT_BLOCK)     what = L"屏蔽，什么都不发";
                    else if (r.act == ACT_VOICE) what = L"触发语音输入";
                    else                        what = L"换成 " + HotkeyToString(r.dst);
                    LogLine(L"按下 " + HotkeyToString(Hotkey(mods, vk)) + L"  →  " + what);
                }
            } else if (g_monitor) {
                /* 长按重复，不重复记录 */
            }
            g_activeSrc  = vk;
            g_activeRule = idx;
            g_activeHold = (r.act == ACT_VOICE && cfg.vtrigger == VT_HOLD);
            return 1;
        }

        if (g_monitor) LogLine(L"按下 " + HotkeyToString(Hotkey(mods, vk)));
        return CallNextHookEx(g_hook, nCode, wParam, lParam);
    }

    return CallNextHookEx(g_hook, nCode, wParam, lParam);
}

/* ============================================================ 对外接口 */

/* 所有对外接口进来先确保临界区/事件已创建。
   注意：GuiCreateMain 里 EngineApplyConfig 会早于 EngineStart 被调用，
   不这么做就会在未初始化的临界区上 EnterCriticalSection → 直接崩。 */
static void EngineEnsureInit() {
    static bool inited = false;
    if (inited) return;
    InitializeCriticalSection(&g_cs);
    InitializeCriticalSection(&g_qcs);
    InitializeCriticalSection(&g_holdCs);
    g_csInit = g_qcsInit = g_holdCsInit = true;
    if (!g_qEvent) g_qEvent = CreateEventW(NULL, FALSE, FALSE, NULL);
    inited = true;
}

bool EngineStart(HWND notifyWnd) {
    g_notify = notifyWnd;
    ZeroMemory(g_down, sizeof(g_down));

    EngineEnsureInit();

    InterlockedExchange(&g_running, 1);
    if (!g_hThread) {
        unsigned tid = 0;
        g_hThread = (HANDLE)_beginthreadex(NULL, 0, WorkerProc, NULL, 0, &tid);
    }

    if (!g_hook) {
        g_hook = SetWindowsHookExW(WH_KEYBOARD_LL, LowLevelKbProc, GetModuleHandleW(NULL), 0);
    }
    return g_hook != NULL;
}

void EngineStop() {
    if (!g_csInit) return;
    if (g_hook) { UnhookWindowsHookEx(g_hook); g_hook = NULL; }

    InterlockedExchange(&g_running, 0);
    if (g_qEvent) SetEvent(g_qEvent);
    if (g_hThread) {
        WaitForSingleObject(g_hThread, 1500);
        CloseHandle(g_hThread);
        g_hThread = NULL;
    }
    /* 万一还按着，松开，别让键盘卡住 */
    if (g_holdCsInit) {
        EnterCriticalSection(&g_holdCs);
        if (g_holdActive) { HoldRelease(g_heldVks, g_heldN, 0); g_heldN = 0; g_holdActive = 0; }
        LeaveCriticalSection(&g_holdCs);
    }
}

void EngineApplyConfig(const Config& c) {
    EngineEnsureInit();
    EnterCriticalSection(&g_cs);
    g_cfg = c;
    LeaveCriticalSection(&g_cs);
    InterlockedExchange(&g_monitor, c.monitor ? 1 : 0);
    InterlockedExchange(&g_testMode, c.testMode ? 1 : 0);
}

void EngineSetEnabled(bool on) { InterlockedExchange(&g_enabled, on ? 1 : 0); }
bool EngineIsEnabled()         { return g_enabled != 0; }
int  EngineRuleCount() {
    if (!g_csInit) return 0;
    EnterCriticalSection(&g_cs);
    int n = (int)g_cfg.rules.size();
    LeaveCriticalSection(&g_cs);
    return n;
}
bool EngineHooked() { return g_hook != NULL; }

unsigned long long EngineFireCount()  { return (unsigned long long)g_fireCount; }
unsigned long long EngineBlockCount() { return (unsigned long long)g_blockCount; }
void EngineResetStats() { InterlockedExchange64(&g_fireCount, 0); InterlockedExchange64(&g_blockCount, 0); }

void EngineDoVoiceToggle() {
    EngineEnsureInit();
    Config cfg;
    EnterCriticalSection(&g_cs); cfg = g_cfg; LeaveCriticalSection(&g_cs);
    Pending p;
    p.kind = PK_FIRE;
    p.act  = ACT_VOICE;
    p.physMods = PhysicalMods();
    Enqueue(p);
}
void EngineDoVoiceHoldStart() {
    Pending p;
    p.kind = PK_HOLD_START; p.act = ACT_VOICE; p.physMods = PhysicalMods();
    Enqueue(p);
}
void EngineDoVoiceHoldEnd() {
    Pending p;
    p.kind = PK_HOLD_END; p.act = ACT_VOICE;
    Enqueue(p);
}

void EngineFireRule(size_t idx) {
    EngineEnsureInit();
    Config cfg;
    EnterCriticalSection(&g_cs); cfg = g_cfg; LeaveCriticalSection(&g_cs);
    if (idx >= cfg.rules.size()) return;
    Pending p;
    p.kind = PK_FIRE;
    p.act  = cfg.rules[idx].act;
    p.src  = cfg.rules[idx].src;
    p.dst  = cfg.rules[idx].dst;
    p.physMods = PhysicalMods();
    Enqueue(p);
}

void EngineBeginCapture(HWND targetWnd) {
    g_captureWnd = targetWnd;
    InterlockedExchange(&g_capturing, 1);
}
void EngineCancelCapture() { InterlockedExchange(&g_capturing, 0); }
bool EngineIsCapturing()   { return g_capturing != 0; }
void EngineSetMonitor(bool on) { InterlockedExchange(&g_monitor, on ? 1 : 0); }

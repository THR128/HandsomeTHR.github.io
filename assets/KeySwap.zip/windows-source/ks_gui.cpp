/* ==========================================================================
   快捷键更换助手 (KeySwap)  v2.1  —  图形界面 + 托盘 + 主消息循环
   ========================================================================== */
#include "ks.h"

#include <cstdio>
#include <cstdlib>
#include <cwchar>
#include <cstring>

/* --------------------------------------------------------------- 控件 ID */
#define IDC_TAB          1001
#define IDC_HINT1        1002
#define IDC_LIST         1003
#define IDC_ADD          1004
#define IDC_EDIT         1005
#define IDC_DEL          1006
#define IDC_UP           1007
#define IDC_DOWN         1008
#define IDC_TOGGLE       1009
#define IDC_TRY          1010
#define IDC_MONITOR      1011
#define IDC_LOG          1012

#define IDC_VOICE_ON     1101
#define IDC_LBL_KEY      1102
#define IDC_HK_VOICE     1103
#define IDC_LBL_PROV     1104
#define IDC_PROVIDER     1105
#define IDC_PROV_HINT    1106
#define IDC_RB_TOGGLE    1107
#define IDC_RB_HOLD      1108
#define IDC_LBL_CT       1109
#define IDC_LBL_CT1      1110
#define IDC_HK_CTOGGLE   1111
#define IDC_LBL_CT2      1112
#define IDC_HK_CHOLD     1113
#define IDC_CUSTOM_HINT  1114
#define IDC_VOICE_TEST   1115
#define IDC_LBL_HOLDMS   1116
#define IDC_HOLDMS       1117
#define IDC_HOLDMS_HINT  1118
#define IDC_VOICE_NOTE   1119
#define IDC_LBL_USE      1120

#define IDC_STARTUP      1201
#define IDC_ENABLED      1202
#define IDC_LBL_INI      1203
#define IDC_OPEN_INI     1204
#define IDC_OPEN_DIR     1205
#define IDC_RELOAD       1206
#define IDC_ABOUT        1207

#define IDC_RD_FROM      1301
#define IDC_RD_TO        1302
#define IDC_RD_MODE      1303
#define IDC_RD_NOTE      1304
#define IDC_RD_OK        1305
#define IDC_RD_CANCEL    1306
#define IDC_RD_CLEAR     1307

#define IDT_SAVE         9001

/* ------------------------------------------------------------- 全局变量 */
static HINSTANCE   g_inst   = NULL;
static HWND        g_main   = NULL;
static HWND        g_h[1300];        /* 按 ID 索引（ID 从 1001 起 → 下标 = ID-1000） */
static HFONT       g_font   = NULL;
static int         g_dpi    = 96;
static Config      g_cfg;
static bool        g_uiReady = false;
static bool        g_trayAdded = false;
static bool        g_balloonShown = false;
static int         g_capWhich = 0;    /* 主窗口上正在录制的热键框：0=无 */
static std::wstring g_iniPath;

#define H(id) g_h[(id) - 1000]

static int S(int v) { return MulDiv(v, g_dpi, 96); }

/* 各 Tab 上放哪些控件 */
static const int kTab1[] = { IDC_HINT1, IDC_LIST, IDC_ADD, IDC_EDIT, IDC_DEL, IDC_UP, IDC_DOWN,
                             IDC_TOGGLE, IDC_TRY, IDC_MONITOR, IDC_LOG, 0 };
static const int kTab2[] = { IDC_VOICE_ON, IDC_LBL_KEY, IDC_HK_VOICE, IDC_LBL_PROV, IDC_PROVIDER,
                             IDC_PROV_HINT, IDC_LBL_USE, IDC_RB_TOGGLE, IDC_RB_HOLD, IDC_LBL_CT,
                             IDC_LBL_CT1, IDC_HK_CTOGGLE, IDC_LBL_CT2, IDC_HK_CHOLD,
                             IDC_CUSTOM_HINT, IDC_VOICE_TEST, IDC_LBL_HOLDMS, IDC_HOLDMS,
                             IDC_HOLDMS_HINT, IDC_VOICE_NOTE, 0 };
static const int kTab3[] = { IDC_STARTUP, IDC_ENABLED, IDC_LBL_INI, IDC_OPEN_INI, IDC_OPEN_DIR,
                             IDC_RELOAD, IDC_ABOUT, 0 };

/* --------------------------------------------------------------- 小工具 */

static void SetFont(HWND h) { SendMessageW(h, WM_SETFONT, (WPARAM)g_font, TRUE); }

/* mingw 的 commctrl.h 里没有 Button_SetCheck / Button_GetCheck 这两个宏，
   自己补上，省得调用点到处改。 */
static inline void Button_SetCheck(HWND h, int check) {
    SendMessageW(h, BM_SETCHECK, (WPARAM)check, 0);
}
static inline int Button_GetCheck(HWND h) {
    return (int)SendMessageW(h, BM_GETCHECK, 0, 0);
}

static HWND MkCtl(const wchar_t* cls, const wchar_t* text, DWORD style, DWORD exStyle,
                  int x, int y, int w, int h, int id, HWND parent) {
    HWND c = CreateWindowExW(exStyle, cls, text, WS_CHILD | WS_VISIBLE | style,
                             S(x), S(y), S(w), S(h), parent, (HMENU)(INT_PTR)id, g_inst, NULL);
    if (c) SetFont(c);
    if (id >= 1000 && id < 1300) g_h[id - 1000] = c;
    return c;
}
static HWND MkStatic(const wchar_t* t, int x, int y, int w, int h, int id, HWND p) {
    return MkCtl(L"STATIC", t, SS_LEFT, 0, x, y, w, h, id, p);
}
static HWND MkButton(const wchar_t* t, int x, int y, int w, int h, int id, HWND p) {
    return MkCtl(L"BUTTON", t, BS_PUSHBUTTON | WS_TABSTOP, 0, x, y, w, h, id, p);
}
static HWND MkCheck(const wchar_t* t, int x, int y, int w, int h, int id, HWND p) {
    return MkCtl(L"BUTTON", t, BS_AUTOCHECKBOX | WS_TABSTOP, 0, x, y, w, h, id, p);
}
static HWND MkRadio(const wchar_t* t, int x, int y, int w, int h, int id, HWND p) {
    return MkCtl(L"BUTTON", t, BS_AUTORADIOBUTTON | WS_TABSTOP, 0, x, y, w, h, id, p);
}
static HWND MkEdit(const wchar_t* t, int x, int y, int w, int h, int id, DWORD extra, HWND p) {
    return MkCtl(L"EDIT", t, WS_TABSTOP | ES_AUTOHSCROLL | extra, WS_EX_CLIENTEDGE, x, y, w, h, id, p);
}

static void ShowTab(int tab) {
    for (int i = 0; kTab1[i]; i++) ShowWindow(H(kTab1[i]), tab == 0 ? SW_SHOW : SW_HIDE);
    for (int i = 0; kTab2[i]; i++) ShowWindow(H(kTab2[i]), tab == 1 ? SW_SHOW : SW_HIDE);
    for (int i = 0; kTab3[i]; i++) ShowWindow(H(kTab3[i]), tab == 2 ? SW_SHOW : SW_HIDE);
}

static void SaveSoon(HWND hwnd) {
    KillTimer(hwnd, IDT_SAVE);
    SetTimer(hwnd, IDT_SAVE, 700, NULL);
}

static void ApplyConfigToEngine() {
    EngineApplyConfig(g_cfg);
    g_cfg.monitor = g_cfg.monitor ? 1 : 0;
}

static void SaveConfigNow() {
    ConfigSave(g_iniPath, g_cfg);
}

/* ------------------------------------------------------------ 规则列表 */

static void RefreshRuleList() {
    HWND lv = H(IDC_LIST);
    if (!lv) return;
    int sel = ListView_GetNextItem(lv, -1, LVNI_SELECTED);
    ListView_DeleteAllItems(lv);

    for (size_t i = 0; i < g_cfg.rules.size(); i++) {
        const Rule& r = g_cfg.rules[i];
        std::wstring mode = r.act == ACT_VOICE ? L"语音输入" : r.act == ACT_BLOCK ? L"屏蔽" : L"换成";
        std::wstring to   = r.act == ACT_VOICE ? L"（语音）" : r.act == ACT_BLOCK ? L"—" : HotkeyToString(r.dst);

        LVITEMW it;
        ZeroMemory(&it, sizeof(it));
        it.mask = LVIF_TEXT | LVIF_PARAM;
        it.iItem = (int)i;
        it.iSubItem = 0;
        it.lParam = (LPARAM)i;
        std::wstring st = r.enabled ? L"✔ 启用" : L"　停用";
        it.pszText = (LPWSTR)st.c_str();
        int row = ListView_InsertItem(lv, &it);
        ListView_SetItemText(lv, row, 1, (LPWSTR)HotkeyToString(r.src).c_str());
        ListView_SetItemText(lv, row, 2, (LPWSTR)to.c_str());
        ListView_SetItemText(lv, row, 3, (LPWSTR)mode.c_str());
        ListView_SetItemText(lv, row, 4, (LPWSTR)r.note.c_str());
    }
    if (sel >= 0 && sel < (int)g_cfg.rules.size())
        ListView_SetItemState(lv, sel, LVIS_SELECTED | LVIS_FOCUSED, LVIS_SELECTED | LVIS_FOCUSED);
}

static void UpdateStatus() {
    HWND status = FindWindowExW(g_main, NULL, STATUSCLASSNAMEW, NULL);
    if (!status) return;

    wchar_t b0[160], b1[128], b2[128];
    if (!EngineIsEnabled())   wcscpy(b0, L"状态：已暂停（右键托盘图标可恢复）");
    else if (!EngineHooked()) wcscpy(b0, L"状态：钩子未装上，试试以管理员身份运行");
    else                      wcscpy(b0, L"状态：正在运行");
    swprintf(b1, 128, L"规则：%d 条", (int)g_cfg.rules.size());
    swprintf(b2, 128, L"已替换 %llu 次", EngineFireCount());

    SendMessageW(status, SB_SETTEXTW, 0, (LPARAM)b0);
    SendMessageW(status, SB_SETTEXTW, 1, (LPARAM)b1);
    SendMessageW(status, SB_SETTEXTW, 2, (LPARAM)b2);
}

/* -------------------------------------------------------------- 前向声明 */
static void SyncUIFromConfig();
static void LogAppend(const std::wstring& s);
static void ShowMainWindow();
static void HideToTray();

/* ============================================================ 规则编辑框 */

struct RuleDlg {
    HWND   hwnd;
    Hotkey from, to;
    int    mode;        /* 0=换成 1=语音 2=屏蔽 */
    std::wstring note;
    int    capWhich;    /* 0 无, 1 按下, 2 变成 */
    bool   ok;
    bool   done;
};
static RuleDlg* g_rd = NULL;

static void RdRefresh() {
    if (!g_rd) return;
    SetWindowTextW(GetDlgItem(g_rd->hwnd, IDC_RD_FROM),
                   g_rd->from.Valid() ? HotkeyToString(g_rd->from).c_str() : L"点这里录制");
    SetWindowTextW(GetDlgItem(g_rd->hwnd, IDC_RD_TO),
                   g_rd->to.Valid() ? HotkeyToString(g_rd->to).c_str() : L"点这里录制");
    Button_SetCheck(GetDlgItem(g_rd->hwnd, IDC_RD_MODE),
                    g_rd->mode == 0 ? BST_CHECKED : BST_UNCHECKED);
    EnableWindow(GetDlgItem(g_rd->hwnd, IDC_RD_TO), g_rd->mode == 0);
}

static LRESULT CALLBACK RuleDlgProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp) {
    switch (msg) {
        case WM_COMMAND: {
            int id = LOWORD(wp);
            if (!g_rd) break;
            if (id == IDC_RD_FROM) {
                g_rd->capWhich = 1;
                SetWindowTextW(GetDlgItem(hwnd, IDC_RD_FROM), L"请按组合键…（Esc 取消）");
                EngineBeginCapture(hwnd);
            } else if (id == IDC_RD_TO) {
                g_rd->capWhich = 2;
                SetWindowTextW(GetDlgItem(hwnd, IDC_RD_TO), L"请按组合键…（Esc 取消）");
                EngineBeginCapture(hwnd);
            } else if (id == IDC_RD_CLEAR) {
                if (g_rd->capWhich == 1) { g_rd->from = Hotkey(); RdRefresh(); }
                else if (g_rd->capWhich == 2) { g_rd->to = Hotkey(); RdRefresh(); }
                else { g_rd->from = Hotkey(); g_rd->to = Hotkey(); RdRefresh(); }
            } else if (id == IDC_RD_MODE) {
                g_rd->mode = Button_GetCheck(GetDlgItem(hwnd, IDC_RD_MODE)) == BST_CHECKED ? 0 : 1;
                RdRefresh();
            } else if (id == IDC_RD_OK || id == IDOK) {
                wchar_t buf[512];
                GetWindowTextW(GetDlgItem(hwnd, IDC_RD_NOTE), buf, 512);
                g_rd->note = buf;
                if (!g_rd->from.Valid()) {
                    MessageBoxW(hwnd, L"还没录制「按下」的组合键。\n点左边那个按钮，然后按一下你想用的键。",
                                L"快捷键更换助手", MB_OK | MB_ICONINFORMATION);
                    break;
                }
                if (g_rd->mode == 0 && !g_rd->to.Valid() && g_rd->to.mods == 0) {
                    MessageBoxW(hwnd, L"「变成」还没设置。\n要么录制一个组合键，要么把「换成另一个键」的勾去掉（就是屏蔽）。",
                                L"快捷键更换助手", MB_OK | MB_ICONINFORMATION);
                    break;
                }
                g_rd->ok = true;
                g_rd->done = true;
                EngineCancelCapture();
            } else if (id == IDC_RD_CANCEL || id == IDCANCEL) {
                g_rd->ok = false;
                g_rd->done = true;
                EngineCancelCapture();
            }
            break;
        }
        case WM_KS_CAPTURE: {
            if (!g_rd) break;
            if (lp == 0) {
                g_rd->capWhich = 0;
                RdRefresh();
                break;
            }
            Hotkey hk = UnpackHotkey(wp);
            if (g_rd->capWhich == 1) g_rd->from = hk;
            else if (g_rd->capWhich == 2) g_rd->to = hk;
            g_rd->capWhich = 0;
            RdRefresh();
            break;
        }
        case WM_CLOSE:
            if (g_rd) { g_rd->ok = false; g_rd->done = true; EngineCancelCapture(); }
            break;
        default:
            return DefWindowProcW(hwnd, msg, wp, lp);
    }
    return 0;
}

static bool ShowRuleDialog(HWND parent, Rule& r, bool isNew) {
    static bool reg = false;
    if (!reg) {
        WNDCLASSEXW wc;
        ZeroMemory(&wc, sizeof(wc));
        wc.cbSize = sizeof(wc);
        wc.style = CS_DBLCLKS;
        wc.lpfnWndProc = RuleDlgProc;
        wc.hInstance = g_inst;
        wc.hCursor = LoadCursorW(NULL, IDC_ARROW);
        wc.hbrBackground = (HBRUSH)(COLOR_BTNFACE + 1);
        wc.lpszClassName = L"KeySwapRuleDlg";
        wc.hIcon = (HICON)SendMessageW(parent, WM_GETICON, ICON_SMALL, 0);
        RegisterClassExW(&wc);
        reg = true;
    }

    /* 注意：这里绝对不能 ZeroMemory(&rd, ...) —— rd 里有 std::wstring，
       memset 会把它内部指针清成 NULL，后面一赋值就写空指针。 */
    RuleDlg rd;
    rd.hwnd     = NULL;
    rd.from     = r.src;
    rd.to       = r.dst;
    rd.mode     = r.act == ACT_VOICE ? 1 : r.act == ACT_BLOCK ? 2 : 0;
    rd.note     = r.note;
    rd.capWhich = 0;
    rd.ok       = false;
    rd.done     = false;

    int W = 470, Hh = 300;
    RECT pr;
    GetWindowRect(parent, &pr);
    int x = pr.left + ((pr.right - pr.left) - S(W)) / 2;
    int y = pr.top + ((pr.bottom - pr.top) - S(Hh)) / 2;

    HWND dlg = CreateWindowExW(WS_EX_DLGMODALFRAME, L"KeySwapRuleDlg",
                               isNew ? L"添加一条替换规则" : L"编辑这条规则",
                               WS_POPUP | WS_CAPTION | WS_SYSMENU | WS_VISIBLE,
                               x, y, S(W), S(Hh), parent, NULL, g_inst, NULL);
    if (!dlg) return false;
    rd.hwnd = dlg;
    g_rd = &rd;

    MkStatic(L"我按下：", 16, 20, 80, 22, 0, dlg);
    MkCtl(L"BUTTON", L"点这里录制", BS_PUSHBUTTON | WS_TABSTOP, 0,
          100, 18, 170, 30, IDC_RD_FROM, dlg);
    MkButton(L"清除", 280, 18, 60, 30, IDC_RD_CLEAR, dlg);

    MkStatic(L"变成：", 16, 62, 80, 22, 0, dlg);
    MkCtl(L"BUTTON", L"点这里录制", BS_PUSHBUTTON | WS_TABSTOP, 0,
          100, 60, 170, 30, IDC_RD_TO, dlg);
    MkCtl(L"BUTTON", L"勾上＝换成另一个键", BS_AUTOCHECKBOX | WS_TABSTOP, 0,
          280, 64, 170, 24, IDC_RD_MODE, dlg);
    Button_SetCheck(GetDlgItem(dlg, IDC_RD_MODE), BST_CHECKED);

    MkStatic(L"备注：", 16, 104, 80, 22, 0, dlg);
    MkEdit(r.note.c_str(), 100, 102, 350, 26, IDC_RD_NOTE, 0, dlg);

    MkStatic(L"提示：勾去掉就是「直接屏蔽」，按了什么也不发。\n"
             L"录制时按 Esc 取消。组合键最多四个修饰键加一个主键。",
             16, 140, 434, 44, 0, dlg);

    MkButton(L"确定", 250, 210, 96, 32, IDC_RD_OK, dlg);
    MkButton(L"取消", 354, 210, 96, 32, IDC_RD_CANCEL, dlg);

    RdRefresh();

    EnableWindow(parent, FALSE);
    SetForegroundWindow(dlg);

    MSG msg;
    while (!rd.done && GetMessageW(&msg, NULL, 0, 0)) {
        if (!IsDialogMessageW(dlg, &msg)) {
            TranslateMessage(&msg);
            DispatchMessageW(&msg);
        }
    }
    if (IsWindow(dlg)) DestroyWindow(dlg);
    g_rd = NULL;
    g_capWhich = 0;

    EnableWindow(parent, TRUE);
    SetActiveWindow(parent);

    /* 恢复钩子把消息发回主窗口 */
    if (EngineIsCapturing()) EngineCancelCapture();

    if (rd.ok) {
        r.src = rd.from;
        r.act = rd.mode == 1 ? ACT_VOICE : rd.mode == 2 ? ACT_BLOCK : ACT_SWAP;
        r.dst = rd.to;
        r.note = rd.note;
    }
    return rd.ok;
}

/* ============================================================ 主窗口 */

static void LogAppend(const std::wstring& s) {
    HWND e = H(IDC_LOG);
    if (!e) return;
    int len = GetWindowTextLengthW(e);
    if (len > 20000) {
        SendMessageW(e, EM_SETSEL, 0, 4000);
        SendMessageW(e, EM_REPLACESEL, FALSE, (LPARAM)L"");
    }
    SendMessageW(e, EM_SETSEL, (WPARAM)-1, (LPARAM)-1);
    std::wstring line = s + L"\r\n";
    SendMessageW(e, EM_REPLACESEL, FALSE, (LPARAM)line.c_str());
}

static void SyncUIFromConfig() {
    g_uiReady = false;
    Button_SetCheck(H(IDC_MONITOR), g_cfg.monitor ? BST_CHECKED : BST_UNCHECKED);
    Button_SetCheck(H(IDC_VOICE_ON), g_cfg.voiceEnabled ? BST_CHECKED : BST_UNCHECKED);
    Button_SetCheck(H(IDC_RB_TOGGLE), g_cfg.vtrigger == VT_TOGGLE ? BST_CHECKED : BST_UNCHECKED);
    Button_SetCheck(H(IDC_RB_HOLD), g_cfg.vtrigger == VT_HOLD ? BST_CHECKED : BST_UNCHECKED);
    Button_SetCheck(H(IDC_STARTUP), g_cfg.startup ? BST_CHECKED : BST_UNCHECKED);
    Button_SetCheck(H(IDC_ENABLED), EngineIsEnabled() ? BST_CHECKED : BST_UNCHECKED);

    SetWindowTextW(H(IDC_HK_VOICE), HotkeyToString(g_cfg.voiceKey).c_str());
    SetWindowTextW(H(IDC_HK_CTOGGLE), HotkeyToString(g_cfg.customToggle).c_str());
    SetWindowTextW(H(IDC_HK_CHOLD), HotkeyToString(g_cfg.customHold).c_str());

    HWND cb = H(IDC_PROVIDER);
    SendMessageW(cb, CB_RESETCONTENT, 0, 0);
    SendMessageW(cb, CB_ADDSTRING, 0, (LPARAM)L"电脑版微信（Ctrl+Win）");
    SendMessageW(cb, CB_ADDSTRING, 0, (LPARAM)L"Windows 系统自带（Win+H）");
    SendMessageW(cb, CB_ADDSTRING, 0, (LPARAM)L"自定义组合键");
    SendMessageW(cb, CB_SETCURSEL, (WPARAM)g_cfg.provider, 0);

    wchar_t b[32];
    swprintf(b, 32, L"%d", g_cfg.chordHoldMs);
    SetWindowTextW(H(IDC_HOLDMS), b);

    const wchar_t* hints[3] = {
        L"需要电脑版微信 4.1.7 或更高版本，并且已经登录（最小化没关系，完全退出不行）",
        L"不装微信也能用：按 Win+H 打开系统听写，再按一下关闭",
        L"适用于讯飞、搜狗等自带语音快捷键的输入法，下面自己填组合键"
    };
    SetWindowTextW(H(IDC_PROV_HINT), hints[g_cfg.provider]);

    SetWindowTextW(H(IDC_LBL_INI), (L"配置文件：" + g_iniPath).c_str());

    g_uiReady = true;
    RefreshRuleList();
    UpdateStatus();
}

static void ReadUIToConfig(bool* needApply) {
    if (!g_uiReady) return;
    bool apply = false;

    int mon = Button_GetCheck(H(IDC_MONITOR)) == BST_CHECKED ? 1 : 0;
    if (mon != g_cfg.monitor) { g_cfg.monitor = mon; apply = true; EngineSetMonitor(mon != 0); }

    bool ve = Button_GetCheck(H(IDC_VOICE_ON)) == BST_CHECKED;
    if (ve != g_cfg.voiceEnabled) { g_cfg.voiceEnabled = ve; apply = true; }

    int vt = Button_GetCheck(H(IDC_RB_HOLD)) == BST_CHECKED ? VT_HOLD : VT_TOGGLE;
    if (vt != g_cfg.vtrigger) { g_cfg.vtrigger = vt; apply = true; }

    bool st = Button_GetCheck(H(IDC_STARTUP)) == BST_CHECKED;
    if (st != g_cfg.startup) {
        g_cfg.startup = st;
        StartupSet(st);
        apply = true;
    }

    bool en = Button_GetCheck(H(IDC_ENABLED)) == BST_CHECKED;
    if (en != EngineIsEnabled()) { EngineSetEnabled(en); UpdateStatus(); }

    int prov = (int)SendMessageW(H(IDC_PROVIDER), CB_GETCURSEL, 0, 0);
    if (prov >= 0 && prov != g_cfg.provider) {
        g_cfg.provider = prov;
        const wchar_t* hints[3] = {
            L"需要电脑版微信 4.1.7 或更高版本，并且已经登录（最小化没关系，完全退出不行）",
            L"不装微信也能用：按 Win+H 打开系统听写，再按一下关闭",
            L"适用于讯飞、搜狗等自带语音快捷键的输入法，下面自己填组合键"
        };
        SetWindowTextW(H(IDC_PROV_HINT), hints[prov]);
        apply = true;
    }

    wchar_t b[32];
    GetWindowTextW(H(IDC_HOLDMS), b, 32);
    int ms = _wtoi(b);
    if (ms >= 20 && ms <= 2000 && ms != g_cfg.chordHoldMs) { g_cfg.chordHoldMs = ms; apply = true; }

    if (needApply) *needApply = apply;
    if (apply) ApplyConfigToEngine();
}

static void ShowMainWindow() {
    ShowWindow(g_main, SW_SHOW);
    ShowWindow(g_main, SW_RESTORE);
    SetForegroundWindow(g_main);
}

static void HideToTray() {
    ShowWindow(g_main, SW_HIDE);
    if (!g_balloonShown && g_trayAdded) {
        NOTIFYICONDATAW nid;
        ZeroMemory(&nid, sizeof(nid));
        nid.cbSize = sizeof(nid);
        nid.hWnd = g_main;
        nid.uID = KS_TRAY_ID;
        nid.uFlags = NIF_INFO;
        nid.dwInfoFlags = NIIF_INFO;
        wcscpy(nid.szInfoTitle, L"快捷键更换助手还在后台干活");
        wcscpy(nid.szInfo, L"双击这里可以再打开窗口；要彻底退出请右键这个图标。");
        Shell_NotifyIconW(NIM_MODIFY, &nid);
        g_balloonShown = true;
    }
}

/* ------------------------------------------------------------- 托盘 */

static void TrayAdd() {
    NOTIFYICONDATAW nid;
    ZeroMemory(&nid, sizeof(nid));
    nid.cbSize = sizeof(nid);
    nid.hWnd = g_main;
    nid.uID = KS_TRAY_ID;
    nid.uFlags = NIF_ICON | NIF_MESSAGE | NIF_TIP;
    nid.uCallbackMessage = WM_KS_TRAY;
    nid.hIcon = (HICON)LoadImageW(g_inst, MAKEINTRESOURCEW(101), IMAGE_ICON,
                                  GetSystemMetrics(SM_CXSMICON), GetSystemMetrics(SM_CYSMICON), 0);
    if (!nid.hIcon) nid.hIcon = LoadIconW(NULL, IDI_APPLICATION);
    wcscpy(nid.szTip, KS_APP_NAME L" v" KS_VERSION);
    g_trayAdded = Shell_NotifyIconW(NIM_ADD, &nid) == TRUE;
}

static void TrayRemove() {
    if (!g_trayAdded) return;
    NOTIFYICONDATAW nid;
    ZeroMemory(&nid, sizeof(nid));
    nid.cbSize = sizeof(nid);
    nid.hWnd = g_main;
    nid.uID = KS_TRAY_ID;
    Shell_NotifyIconW(NIM_DELETE, &nid);
    g_trayAdded = false;
}

static void TrayMenu() {
    HMENU m = CreatePopupMenu();
    AppendMenuW(m, MF_STRING, 1, L"打开主界面");
    AppendMenuW(m, MF_SEPARATOR, 0, NULL);
    AppendMenuW(m, MF_STRING | (EngineIsEnabled() ? MF_CHECKED : 0), 2,
                EngineIsEnabled() ? L"暂停所有替换" : L"恢复所有替换");
    AppendMenuW(m, MF_STRING | (g_cfg.startup ? MF_CHECKED : 0), 3, L"开机自动启动");
    AppendMenuW(m, MF_STRING | (g_cfg.monitor ? MF_CHECKED : 0), 4, L"按键监视（排查用）");
    AppendMenuW(m, MF_SEPARATOR, 0, NULL);
    AppendMenuW(m, MF_STRING, 9, L"退出 " KS_APP_EN);

    POINT pt;
    GetCursorPos(&pt);
    SetForegroundWindow(g_main);
    int cmd = (int)TrackPopupMenu(m, TPM_RETURNCMD | TPM_RIGHTBUTTON, pt.x, pt.y, 0, g_main, NULL);
    DestroyMenu(m);
    PostMessageW(g_main, WM_NULL, 0, 0);

    switch (cmd) {
        case 1: ShowMainWindow(); break;
        case 2: {
            bool on = !EngineIsEnabled();
            EngineSetEnabled(on);
            Button_SetCheck(H(IDC_ENABLED), on ? BST_CHECKED : BST_UNCHECKED);
            UpdateStatus();
            break;
        }
        case 3: {
            g_cfg.startup = !g_cfg.startup;
            StartupSet(g_cfg.startup);
            Button_SetCheck(H(IDC_STARTUP), g_cfg.startup ? BST_CHECKED : BST_UNCHECKED);
            SaveSoon(g_main);
            break;
        }
        case 4: {
            g_cfg.monitor = g_cfg.monitor ? 0 : 1;
            EngineSetMonitor(g_cfg.monitor != 0);
            Button_SetCheck(H(IDC_MONITOR), g_cfg.monitor ? BST_CHECKED : BST_UNCHECKED);
            SaveSoon(g_main);
            break;
        }
        case 9:
            SaveConfigNow();
            DestroyWindow(g_main);
            break;
    }
}

/* ------------------------------------------------------------- 建界面 */

static void BuildUI(HWND hwnd) {
    /* 菜单栏 */
    HMENU mb = CreateMenu();
    HMENU m1 = CreatePopupMenu();
    AppendMenuW(m1, MF_STRING, 100, L"重新载入配置(&R)");
    AppendMenuW(m1, MF_STRING, 101, L"打开配置文件(&O)");
    AppendMenuW(m1, MF_STRING, 102, L"打开配置所在文件夹(&F)");
    AppendMenuW(m1, MF_SEPARATOR, 0, NULL);
    AppendMenuW(m1, MF_STRING, 103, L"退出(&X)");
    AppendMenuW(mb, MF_POPUP, (UINT_PTR)m1, L"文件(&F)");
    HMENU m2 = CreatePopupMenu();
    AppendMenuW(m2, MF_STRING, 200, L"暂停 / 恢复所有替换(&P)");
    AppendMenuW(m2, MF_STRING, 201, L"重置统计(&C)");
    AppendMenuW(mb, MF_POPUP, (UINT_PTR)m2, L"操作(&A)");
    HMENU m3 = CreatePopupMenu();
    AppendMenuW(m3, MF_STRING, 300, L"使用说明(&H)");
    AppendMenuW(m3, MF_STRING, 301, L"关于(&A)");
    AppendMenuW(mb, MF_POPUP, (UINT_PTR)m3, L"帮助(&H)");
    SetMenu(hwnd, mb);

    MkCtl(WC_TABCONTROLW, L"", WS_TABSTOP, 0, 10, 10, 780, 566, IDC_TAB, hwnd);
    TCITEMW ti;
    ZeroMemory(&ti, sizeof(ti));
    ti.mask = TCIF_TEXT;
    ti.pszText = (LPWSTR)L"  快捷键替换  ";
    TabCtrl_InsertItem(H(IDC_TAB), 0, &ti);
    ti.pszText = (LPWSTR)L"  语音输入  ";
    TabCtrl_InsertItem(H(IDC_TAB), 1, &ti);
    ti.pszText = (LPWSTR)L"  设置  ";
    TabCtrl_InsertItem(H(IDC_TAB), 2, &ti);

    /* ---------------- Tab1 ---------------- */
    MkStatic(L"下面就是你自己的替换清单：左边是你按下的键，中间是它实际会变成的键。不给力就点「试一下」。",
             24, 46, 750, 20, IDC_HINT1, hwnd);

    HWND lv = MkCtl(WC_LISTVIEWW, L"", LVS_REPORT | LVS_SINGLESEL | LVS_SHOWSELALWAYS | WS_TABSTOP,
                    WS_EX_CLIENTEDGE, 24, 70, 752, 246, IDC_LIST, hwnd);
    ListView_SetExtendedListViewStyle(lv, LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES | LVS_EX_DOUBLEBUFFER);
    struct { const wchar_t* t; int w; } cols[] = {
        { L"状态", 70 }, { L"我按下", 150 }, { L"变成", 150 }, { L"方式", 74 }, { L"备注", 300 }
    };
    for (int i = 0; i < 5; i++) {
        LVCOLUMNW c;
        ZeroMemory(&c, sizeof(c));
        c.mask = LVCF_TEXT | LVCF_WIDTH | LVCF_SUBITEM;
        c.pszText = (LPWSTR)cols[i].t;
        c.cx = S(cols[i].w);
        c.iSubItem = i;
        ListView_InsertColumn(lv, i, &c);
    }

    MkButton(L"添加规则", 24, 326, 92, 30, IDC_ADD, hwnd);
    MkButton(L"编辑", 122, 326, 70, 30, IDC_EDIT, hwnd);
    MkButton(L"删除", 198, 326, 70, 30, IDC_DEL, hwnd);
    MkButton(L"上移", 274, 326, 62, 30, IDC_UP, hwnd);
    MkButton(L"下移", 342, 326, 62, 30, IDC_DOWN, hwnd);
    MkButton(L"启用 / 停用", 410, 326, 100, 30, IDC_TOGGLE, hwnd);
    MkButton(L"试一下", 516, 326, 80, 30, IDC_TRY, hwnd);

    MkCheck(L"打开按键监视（想知道某个键到底有没有被拦下来时用，平时关掉）",
            24, 364, 560, 22, IDC_MONITOR, hwnd);
    MkCtl(L"EDIT", L"", WS_VSCROLL | ES_MULTILINE | ES_READONLY | WS_TABSTOP,
          WS_EX_CLIENTEDGE, 24, 390, 752, 168, IDC_LOG, hwnd);
    /* ---------------- Tab2 ---------------- */
    MkCheck(L"启用语音输入热键（这台电脑上「按一下就能说话」的开关）",
            28, 50, 520, 22, IDC_VOICE_ON, hwnd);
    MkStatic(L"热键：", 28, 88, 60, 22, IDC_LBL_KEY, hwnd);
    MkCtl(L"BUTTON", L"点这里录制", BS_PUSHBUTTON | WS_TABSTOP, 0,
          92, 84, 180, 30, IDC_HK_VOICE, hwnd);
    MkStatic(L"语音输入来源：", 300, 88, 110, 22, IDC_LBL_PROV, hwnd);
    MkCtl(L"COMBOBOX", L"", CBS_DROPDOWNLIST | WS_VSCROLL | WS_TABSTOP, 0,
          414, 84, 300, 200, IDC_PROVIDER, hwnd);
    MkStatic(L"", 28, 120, 700, 20, IDC_PROV_HINT, hwnd);

    MkStatic(L"怎么用：", 28, 150, 80, 22, IDC_LBL_USE, hwnd);
    MkRadio(L"按一下开始说话，再按一下结束（推荐，手指不用一直按着）",
            100, 150, 420, 22, IDC_RB_TOGGLE, hwnd);
    MkRadio(L"按住热键说话，松开就结束（跟微信里按住说话一个感觉）",
            100, 176, 420, 22, IDC_RB_HOLD, hwnd);

    MkStatic(L"自定义组合键（上面「语音输入来源」选「自定义」时才用得上）：",
             28, 212, 520, 22, IDC_LBL_CT, hwnd);
    MkStatic(L"点按一下发：", 28, 246, 90, 22, IDC_LBL_CT1, hwnd);
    MkCtl(L"BUTTON", L"点这里录制", BS_PUSHBUTTON | WS_TABSTOP, 0,
          122, 242, 170, 30, IDC_HK_CTOGGLE, hwnd);
    MkStatic(L"按住时发：", 310, 246, 90, 22, IDC_LBL_CT2, hwnd);
    MkCtl(L"BUTTON", L"点这里录制", BS_PUSHBUTTON | WS_TABSTOP, 0,
          404, 242, 170, 30, IDC_HK_CHOLD, hwnd);
    MkStatic(L"组合键只写修饰键也行，比如 Ctrl+Win（微信「按住说话」就是这种）。",
             28, 280, 700, 20, IDC_CUSTOM_HINT, hwnd);

    MkButton(L"试一下（把语音条叫出来）", 28, 310, 240, 34, IDC_VOICE_TEST, hwnd);
    MkStatic(L"按住时长：", 28, 366, 90, 22, IDC_LBL_HOLDMS, hwnd);
    MkCtl(L"EDIT", L"130", WS_TABSTOP | ES_NUMBER, WS_EX_CLIENTEDGE, 122, 362, 70, 26, IDC_HOLDMS, hwnd);
    MkStatic(L"毫秒（微信升级后认不出来，就改成 200 试试）", 200, 366, 420, 22, IDC_HOLDMS_HINT, hwnd);
    MkStatic(L"如果你操作的软件是「以管理员身份运行」的（某些游戏、开发工具），普通权限的钩子够不着它：\r\n"
             L"右键 KeySwap.exe → 属性 → 兼容性 → 勾上「以管理员身份运行此程序」，再重开本程序。",
             28, 404, 730, 60, IDC_VOICE_NOTE, hwnd);

    /* ---------------- Tab3 ---------------- */
    MkCheck(L"开机自动启动（下次开机会自己跑起来）", 28, 50, 460, 22, IDC_STARTUP, hwnd);
    MkCheck(L"总开关：暂停所有替换（临时想让原快捷键恢复原样时用）", 28, 80, 560, 22, IDC_ENABLED, hwnd);
    MkStatic(L"", 28, 124, 730, 20, IDC_LBL_INI, hwnd);
    MkButton(L"打开配置文件", 28, 152, 130, 30, IDC_OPEN_INI, hwnd);
    MkButton(L"打开所在文件夹", 166, 152, 140, 30, IDC_OPEN_DIR, hwnd);
    MkButton(L"重新载入配置", 314, 152, 130, 30, IDC_RELOAD, hwnd);
    MkStatic(L"快捷键更换助手 KeySwap v" KS_VERSION L"（C++ 版）\r\n"
             L"\r\n"
             L"它干两件事：\r\n"
             L"  1. 把记不住的复杂快捷键，换成你顺手的样子（可以加很多条）。\r\n"
             L"  2. 按一下热键就能说话，语音文字直接进到光标所在的地方。\r\n"
             L"\r\n"
             L"不写注册表、不装驱动、不联网，就一个 exe。\r\n"
             L"设置全在下面这个文件里，用记事本也能改，删掉就恢复默认。\r\n"
             L"\r\n"
             L"小提示：\r\n"
             L"· 关窗口不会退出，它会缩到右下角托盘继续干活；要退出请右键托盘图标。\r\n"
             L"· 想让某个快捷键「恢复原样」，去「快捷键替换」页把它停用就行。\r\n"
             L"· 记不住哪个键对应哪条规则？打开「按键监视」，按下试试，日志里会写。\r\n"
             L"· 微信语音没反应：先确认电脑版微信 4.1.7+ 已登录，再把「按住时长」改成 200。",
             28, 200, 740, 320, IDC_ABOUT, hwnd);

    /* 状态栏 */
    HWND sb = CreateWindowExW(0, STATUSCLASSNAMEW, L"",
                              WS_CHILD | WS_VISIBLE | SBARS_SIZEGRIP, 0, 0, 0, 0,
                              hwnd, (HMENU)0, g_inst, NULL);
    SetFont(sb);
    int parts[3] = { S(400), S(560), -1 };
    SendMessageW(sb, SB_SETPARTS, 3, (LPARAM)parts);

    ShowTab(0);
}

/* ------------------------------------------------------------ 窗口过程 */

static void OnCommand(HWND hwnd, int id, int code) {
    switch (id) {
        case IDC_ADD: {
            Rule r;
            r.enabled = true;
            if (ShowRuleDialog(hwnd, r, true)) {
                g_cfg.rules.push_back(r);
                RefreshRuleList();
                ApplyConfigToEngine();
                SaveSoon(hwnd);
                int n = (int)g_cfg.rules.size() - 1;
                ListView_SetItemState(H(IDC_LIST), n, LVIS_SELECTED | LVIS_FOCUSED,
                                      LVIS_SELECTED | LVIS_FOCUSED);
                ListView_EnsureVisible(H(IDC_LIST), n, FALSE);
            }
            break;
        }
        case IDC_EDIT: {
            int sel = ListView_GetNextItem(H(IDC_LIST), -1, LVNI_SELECTED);
            if (sel < 0 || sel >= (int)g_cfg.rules.size()) {
                MessageBoxW(hwnd, L"先在列表里点一条规则。", KS_APP_NAME, MB_OK | MB_ICONINFORMATION);
                break;
            }
            Rule r = g_cfg.rules[sel];
            if (ShowRuleDialog(hwnd, r, false)) {
                g_cfg.rules[sel] = r;
                RefreshRuleList();
                ApplyConfigToEngine();
                SaveSoon(hwnd);
            }
            break;
        }
        case IDC_DEL: {
            int sel = ListView_GetNextItem(H(IDC_LIST), -1, LVNI_SELECTED);
            if (sel < 0 || sel >= (int)g_cfg.rules.size()) {
                MessageBoxW(hwnd, L"先在列表里点一条规则。", KS_APP_NAME, MB_OK | MB_ICONINFORMATION);
                break;
            }
            if (MessageBoxW(hwnd, (L"确定删掉这条规则吗？\r\n\r\n" + HotkeyToString(g_cfg.rules[sel].src)).c_str(),
                            KS_APP_NAME, MB_YESNO | MB_ICONQUESTION) == IDYES) {
                g_cfg.rules.erase(g_cfg.rules.begin() + sel);
                RefreshRuleList();
                ApplyConfigToEngine();
                SaveSoon(hwnd);
            }
            break;
        }
        case IDC_UP:
        case IDC_DOWN: {
            int sel = ListView_GetNextItem(H(IDC_LIST), -1, LVNI_SELECTED);
            int to = id == IDC_UP ? sel - 1 : sel + 1;
            if (sel < 0 || to < 0 || to >= (int)g_cfg.rules.size()) break;
            std::swap(g_cfg.rules[sel], g_cfg.rules[to]);
            RefreshRuleList();
            ListView_SetItemState(H(IDC_LIST), to, LVIS_SELECTED | LVIS_FOCUSED,
                                  LVIS_SELECTED | LVIS_FOCUSED);
            ApplyConfigToEngine();
            SaveSoon(hwnd);
            break;
        }
        case IDC_TOGGLE: {
            int sel = ListView_GetNextItem(H(IDC_LIST), -1, LVNI_SELECTED);
            if (sel < 0 || sel >= (int)g_cfg.rules.size()) {
                MessageBoxW(hwnd, L"先在列表里点一条规则。", KS_APP_NAME, MB_OK | MB_ICONINFORMATION);
                break;
            }
            g_cfg.rules[sel].enabled = !g_cfg.rules[sel].enabled;
            RefreshRuleList();
            ListView_SetItemState(H(IDC_LIST), sel, LVIS_SELECTED | LVIS_FOCUSED,
                                  LVIS_SELECTED | LVIS_FOCUSED);
            ApplyConfigToEngine();
            SaveSoon(hwnd);
            break;
        }
        case IDC_TRY: {
            int sel = ListView_GetNextItem(H(IDC_LIST), -1, LVNI_SELECTED);
            if (sel < 0 || sel >= (int)g_cfg.rules.size()) {
                MessageBoxW(hwnd, L"先在列表里点一条规则。", KS_APP_NAME, MB_OK | MB_ICONINFORMATION);
                break;
            }
            EngineFireRule((size_t)sel);
            LogAppend(L"[试一下] 手动执行：" + HotkeyToString(g_cfg.rules[sel].src) + L"  →  已发出");
            break;
        }
        case IDC_VOICE_TEST:
            if (g_cfg.vtrigger == VT_HOLD) EngineDoVoiceHoldStart();
            else EngineDoVoiceToggle();
            LogAppend(L"[试一下] 已把语音输入的组合键发出去");
            break;
        case IDC_MONITOR:
            g_cfg.monitor = Button_GetCheck(H(IDC_MONITOR)) == BST_CHECKED ? 1 : 0;
            EngineSetMonitor(g_cfg.monitor != 0);
            LogAppend(g_cfg.monitor ? L"—— 按键监视已打开 ——" : L"—— 按键监视已关闭 ——");
            SaveSoon(hwnd);
            break;
        case IDC_HK_VOICE:
            g_capWhich = 1;
            SetWindowTextW(H(IDC_HK_VOICE), L"请按组合键…（Esc 取消）");
            EngineBeginCapture(hwnd);
            break;
        case IDC_HK_CTOGGLE:
            g_capWhich = 2;
            SetWindowTextW(H(IDC_HK_CTOGGLE), L"请按组合键…（Esc 取消）");
            EngineBeginCapture(hwnd);
            break;
        case IDC_HK_CHOLD:
            g_capWhich = 3;
            SetWindowTextW(H(IDC_HK_CHOLD), L"请按组合键…（Esc 取消）");
            EngineBeginCapture(hwnd);
            break;
        case IDC_RELOAD: {
            Config c;
            bool existed = false;
            ConfigLoad(g_iniPath, c, &existed);
            g_cfg = c;
            ApplyConfigToEngine();
            EngineSetEnabled(EngineIsEnabled());
            SyncUIFromConfig();
            LogAppend(L"[配置] 已从文件重新载入，共 " + FormatW(L"%d", (int)g_cfg.rules.size()) + L" 条规则");
            break;
        }
        case IDC_OPEN_INI:
            ShellExecuteW(hwnd, L"open", L"notepad.exe", (L"\"" + g_iniPath + L"\"").c_str(), NULL, SW_SHOW);
            break;
        case IDC_OPEN_DIR:
            ShellExecuteW(hwnd, L"open", ExeDir().c_str(), NULL, NULL, SW_SHOW);
            break;
        case 100: SendMessageW(hwnd, WM_COMMAND, IDC_RELOAD, 0); break;
        case 101: SendMessageW(hwnd, WM_COMMAND, IDC_OPEN_INI, 0); break;
        case 102: SendMessageW(hwnd, WM_COMMAND, IDC_OPEN_DIR, 0); break;
        case 103: SaveConfigNow(); DestroyWindow(hwnd); break;
        case 200: {
            bool on = !EngineIsEnabled();
            EngineSetEnabled(on);
            Button_SetCheck(H(IDC_ENABLED), on ? BST_CHECKED : BST_UNCHECKED);
            UpdateStatus();
            break;
        }
        case 201: EngineResetStats(); UpdateStatus(); LogAppend(L"[统计] 已清零"); break;
        case 300:
            MessageBoxW(hwnd,
                L"怎么用（三步）：\r\n"
                L"1. 在「快捷键替换」页点「添加规则」。\r\n"
                L"2. 点「点这里录制」，按下你记不住的那个复杂快捷键；\r\n"
                L"   再点右边那个，按下你想用它代替的简单键。\r\n"
                L"3. 关掉本窗口就行（它会缩到右下角托盘继续干活）。\r\n\r\n"
                L"语音输入：\r\n"
                L"「语音输入」页里录一个热键（默认 F9）。按一下就说话，\r\n"
                L"说完再按一下结束，或者按 Esc 关掉语音条。\r\n\r\n"
                L"想临时全部关掉：右键托盘的图标 → 暂停所有替换。\r\n"
                L"想彻底退出：右键托盘的图标 → 退出。",
                L"使用说明", MB_OK | MB_ICONINFORMATION);
            break;
        case 301:
            MessageBoxW(hwnd,
                (KS_APP_NAME L" v" KS_VERSION_FULL L"\r\n\r\n"
                 L"一个用 C++ 写的 Windows 小工具：\r\n"
                 L"把各种记不住的复杂快捷键，换成你顺手的样子；\r\n"
                 L"顺手也把「电脑上按一下就能说话」这件事办了。\r\n\r\n"
                 L"不写注册表、不装驱动、不联网，就一个 exe。\r\n"
                 L"设置全在同目录的 " KS_INI_NAME L" 里，删掉就恢复默认。\r\n\r\n"
                 L"配置文件：" + g_iniPath).c_str(),
                L"关于", MB_OK | MB_ICONINFORMATION);
            break;
    }
    (void)code;
}

static LRESULT CALLBACK MainProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp) {
    switch (msg) {
        case WM_CREATE:
            g_main = hwnd;
            BuildUI(hwnd);
            TrayAdd();
            SyncUIFromConfig();
            LogAppend(L"—— " KS_APP_NAME L" v" KS_VERSION L" 已启动 ——");
            return 0;

        case WM_COMMAND:
            OnCommand(hwnd, LOWORD(wp), HIWORD(wp));
            return 0;

        case WM_NOTIFY: {
            NMHDR* nh = (NMHDR*)lp;
            if (nh->idFrom == IDC_TAB && nh->code == TCN_SELCHANGE) {
                ShowTab(TabCtrl_GetCurSel(H(IDC_TAB)));
            } else if (nh->idFrom == IDC_LIST && nh->code == NM_DBLCLK) {
                SendMessageW(hwnd, WM_COMMAND, IDC_EDIT, 0);
            }
            break;
        }

        case WM_KS_CAPTURE: {
            Hotkey hk = UnpackHotkey(wp);
            if (lp == 0) {
                SyncUIFromConfig();
                g_capWhich = 0;
                break;
            }
            if (g_capWhich == 1) {
                if (hk.Valid()) g_cfg.voiceKey = hk;
                SetWindowTextW(H(IDC_HK_VOICE), HotkeyToString(g_cfg.voiceKey).c_str());
            } else if (g_capWhich == 2) {
                g_cfg.customToggle = hk;
                SetWindowTextW(H(IDC_HK_CTOGGLE), HotkeyToString(hk).c_str());
            } else if (g_capWhich == 3) {
                g_cfg.customHold = hk;
                SetWindowTextW(H(IDC_HK_CHOLD), HotkeyToString(hk).c_str());
            }
            g_capWhich = 0;
            ApplyConfigToEngine();
            SaveSoon(hwnd);
            break;
        }

        case WM_KS_KEYLOG: {
            std::wstring* s = (std::wstring*)wp;
            if (s) { LogAppend(*s); delete s; }
            return 0;
        }

        case WM_KS_TRAY:
            switch ((UINT)lp) {
                case WM_LBUTTONUP:
                case WM_LBUTTONDBLCLK:
                    ShowMainWindow();
                    break;
                case WM_RBUTTONUP:
                case WM_CONTEXTMENU:
                    TrayMenu();
                    break;
            }
            return 0;

        case WM_TIMER:
            if (wp == IDT_SAVE) {
                KillTimer(hwnd, IDT_SAVE);
                bool ap = false;
                ReadUIToConfig(&ap);
                SaveConfigNow();
                UpdateStatus();
            } else if (wp == IDT_SAVE + 1) {
                UpdateStatus();
            }
            return 0;

        case WM_CLOSE:
            HideToTray();
            return 0;

        case WM_QUERYENDSESSION:
            SaveConfigNow();
            return TRUE;

        case WM_ENDSESSION:
            if (wp) { SaveConfigNow(); EngineStop(); }
            return 0;

        case WM_DESTROY:
            SaveConfigNow();
            TrayRemove();
            EngineStop();
            PostQuitMessage(0);
            return 0;
    }
    return DefWindowProcW(hwnd, msg, wp, lp);
}

/* ------------------------------------------------------------ 对外入口 */

static bool g_forceTestMode = false;
void GuiForceTestMode(bool on) { g_forceTestMode = on; }

HWND GuiCreateMain(HINSTANCE hInst) {
    g_inst = hInst;

    /* 字体 & DPI */
    HDC hdc = GetDC(NULL);
    g_dpi = GetDeviceCaps(hdc, LOGPIXELSY);
    ReleaseDC(NULL, hdc);
    if (g_dpi < 96) g_dpi = 96;

    NONCLIENTMETRICSW ncm;
    ZeroMemory(&ncm, sizeof(ncm));
    ncm.cbSize = sizeof(ncm);
    if (SystemParametersInfoW(SPI_GETNONCLIENTMETRICS, sizeof(ncm), &ncm, 0)) {
        LOGFONTW lf = ncm.lfMessageFont;
        lf.lfHeight = -MulDiv(9, g_dpi, 72);
        wcscpy(lf.lfFaceName, L"Microsoft YaHei UI");
        g_font = CreateFontIndirectW(&lf);
    }
    if (!g_font) g_font = (HFONT)GetStockObject(DEFAULT_GUI_FONT);

    WNDCLASSEXW wc;
    ZeroMemory(&wc, sizeof(wc));
    wc.cbSize = sizeof(wc);
    wc.style = CS_HREDRAW | CS_VREDRAW;
    wc.lpfnWndProc = MainProc;
    wc.hInstance = hInst;
    wc.hCursor = LoadCursorW(NULL, IDC_ARROW);
    wc.hbrBackground = (HBRUSH)(COLOR_BTNFACE + 1);
    wc.lpszClassName = KS_WNDCLASS;
    wc.hIcon = (HICON)LoadImageW(hInst, MAKEINTRESOURCEW(101), IMAGE_ICON, 32, 32, 0);
    wc.hIconSm = (HICON)LoadImageW(hInst, MAKEINTRESOURCEW(101), IMAGE_ICON, 16, 16, 0);
    if (!wc.hIcon) wc.hIcon = LoadIconW(NULL, IDI_APPLICATION);
    if (!wc.hIconSm) wc.hIconSm = LoadIconW(NULL, IDI_APPLICATION);
    if (!RegisterClassExW(&wc)) return NULL;

    g_iniPath = ExeDir() + L"\\" + KS_INI_NAME;

    bool existed = false;
    ConfigLoad(g_iniPath, g_cfg, &existed);
    if (!existed) ConfigSave(g_iniPath, g_cfg);
    if (g_forceTestMode) g_cfg.testMode = 1;
    /* 让注册表里的自启项和配置文件保持一致（配置文件里关掉了就一并删掉） */
    StartupSet(g_cfg.startup);

    int clientW = S(800), clientH = S(604);
    RECT rc;
    rc.left = 0; rc.top = 0; rc.right = clientW; rc.bottom = clientH;
    AdjustWindowRectEx(&rc, WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX, TRUE, 0);
    int W = rc.right - rc.left, Hh = rc.bottom - rc.top;
    int sw = GetSystemMetrics(SM_CXSCREEN), sh = GetSystemMetrics(SM_CYSCREEN);
    HWND h = CreateWindowExW(0, KS_WNDCLASS, KS_APP_NAME L"  v" KS_VERSION,
                             WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX,
                             (sw - W) / 2, (sh - Hh) / 2, W, Hh,
                             NULL, NULL, hInst, NULL);
    if (!h) return NULL;

    EngineApplyConfig(g_cfg);
    EngineSetEnabled(g_cfg.enabledAll);
    if (!EngineStart(h)) {
        /* 钩子装不上也要能用界面 */
    }
    /* 钩子状态必须在 EngineStart 之后才判断，否则会误报「没装上」 */
    LogAppend(EngineHooked() ? L"键盘钩子已装上，替换规则生效中。"
                             : L"⚠ 键盘钩子没装上！请试试右键 exe → 以管理员身份运行。");
    SetTimer(h, IDT_SAVE + 1, 1000, NULL);
    return h;
}

int GuiRun() {
    MSG msg;
    while (GetMessageW(&msg, NULL, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessageW(&msg);
    }
    return (int)msg.wParam;
}

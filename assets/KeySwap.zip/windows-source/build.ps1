# Build KeySwap v2.1 (Windows) — TDM-GCC / mingw-w64, 64-bit
#
# Put this file in the same folder as the .cpp/.h sources and run it:
#     powershell -NoProfile -ExecutionPolicy Bypass -File build.ps1
#
# Two things this script works around, both worth knowing:
#   1. The GCC install lives under "C:\Program Files (x86)\..." and windres
#      cannot spawn its preprocessor from a path containing spaces, so we use
#      the 8.3 short path (C:\PROGRA~2\...).
#   2. windres replaces its default "gcc -E" only if you hand it the whole
#      command, but PowerShell 5.1 cannot pass a single argument containing a
#      space. So we point --preprocessor at a tiny wrapper .bat that adds -E.

$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$full = 'C:\Program Files (x86)\Embarcadero\Dev-Cpp\TDM-GCC-64'

if (-not (Test-Path $full)) {
    Write-Output "TDM-GCC not found at: $full"
    Write-Output "Install Dev-C++ / TDM-GCC, or edit \$full above."
    exit 1
}

# 8.3 short path, no spaces
$fso   = New-Object -ComObject Scripting.FileSystemObject
$bin   = (Join-Path ($fso.GetFolder($full).ShortPath) 'bin')
$wr    = Join-Path $bin 'windres.exe'
$gxx   = Join-Path $bin 'g++.exe'
$wrap  = Join-Path $here 'gccE.bat'

function RunExe($exe, $argList, $tag) {
    $out = Join-Path $here "$tag.out.txt"
    $err = Join-Path $here "$tag.err.txt"
    Remove-Item $out, $err -ErrorAction SilentlyContinue
    $p = Start-Process -FilePath $exe -ArgumentList $argList -NoNewWindow -Wait -PassThru `
                       -RedirectStandardOutput $out -RedirectStandardError $err
    $o = ''; $e = ''
    if (Test-Path $out) { $o = [System.IO.File]::ReadAllText($out) }
    if (Test-Path $err) { $e = [System.IO.File]::ReadAllText($err) }
    return @{ Code = $p.ExitCode; Out = $o; Err = $e }
}

# ---- 0. preprocessor wrapper for windres ----------------------------------
[System.IO.File]::WriteAllText($wrap, "@echo off`r`n`"$bin\gcc.exe`" -E -xc %*`r`n")

# ---- 1. resources (icon + manifest + version info) ------------------------
$res = Join-Path $here 'res.o'
Remove-Item $res -ErrorAction SilentlyContinue
$r = RunExe $wr @("--preprocessor=$wrap", '--codepage=65001', '-I', $here,
                  (Join-Path $here 'resource.rc'), '-O', 'coff', '-o', $res) 'windres'
Write-Output ("windres exit={0}  res.o={1}" -f $r.Code, (Test-Path $res))
if ($r.Code -ne 0) { Write-Output $r.Err }

# ---- 2. compile + link ----------------------------------------------------
$exe = Join-Path $here 'KeySwap.exe'
Remove-Item $exe -ErrorAction SilentlyContinue

$sources = @('ks_main.cpp', 'ks_gui.cpp', 'ks_engine.cpp', 'ks_core.cpp') |
           ForEach-Object { Join-Path $here $_ }
$argumentList = @(
    '-std=c++17', '-O2', '-Wall',
    '-mwindows', '-static', '-static-libgcc', '-static-libstdc++',
    '-DUNICODE', '-D_UNICODE', '-D_WIN32_IE=0x0601',
    '-I', $here
) + $sources + @(
    $res, '-o', $exe,
    '-lcomctl32', '-lshell32', '-luser32', '-lgdi32', '-ladvapi32', '-lole32', '-loleaut32'
)

$b = RunExe $gxx $argumentList 'gcc'
Write-Output ("g++ exit={0}" -f $b.Code)
if ($b.Err) { Write-Output "--- compiler diagnostics ---"; Write-Output $b.Err }

if (Test-Path $exe) {
    Write-Output ("BUILD OK: {0}  {1} bytes" -f $exe, (Get-Item $exe).Length)
} else {
    Write-Output 'BUILD FAILED: no exe produced'
}

# ---- 3. self test ---------------------------------------------------------
if (Test-Path $exe) {
    $rep = Join-Path $here 'selftest_report.txt'
    Remove-Item $rep -ErrorAction SilentlyContinue
    $t = Start-Process -FilePath $exe -ArgumentList @('--selftest', $rep) -NoNewWindow -Wait -PassThru
    if (Test-Path $rep) {
        Write-Output ("--- self test (exit={0}) ---" -f $t.ExitCode)
        Write-Output ([System.IO.File]::ReadAllText($rep, [System.Text.Encoding]::UTF8))
    }
}

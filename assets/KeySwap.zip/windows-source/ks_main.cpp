/* ==========================================================================
   快捷键更换助手 (KeySwap)  v2.1  —  程序入口 / 单实例 / 自检
   ========================================================================== */
#include "ks.h"

#include <cstdio>
#include <cstdlib>
#include <cwchar>
#include <cstring>

void GuiForceTestMode(bool on);
HWND GuiCreateMain(HINSTANCE hInst);
int  GuiRun();

/* ----------------------------------------------------------- 写测试报告 */

static bool WriteFileUtf8(const std::wstring& path, const std::wstring& text) {
    std::string body = WToUtf8(text);
    std::string all;
    all.append("\xEF\xBB\xBF", 3);
    all += body;
    HANDLE h = CreateFileW(path.c_str(), GENERIC_WRITE, 0, NULL,
                           CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    if (h == INVALID_HANDLE_VALUE) return false;
    DWORD wr = 0;
    if (!all.empty()) WriteFile(h, all.data(), (DWORD)all.size(), &wr, NULL);
    CloseHandle(h);
    return true;
}

static int  g_fails = 0;
static std::wstring g_rep;

static void Check(bool ok, const std::wstring& what) {
    g_rep += (ok ? L"[OK]    " : L"[FAIL]  ");
    g_rep += what;
    g_rep += L"\r\n";
    if (!ok) g_fails++;
}

/* --------------------------------------------------------------- 自检 */

static int RunSelfTest(const std::wstring& outFile) {
    g_rep = L"快捷键更换助手 KeySwap v" KS_VERSION_FULL L"  自检报告\r\n";
    g_rep += L"exe: " + ExePath() + L"\r\n\r\n";

    /* ---- 1. 键名解析 / 格式化 来回转换 ---- */
    struct ChordCase { const wchar_t* s; bool hasKey; };
    const ChordCase chords[] = {
        { L"F9", true },          { L"F1", true },          { L"F24", true },
        { L"Ctrl+Alt+K", true },  { L"Ctrl+Win+Shift", false }, { L"Ctrl+Win", false },
        { L"Win+H", true },       { L"Ctrl+Shift+A", true },{ L"Alt+F4", true },
        { L"Ctrl+Alt+Delete", true }, { L"Shift+空格", true }, { L"Ctrl+小键盘0", true },
        { L"Ctrl+小键盘9", true },{ L"Ctrl+左", true },     { L"CapsLock", true },
        { L"Esc", true },         { L"Ctrl+`", true },      { L"Ctrl+分号", true },
        { L"Alt+回车", true },    { L"Ctrl+删除", true },   { L"Ctrl+Alt+Shift+Win", false },
        { L"Ctrl+PgUp", true },   { L"Shift+Home", true },  { L"Ctrl+PrintScreen", true }
    };
    for (int i = 0; i < (int)(sizeof(chords) / sizeof(chords[0])); i++) {
        Hotkey a, b;
        bool ok1 = StringToHotkey(chords[i].s, a);
        std::wstring back = HotkeyToString(a);
        bool ok2 = StringToHotkey(back, b);
        /* 主键该有的必须有；两个方向都要一致 */
        bool keyOk = chords[i].hasKey ? (a.vk != 0) : (a.vk == 0);
        /* 显示出来的字符串不能有末尾加号、双加号这种难看的东西 */
        bool  fmtOk = back.find(L"++") == std::wstring::npos &&
                      (back.empty() || back[back.size() - 1] != L'+');
        Check(ok1 && ok2 && a == b && keyOk && fmtOk,
              std::wstring(L"键名来回转换：") + chords[i].s + L"  →  " + back +
              (keyOk ? L"" : L"   [主键丢了!]") + (ok2 && a == b ? L"" : L"   [解析不一致!]"));
    }

    /* ---- 2. 组合键只写修饰键（微信「按住说话」那种） ---- */
    {
        Hotkey hk;
        bool ok = StringToHotkey(L"Ctrl+Win", hk);
        Check(ok && hk.vk == 0 && hk.mods == (KM_CTRL | KM_WIN),
              L"仅修饰键的组合键解析：Ctrl+Win → mods=" + FormatW(L"%d", (int)hk.mods));
    }

    /* ---- 3. 空快捷键 ---- */
    {
        Hotkey hk;
        Check(!hk.Valid() && HotkeyToString(hk) == L"（未设置）", L"空快捷键显示为「未设置」");
    }

    /* ---- 4. 配置存盘 / 读回 一致性 ---- */
    {
        std::wstring tmp = ExeDir() + L"\\__selftest.ini";
        DeleteFileW(tmp.c_str());

        Config a;
        ConfigDefault(a);
        a.rules.clear();
        Rule r1;
        r1.enabled = true;
        StringToHotkey(L"Ctrl+Alt+K", r1.src);
        StringToHotkey(L"F5", r1.dst);
        r1.act = ACT_SWAP;
        r1.note = L"中文备注：测试用 ✓ 123";
        a.rules.push_back(r1);

        Rule r2;
        r2.enabled = false;
        StringToHotkey(L"CapsLock", r2.src);
        r2.act = ACT_BLOCK;
        r2.note = L"屏蔽掉大写锁定";
        a.rules.push_back(r2);

        Rule r3;
        r3.enabled = true;
        StringToHotkey(L"Ctrl+Alt+V", r3.src);
        r3.act = ACT_VOICE;
        r3.note = L"";
        a.rules.push_back(r3);

        a.voiceKey = Hotkey(0, VK_F9);
        a.provider = VP_WINDOWS;
        a.vtrigger = VT_HOLD;
        a.customToggle = Hotkey(KM_CTRL | KM_WIN | KM_SHIFT, 0);
        a.chordHoldMs = 155;
        a.gapMs = 35;
        a.startup = true;
        a.monitor = 0;
        StringToHotkey(L"Ctrl+Alt+M", a.customHold);

        Check(ConfigSave(tmp, a), L"配置写盘成功");

        Config b;
        bool existed = false;
        ConfigLoad(tmp, b, &existed);
        Check(existed, L"配置读回：文件存在");
        Check(b.rules.size() == 3, L"配置读回：规则条数 = " + FormatW(L"%d", (int)b.rules.size()));

        bool same = b.rules.size() == 3;
        if (same) {
            same = b.rules[0].enabled && b.rules[0].act == ACT_SWAP
                && b.rules[0].src == a.rules[0].src && b.rules[0].dst == a.rules[0].dst
                && b.rules[0].note == a.rules[0].note;
            Check(same, L"配置读回：第 1 条（含中文备注）完全一致");
            Check(!b.rules[1].enabled && b.rules[1].act == ACT_BLOCK
                  && b.rules[1].src == a.rules[1].src,
                  L"配置读回：第 2 条（屏蔽 + 停用）一致");
            Check(b.rules[2].act == ACT_VOICE && b.rules[2].src == a.rules[2].src,
                  L"配置读回：第 3 条（语音）一致");
        }
        Check(b.voiceKey == a.voiceKey && b.provider == a.provider && b.vtrigger == a.vtrigger,
              L"配置读回：语音设置一致");
        Check(b.chordHoldMs == 155 && b.gapMs == 35, L"配置读回：按住时长/间隔一致");
        Check(b.customToggle == a.customToggle && b.customHold == a.customHold,
              L"配置读回：自定义组合键一致");
        Check(b.startup == true, L"配置读回：开机自启一致");

        /* ---- 5. 文件确实是 UTF-8 BOM ---- */
        HANDLE h = CreateFileW(tmp.c_str(), GENERIC_READ, FILE_SHARE_READ, NULL,
                               OPEN_EXISTING, 0, NULL);
        bool bom = false, hasCn = false;
        if (h != INVALID_HANDLE_VALUE) {
            DWORD sz = GetFileSize(h, NULL);
            std::string buf;
            buf.resize(sz);
            DWORD rd = 0;
            ReadFile(h, &buf[0], sz, &rd, NULL);
            CloseHandle(h);
            buf.resize(rd);
            bom = buf.size() > 3 && (unsigned char)buf[0] == 0xEF
                  && (unsigned char)buf[1] == 0xBB && (unsigned char)buf[2] == 0xBF;
            hasCn = buf.find("中文备注") != std::string::npos;
        }
        Check(bom, L"配置文件带 UTF-8 BOM（记事本不乱码）");
        Check(hasCn, L"中文备注按 UTF-8 正确写入");

        /* ---- 6. 容错：乱文件不应崩 ---- */
        std::wstring bad = ExeDir() + L"\\__selftest_bad.ini";
        WriteFileUtf8(bad,
            L"[规则\r\nFrom=这不是键\r\nEnabled=abc\r\n\r\n[全局\r\nChordHoldMs=999999\r\n");
        Config c;
        bool e2 = false;
        ConfigLoad(bad, c, &e2);
        Check(e2 && c.rules.empty(), L"容错：乱七八糟的配置不会崩，坏规则被丢掉");
        Check(c.chordHoldMs >= 20 && c.chordHoldMs <= 2000,
              L"容错：越界的按住时长被夹回合法范围 (" + FormatW(L"%d", c.chordHoldMs) + L")");

        DeleteFileW(bad.c_str());
        DeleteFileW(tmp.c_str());
    }

    /* ---- 7. 缺文件时的默认值 ---- */
    {
        std::wstring none = ExeDir() + L"\\__no_such_file_91.ini";
        DeleteFileW(none.c_str());
        Config c;
        bool existed = true;
        ConfigLoad(none, c, &existed);
        Check(!existed, L"缺配置时不报错，走默认值");
        Check(c.rules.size() >= 2, L"默认配置自带示例规则 " + FormatW(L"%d", (int)c.rules.size()) + L" 条");
        bool allOff = true;
        for (size_t i = 0; i < c.rules.size(); i++) if (c.rules[i].enabled) allOff = false;
        Check(allOff, L"默认示例规则全部是「停用」状态（不会打扰用户）");
        Check(c.voiceEnabled && c.voiceKey.vk == VK_F9, L"默认语音热键是 F9 且已启用");
        Check(c.provider == VP_WEIXIN, L"默认语音来源是电脑版微信");
        Check(c.enabledAll, L"默认总开关是开着的");
    }

    /* ---- 8. 开机自启读注册表 ---- */
    {
        bool st = StartupIsEnabled();
        g_rep += L"[OK]    开机自启状态可读取：" + std::wstring(st ? L"已开启" : L"未开启") + L"\r\n";
    }

    g_rep += L"\r\n=====================================\r\n";
    g_rep += (g_fails == 0) ? L"全部通过 ✔\r\n"
                            : (L"有 " + FormatW(L"%d", g_fails) + L" 项没通过 ✘\r\n");

    if (!outFile.empty()) WriteFileUtf8(outFile, g_rep);
    /* 有控制台就顺便打印一份 */
    if (AttachConsole(ATTACH_PARENT_PROCESS)) {
        HANDLE ho = GetStdHandle(STD_OUTPUT_HANDLE);
        if (ho && ho != INVALID_HANDLE_VALUE) {
            std::string u = WToUtf8(g_rep);
            DWORD wr = 0;
            WriteFile(ho, u.data(), (DWORD)u.size(), &wr, NULL);
        }
        FreeConsole();
    }
    return g_fails == 0 ? 0 : 1;
}

/* --------------------------------------------------------------- 入口 */

int WINAPI WinMain(HINSTANCE hInst, HINSTANCE hPrev, LPSTR lpCmdLine, int nCmdShow) {
    (void)hPrev; (void)lpCmdLine;

    std::wstring cmd = GetCommandLineW();

    /* ---- 自检模式：KeySwap.exe --selftest [报告文件] ---- */
    if (cmd.find(L"--selftest") != std::wstring::npos) {
        std::wstring out;
        size_t p = cmd.find(L"--selftest");
        size_t q = cmd.find(L' ', p);
        if (q != std::wstring::npos) {
            out = TrimW(cmd.substr(q + 1));
            if (!out.empty() && out[0] == L'"') {
                size_t e = out.find(L'"', 1);
                if (e != std::wstring::npos) out = out.substr(1, e - 1);
            }
        }
        return RunSelfTest(out);
    }

    /* ---- 单实例 ---- */
    HANDLE mtx = CreateMutexW(NULL, TRUE, KS_MUTEX_NAME);
    if (mtx && GetLastError() == ERROR_ALREADY_EXISTS) {
        HWND old = FindWindowW(KS_WNDCLASS, NULL);
        if (old) {
            ShowWindow(old, SW_SHOW);
            ShowWindow(old, SW_RESTORE);
            SetForegroundWindow(old);
        } else {
            MessageBoxW(NULL, L"快捷键更换助手已经在运行了（看右下角托盘图标）。",
                        KS_APP_NAME, MB_OK | MB_ICONINFORMATION);
        }
        return 0;
    }

    SetProcessDPIAware();

    INITCOMMONCONTROLSEX icc;
    icc.dwSize = sizeof(icc);
    icc.dwICC = ICC_LISTVIEW_CLASSES | ICC_BAR_CLASSES | ICC_TAB_CLASSES |
                ICC_STANDARD_CLASSES | ICC_WIN95_CLASSES;
    InitCommonControlsEx(&icc);

    if (cmd.find(L"--testmode") != std::wstring::npos) GuiForceTestMode(true);

    HWND wnd = GuiCreateMain(hInst);
    if (!wnd) {
        MessageBoxW(NULL, L"窗口创建失败，程序无法启动。", KS_APP_NAME, MB_OK | MB_ICONERROR);
        return 1;
    }
    ShowWindow(wnd, nCmdShow == 0 ? SW_SHOWNORMAL : nCmdShow);
    UpdateWindow(wnd);

    int r = GuiRun();
    if (mtx) CloseHandle(mtx);
    return r;
}

﻿# 源码说明（Windows 版）

## 目录
  ks.h            公共类型 / 按键名表 / 引擎接口
  ks_core.cpp     按键名解析、配置文件读写、开机自启
  ks_engine.cpp   低级键盘钩子、规则匹配、按键注入、热键录制、按键监视
  ks_gui.cpp      Win32 图形界面（三个标签页）+ 托盘 + 主消息循环
  ks_main.cpp     程序入口、单实例、--selftest 自检
  resource.rc     图标 / 清单 / 版本信息
  app.manifest    comctl32 v6 + DPI 感知 + 支持的系统列表
  app.ico         程序图标（8 种尺寸）
  build.ps1       一键编译脚本

## 编译
这台机器上用的是 Dev-C++ 自带的 TDM-GCC 9.2.0（在
C:\Program Files (x86)\Embarcadero\Dev-Cpp\TDM-GCC-64），
不需要装 Visual Studio，也不需要 .NET SDK。

    powershell -NoProfile -ExecutionPolicy Bypass -File build.ps1

脚本会自己编译资源、链接、然后跑一遍内置自检并打印结果。
产物是同目录的 KeySwap.exe（单文件、静态链接，不依赖任何运行库）。

## 两个值得记住的坑
1. windres 从带空格的路径里调不起预处理器，所以脚本先取 8.3 短路径
   (C:\PROGRA~2\...)。
2. windres 只有在你自己给出完整命令时才会替换默认的 "gcc -E"，
   而 PowerShell 5.1 没法传递带空格的单个参数 —— 所以脚本生成一个
   小 .bat 包一层，由它补上 -E。

## 想自己改的话
  · 加一种新的规则动作 → 改 ActionKind + ks_engine.cpp 的 DoFire
  · 改界面文字 / 布局   → ks_gui.cpp 的 BuildUI（坐标都是 96dpi 下的值，
                          程序会按实际 DPI 自动缩放）
  · 加新的组合键名字    → ks_core.cpp 的 kNameTable

## 测试脚本（dev-scripts/）
  KeyTest.cpp     键盘事件探针 + 模拟按键注入，用来做端到端验证
  e2etest.ps1     端到端测试：验证「源按键被吞掉、目标按键被发出来」
  systest.ps1     系统级测试：开机自启、托盘、单实例、配置持久化
# 快捷键更换助手 KeySwap v2.1 — macOS 版说明

## 先说清楚：这份代码没有在 Mac 上验证过

配套的 Windows 版是真机测过的（自检 + 端到端拦截测试 + 真实微信语音实测）。
macOS 这份**只是按官方 API 写的原生实现，我没有 Mac 可以编译和运行**。
所以请把它当作「可用的起点」，而不是「开箱即用的成品」。

如果你只是想马上在 Mac 上把键位换掉，成熟方案是：

| 工具 | 适合谁 | 说明 |
|---|---|---|
| **Karabiner-Elements** | 想要稳定、功能全 | 开源，专门做键位重映射，社区活跃 |
| **Hammerspoon** | 愿意写点 Lua | 用 `hs.hotkey` 做热键、`hs.eventtap` 做拦截 |
| **skhd** | 只要简单热键 | 配置文件极简 |

本文件的价值在于：**不依赖任何第三方框架，而且和 Windows 版共用同一份 `KeySwap.ini`**，
你在这台电脑上配好的规则可以原样拷到 Mac 上用（注意修饰键名字对应关系）。

## 编译

需要 Xcode 命令行工具：

```bash
xcode-select --install
make
```

如果 `make` 报错，多半是某个常量名的拼写差异，改一下即可（例如 Carbon 头文件里
`kVK_Control` / `kVK_Option` 这类常量名在不同 SDK 版本里偶有差别）。

## 运行与授权（这一步不能跳）

```bash
./KeySwap
```

1. 启动后菜单栏会出现一个 **⇄** 图标。
2. 首次运行会在「系统设置 → 隐私与安全性 → 辅助功能」里要求授权，
   请把 **KeySwap** 勾上。没有这个权限，`CGEventTap` 收不到任何按键。
3. **授权之后必须重启程序**，否则 tap 仍然创建失败（终端会打印提示）。
4. 如果重启后还是没反应，检查一下有没有别的工具（如 Karabiner）抢占按键事件。

## 配置文件

与 Windows 版同名同格式，放在**程序同目录**的 `KeySwap.ini`：

```ini
[general]
Enabled=1
ChordHoldMs=130
GapMs=25

[voice]
Enabled=1
Key=F9
Provider=system      ; system = 连按两下 Control 触发系统听写
                     ; fn     = 连按两下 🌐/Fn 键
                     ; custom = 用下面两个自定义组合键
Trigger=toggle
CustomToggle=Ctrl+Shift+D
CustomHold=Ctrl+Shift+D

[rule]
Enabled=1
From=Ctrl+Alt+K
Mode=swap
To=F5
Note=把 Ctrl+Alt+K 换成 F5

[rule]
Enabled=1
From=Ctrl+Alt+Q
Mode=block
Note=屏蔽 Ctrl+Alt+Q
```

`Mode` 三种取值：`swap`（换成别的键）、`voice`（触发语音输入）、`block`（直接屏蔽）。

## 修饰键对照

Windows 版和 macOS 版共用同一份配置，所以键名做了统一映射：

| 配置里写 | Windows 上是 | macOS 上是 |
|---|---|---|
| `Ctrl`  | Ctrl  | Control |
| `Alt`   | Alt   | Option (⌥) |
| `Shift` | Shift | Shift |
| `Win`   | Win   | Command (⌘) |

也就是说，配置里写 `Win+H`，在 Mac 上发出去的就是 `Command+H`。

## macOS 上的语音输入怎么触发

macOS 自带听写（系统设置 → 键盘 → 听写）默认手势是**连按两下 Control**
（部分机型是连按两下 🌐/Fn 键）。所以：

- `Provider=system` 时，本程序会帮你「连按两下 Control」；
- 如果听写的手势你改成别的了，就用 `Provider=custom`，
  把 `CustomToggle` 设成你实际用的那个组合键。

注意：听写是**开关型**手势，所以「按住说话」模式在系统听写下会退化成「点一下」。

## 已知限制

- 未在真机验证，可能还需要小改。
- 菜单栏只提供：暂停/恢复、打开配置、重新载入、退出。没有 Windows 版那样的图形规则编辑器
  —— 直接编辑 `KeySwap.ini` 即可（改完用菜单里的「重新载入配置」）。
- 需要「辅助功能」权限；企业管控的 Mac 上可能装不了。
- 规则的「按键注入」放在后台串行队列执行，避免阻塞事件回调（回调阻塞会被系统摘掉 tap）。

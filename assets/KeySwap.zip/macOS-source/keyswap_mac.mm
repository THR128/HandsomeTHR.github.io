/* ==========================================================================
   快捷键更换助手 (KeySwap)  v2.1  —  macOS 版
   --------------------------------------------------------------------------
   用 CGEventTap 实现「按下 X → 变成 Y」的全局快捷键替换，
   外加「按一下热键就能说话」（调用 macOS 自带听写）。

   ⚠ 重要说明（请务必读完再动手）
   本文件是为 macOS 编写的原生实现，但**没有在真机上编译和运行过** ——
   开发这套工具的这台电脑是 Windows，手上没有 Mac。
   所以：语法和 API 用法都按官方文档写，但可能还需要你或懂行的朋友
   在 Mac 上编译一次、按报错微调。除此之外的替代方案是：
     · Karabiner-Elements（开源，专门做键位重映射，成熟稳定）
     · Hammerspoon / skhd（脚本化热键）
   如果你只想要「能用」，优先考虑上面这些；本文件的价值是不依赖第三方
   框架、一份配置两边通用。

   编译（需要 Xcode 命令行工具：在终端执行 xcode-select --install）
       make
   运行
       ./KeySwap
   首次运行会申请「辅助功能」权限：
       系统设置 → 隐私与安全性 → 辅助功能 → 勾上 KeySwap
   授权后**需要重启本程序**才生效（CGEventTap 必须在授权后创建）。

   配置文件
       与 Windows 版同名同格式：KeySwap.ini，放在程序同目录。
       修饰键对应关系：Ctrl→Control，Alt→Option，Shift→Shift，Win→Command
   ========================================================================== */

#import <Cocoa/Cocoa.h>
#import <Carbon/Carbon.h>
#import <ApplicationServices/ApplicationServices.h>
#include <CoreGraphics/CoreGraphics.h>

#include <string>
#include <vector>
#include <fstream>
#include <sstream>
#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <unistd.h>

/* ------------------------------------------------------------------ 常量 */

static const uint32_t KS_MAGIC = 0x4B535750;   /* 'KSWP'，标记我们自己发出的按键 */

enum { KM_CTRL = 1, KM_ALT = 2, KM_SHIFT = 4, KM_WIN = 8 };  /* Win 在 Mac 上 = Command */

enum ActionKind { ACT_SWAP = 0, ACT_VOICE = 1, ACT_BLOCK = 2 };
enum VoiceTrigger { VT_TOGGLE = 0, VT_HOLD = 1 };
enum VoiceProvider { VP_MAC_SYSTEM = 0, VP_MAC_FN = 1, VP_CUSTOM = 2 };

struct Hotkey {
    unsigned mods = 0;
    unsigned vk = 0;          /* 这里存的是 macOS 的虚拟键码 (kVK_xxx) */
    bool Valid() const { return vk != 0; }
    bool operator==(const Hotkey& o) const { return mods == o.mods && vk == o.vk; }
};

struct Rule {
    bool enabled = true;
    Hotkey src, dst;
    ActionKind act = ACT_SWAP;
    std::string note;
};

struct Config {
    std::vector<Rule> rules;
    bool enabledAll = true;
    bool voiceEnabled = true;
    Hotkey voiceKey;
    int provider = VP_MAC_SYSTEM;
    int vtrigger = VT_TOGGLE;
    Hotkey customToggle, customHold;
    int chordHoldMs = 130;
    int gapMs = 25;
    Config() { voiceKey.vk = kVK_F9; }
};

/* ------------------------------------------------------- 键名 ↔ 键码 表 */

struct KeyEnt { const char* name; unsigned code; };
static const KeyEnt kKeys[] = {
    { "a", kVK_ANSI_A }, { "b", kVK_ANSI_B }, { "c", kVK_ANSI_C }, { "d", kVK_ANSI_D },
    { "e", kVK_ANSI_E }, { "f", kVK_ANSI_F }, { "g", kVK_ANSI_G }, { "h", kVK_ANSI_H },
    { "i", kVK_ANSI_I }, { "j", kVK_ANSI_J }, { "k", kVK_ANSI_K }, { "l", kVK_ANSI_L },
    { "m", kVK_ANSI_M }, { "n", kVK_ANSI_N }, { "o", kVK_ANSI_O }, { "p", kVK_ANSI_P },
    { "q", kVK_ANSI_Q }, { "r", kVK_ANSI_R }, { "s", kVK_ANSI_S }, { "t", kVK_ANSI_T },
    { "u", kVK_ANSI_U }, { "v", kVK_ANSI_V }, { "w", kVK_ANSI_W }, { "x", kVK_ANSI_X },
    { "y", kVK_ANSI_Y }, { "z", kVK_ANSI_Z },
    { "0", kVK_ANSI_0 }, { "1", kVK_ANSI_1 }, { "2", kVK_ANSI_2 }, { "3", kVK_ANSI_3 },
    { "4", kVK_ANSI_4 }, { "5", kVK_ANSI_5 }, { "6", kVK_ANSI_6 }, { "7", kVK_ANSI_7 },
    { "8", kVK_ANSI_8 }, { "9", kVK_ANSI_9 },
    { "f1", kVK_F1 }, { "f2", kVK_F2 }, { "f3", kVK_F3 }, { "f4", kVK_F4 },
    { "f5", kVK_F5 }, { "f6", kVK_F6 }, { "f7", kVK_F7 }, { "f8", kVK_F8 },
    { "f9", kVK_F9 }, { "f10", kVK_F10 }, { "f11", kVK_F11 }, { "f12", kVK_F12 },
    { "esc", kVK_Escape }, { "escape", kVK_Escape },
    { "space", kVK_Space }, { "空格", kVK_Space },
    { "enter", kVK_Return }, { "return", kVK_Return }, { "回车", kVK_Return },
    { "tab", kVK_Tab }, { "backspace", kVK_Delete }, { "delete", kVK_ForwardDelete },
    { "home", kVK_Home }, { "end", kVK_End },
    { "pageup", kVK_PageUp }, { "pagedown", kVK_PageDown },
    { "left", kVK_LeftArrow }, { "right", kVK_RightArrow },
    { "up", kVK_UpArrow }, { "down", kVK_DownArrow },
    { "capslock", kVK_CapsLock },
    { "-", kVK_ANSI_Minus }, { "=", kVK_ANSI_Equal },
    { "[", kVK_ANSI_LeftBracket }, { "]", kVK_ANSI_RightBracket },
    { "\\", kVK_ANSI_Backslash }, { ";", kVK_ANSI_Semicolon },
    { "'", kVK_ANSI_Quote }, { ",", kVK_ANSI_Comma },
    { ".", kVK_ANSI_Period }, { "/", kVK_ANSI_Slash }, { "`", kVK_ANSI_Grave },
    { NULL, 0 }
};

static std::string Lower(const std::string& s) {
    std::string r = s;
    std::transform(r.begin(), r.end(), r.begin(), ::tolower);
    return r;
}
static std::string Trim(const std::string& s) {
    size_t a = s.find_first_not_of(" \t\r\n");
    if (a == std::string::npos) return "";
    size_t b = s.find_last_not_of(" \t\r\n");
    return s.substr(a, b - a + 1);
}

static std::string KeyName(unsigned code) {
    static const struct { unsigned c; const char* n; } tbl[] = {
        { kVK_F1, "F1" }, { kVK_F2, "F2" }, { kVK_F3, "F3" }, { kVK_F4, "F4" },
        { kVK_F5, "F5" }, { kVK_F6, "F6" }, { kVK_F7, "F7" }, { kVK_F8, "F8" },
        { kVK_F9, "F9" }, { kVK_F10, "F10" }, { kVK_F11, "F11" }, { kVK_F12, "F12" },
        { kVK_Escape, "Esc" }, { kVK_Space, "Space" }, { kVK_Return, "Enter" },
        { kVK_Tab, "Tab" }, { kVK_Delete, "Backspace" }, { kVK_ForwardDelete, "Delete" },
        { kVK_Home, "Home" }, { kVK_End, "End" }, { kVK_PageUp, "PageUp" },
        { kVK_PageDown, "PageDown" }, { kVK_LeftArrow, "Left" }, { kVK_RightArrow, "Right" },
        { kVK_UpArrow, "Up" }, { kVK_DownArrow, "Down" }, { kVK_CapsLock, "CapsLock" },
        { 0, NULL }
    };
    for (int i = 0; tbl[i].n; i++) if (tbl[i].c == code) return tbl[i].n;
    for (int i = 0; kKeys[i].name; i++) {
        if (kKeys[i].code == code && kKeys[i].name[0] >= 'a' && kKeys[i].name[0] <= 'z')
            return std::string(1, (char)toupper(kKeys[i].name[0]));
    }
    char buf[16];
    snprintf(buf, sizeof(buf), "key%u", code);
    return buf;
}

static std::string HotkeyToString(const Hotkey& hk) {
    std::string r;
    if (hk.mods & KM_CTRL)  r += "Ctrl+";
    if (hk.mods & KM_ALT)   r += "Alt+";
    if (hk.mods & KM_SHIFT) r += "Shift+";
    if (hk.mods & KM_WIN)   r += "Win+";       /* 在 Mac 上就是 Command */
    if (hk.vk) r += KeyName(hk.vk);
    if (r.empty()) return "（未设置）";
    if (r[r.size() - 1] == '+') r.erase(r.size() - 1);
    return r;
}

static bool StringToHotkey(const std::string& src, Hotkey& out) {
    out.mods = 0; out.vk = 0;
    std::string s = Trim(src);
    if (s.empty()) return false;
    std::vector<std::string> toks;
    std::string cur;
    for (size_t i = 0; i <= s.size(); i++) {
        if (i == s.size() || s[i] == '+') { toks.push_back(cur); cur.clear(); }
        else cur.push_back(s[i]);
    }
    bool any = false;
    for (size_t i = 0; i < toks.size(); i++) {
        std::string t = Lower(Trim(toks[i]));
        if (t.empty()) continue;
        if (t == "ctrl" || t == "control" || t == "控制") { out.mods |= KM_CTRL; any = true; continue; }
        if (t == "alt" || t == "option" || t == "opt" || t == "菜单") { out.mods |= KM_ALT; any = true; continue; }
        if (t == "shift" || t == "上档") { out.mods |= KM_SHIFT; any = true; continue; }
        if (t == "win" || t == "windows" || t == "cmd" || t == "command" || t == "super" || t == "超级") {
            out.mods |= KM_WIN; any = true; continue;
        }
        for (int k = 0; kKeys[k].name; k++) {
            if (Lower(kKeys[k].name) == t) { out.vk = kKeys[k].code; any = true; break; }
        }
    }
    return any;
}

/* --------------------------------------------------------------- 配置读写 */

static std::string DirOf(const std::string& path) {
    size_t p = path.find_last_of('/');
    return (p == std::string::npos) ? std::string(".") : path.substr(0, p);
}

static void ConfigDefault(Config& c) {
    Rule r1;
    r1.enabled = false;
    StringToHotkey("Ctrl+Alt+K", r1.src);
    StringToHotkey("F5", r1.dst);
    r1.note = "示例：按 Ctrl+Alt+K 等于按 F5（默认关着）";
    c.rules.push_back(r1);

    Rule r2;
    r2.enabled = false;
    StringToHotkey("Ctrl+Alt+Q", r2.src);
    r2.act = ACT_BLOCK;
    r2.note = "示例：屏蔽掉 Ctrl+Alt+Q";
    c.rules.push_back(r2);
}

static bool ConfigLoad(const std::string& path, Config& c) {
    std::ifstream in(path.c_str(), std::ios::binary);
    if (!in) { ConfigDefault(c); return false; }

    std::stringstream ss;
    ss << in.rdbuf();
    std::string text = ss.str();
    if (text.size() >= 3 && (unsigned char)text[0] == 0xEF &&
        (unsigned char)text[1] == 0xBB && (unsigned char)text[2] == 0xBF)
        text = text.substr(3);                     /* 去掉 UTF-8 BOM */

    std::string section;
    Rule cur;
    bool inRule = false;
    std::istringstream ls(text);
    std::string line;
    while (std::getline(ls, line)) {
        line = Trim(line);
        if (line.empty() || line[0] == ';' || line[0] == '#') continue;
        if (line[0] == '[') {
            if (inRule) { c.rules.push_back(cur); inRule = false; }
            size_t rb = line.find(']');
            std::string inner = (rb == std::string::npos) ? line.substr(1)
                                                          : line.substr(1, rb - 1);
            std::string s = Lower(Trim(inner));
            if (s == "规则" || s == "rule" || s == "rules") { section = "rule"; cur = Rule(); inRule = true; }
            else if (s == "全局" || s == "general" || s == "global" || s == "app") section = "general";
            else if (s == "语音输入" || s == "voice") section = "voice";
            else section = s;
            continue;
        }
        size_t eq = line.find('=');
        if (eq == std::string::npos) continue;
        std::string k = Trim(line.substr(0, eq));
        std::string v = Trim(line.substr(eq + 1));
        std::string kl = Lower(k);

        if (section == "general") {
            if (kl == "enabled") c.enabledAll = (v == "1");
            else if (kl == "chordholdms") { int n = atoi(v.c_str()); if (n >= 20 && n <= 2000) c.chordHoldMs = n; }
            else if (kl == "gapms") { int n = atoi(v.c_str()); if (n >= 0 && n <= 500) c.gapMs = n; }
        } else if (section == "voice") {
            if (kl == "enabled") c.voiceEnabled = (v == "1");
            else if (kl == "key" || kl == "hotkey") { Hotkey h; if (StringToHotkey(v, h) && h.Valid()) c.voiceKey = h; }
            else if (kl == "provider") {
                if (Lower(v) == "fn") c.provider = VP_MAC_FN;
                else if (Lower(v) == "custom") c.provider = VP_CUSTOM;
                else c.provider = VP_MAC_SYSTEM;
            }
            else if (kl == "trigger") c.vtrigger = (Lower(v) == "hold") ? VT_HOLD : VT_TOGGLE;
            else if (kl == "customtoggle") { Hotkey h; if (StringToHotkey(v, h)) c.customToggle = h; }
            else if (kl == "customhold") { Hotkey h; if (StringToHotkey(v, h)) c.customHold = h; }
        } else if (section == "rule") {
            if (kl == "enabled") cur.enabled = (v == "1");
            else if (kl == "from") { Hotkey h; if (StringToHotkey(v, h)) cur.src = h; }
            else if (kl == "to") { Hotkey h; if (StringToHotkey(v, h)) cur.dst = h; }
            else if (kl == "note") cur.note = v;
            else if (kl == "mode") {
                std::string m = Lower(v);
                cur.act = (m == "voice") ? ACT_VOICE : (m == "block") ? ACT_BLOCK : ACT_SWAP;
            }
        }
    }
    if (inRule) c.rules.push_back(cur);
    return true;
}

/* ------------------------------------------------------------ 引擎状态 */

static Config          g_cfg;
static CFMachPortRef   g_tap = NULL;
static CFRunLoopSourceRef g_src = NULL;
static bool            g_enabled = true;

/* 物理按键状态（只记修饰键就够） */
static bool g_ctrl = false, g_alt = false, g_shift = false, g_cmd = false;

static bool g_holdActive = false;
static Hotkey g_holdChord;

static void PostKey(unsigned code, bool down) {
    CGEventRef e = CGEventCreateKeyboardEvent(NULL, (CGKeyCode)code, !down);
    if (!e) return;
    CGEventSetIntegerValueField(e, kCGEventSourceUserData, KS_MAGIC);
    CGEventPost(kCGSessionEventTap, e);
    CFRelease(e);
}

static void SleepMs(int ms) {
    usleep((useconds_t)ms * 1000);
}

/* 按键注入永远在后台串行队列上做。
   CGEventTap 的回调里绝对不能阻塞/睡——超时会被系统直接摘掉 tap。 */
static dispatch_queue_t g_work = NULL;

static void RunOnWork(void (^block)(void)) {
    if (!g_work) g_work = dispatch_queue_create("keyswap.work", DISPATCH_QUEUE_SERIAL);
    dispatch_async(g_work, block);
}

/* 把一个「组合键」完整地按一下：按下修饰键 → 按下主键 → 停一会 → 反向松开 */
static void InjectChord(const Hotkey& hk) {
    std::vector<unsigned> mods;
    if (hk.mods & KM_CTRL)  mods.push_back(kVK_Control);
    if (hk.mods & KM_ALT)   mods.push_back(kVK_Option);
    if (hk.mods & KM_SHIFT) mods.push_back(kVK_Shift);
    if (hk.mods & KM_WIN)   mods.push_back(kVK_Command);

    for (size_t i = 0; i < mods.size(); i++)  { PostKey(mods[i], true);  SleepMs(g_cfg.gapMs); }
    if (hk.vk) {
        PostKey(hk.vk, true);
        SleepMs(g_cfg.chordHoldMs);
        PostKey(hk.vk, false);
        SleepMs(g_cfg.gapMs);
    } else {
        SleepMs(g_cfg.chordHoldMs);
    }
    for (int i = (int)mods.size() - 1; i >= 0; i--) { PostKey(mods[i], false); SleepMs(g_cfg.gapMs); }
}

/* 语音输入要发的组合键 */
static Hotkey VoiceChord(bool* holdIsPress) {
    Hotkey h;
    if (g_cfg.provider == VP_CUSTOM) {
        h = (g_cfg.vtrigger == VT_HOLD) ? g_cfg.customHold : g_cfg.customToggle;
        if (holdIsPress) *holdIsPress = true;
    } else {
        /* macOS 自带听写的默认手势是「连按两下 Control」（Fn 机型也可以连按两下 🌐 键）。
           这里用「点按两下」的方式来触发，所以它本质上是个开关。 */
        h.mods = 0;
        h.vk = (g_cfg.provider == VP_MAC_FN) ? kVK_Function : kVK_Control;
        if (holdIsPress) *holdIsPress = false;
    }
    return h;
}

static void DoVoiceToggle() {
    if (g_cfg.provider == VP_CUSTOM) { InjectChord(VoiceChord(NULL)); return; }
    unsigned k = (g_cfg.provider == VP_MAC_FN) ? kVK_Function : kVK_Control;
    /* 连按两下 */
    PostKey(k, true); SleepMs(40); PostKey(k, false);
    SleepMs(60);
    PostKey(k, true); SleepMs(40); PostKey(k, false);
}

static void FireRule(const Rule& r) {
    if (r.act == ACT_BLOCK) return;
    if (r.act == ACT_VOICE) { DoVoiceToggle(); return; }
    InjectChord(r.dst);
}

/* 放到后台去执行，回调立刻返回 */
static void FireRuleAsync(const Rule& r) {
    Rule copy = r;
    RunOnWork(^{ FireRule(copy); });
}
static void DoVoiceToggleAsync() {
    RunOnWork(^{ DoVoiceToggle(); });
}

/* 按住说话：按下时把组合键按住不放，松开时再放掉 */
static void HoldStartAsync(const Hotkey& h) {
    Hotkey copy = h;
    RunOnWork(^{
        if (copy.mods & KM_CTRL)  { PostKey(kVK_Control, true); SleepMs(g_cfg.gapMs); }
        if (copy.mods & KM_ALT)   { PostKey(kVK_Option,  true); SleepMs(g_cfg.gapMs); }
        if (copy.mods & KM_SHIFT) { PostKey(kVK_Shift,   true); SleepMs(g_cfg.gapMs); }
        if (copy.mods & KM_WIN)   { PostKey(kVK_Command, true); SleepMs(g_cfg.gapMs); }
        if (copy.vk) PostKey(copy.vk, true);
    });
}
static void HoldEndAsync(const Hotkey& h) {
    Hotkey copy = h;
    RunOnWork(^{
        if (copy.vk) PostKey(copy.vk, false);
        if (copy.mods & KM_WIN)   { PostKey(kVK_Command, false); SleepMs(g_cfg.gapMs); }
        if (copy.mods & KM_SHIFT) { PostKey(kVK_Shift,   false); SleepMs(g_cfg.gapMs); }
        if (copy.mods & KM_ALT)   { PostKey(kVK_Option,  false); SleepMs(g_cfg.gapMs); }
        if (copy.mods & KM_CTRL)  { PostKey(kVK_Control, false); SleepMs(g_cfg.gapMs); }
    });
}

/* ------------------------------------------------------------- 事件回调 */

static unsigned FlagsToMods(CGEventFlags f) {
    unsigned m = 0;
    if (f & kCGEventFlagMaskControl)   m |= KM_CTRL;
    if (f & kCGEventFlagMaskAlternate) m |= KM_ALT;
    if (f & kCGEventFlagMaskShift)     m |= KM_SHIFT;
    if (f & kCGEventFlagMaskCommand)   m |= KM_WIN;
    return m;
}

/* 被我们吞掉的触发键：它的 keyUp 也要吞掉 */
static unsigned g_swallowedKey = 0;

static CGEventRef TapCallback(CGEventTapProxy proxy, CGEventType type,
                              CGEventRef event, void* refcon) {
    (void)proxy; (void)refcon;

    /* 系统可能把 tap 关掉（超时等），这里兜一下 */
    if (type == kCGEventTapDisabledByTimeout || type == kCGEventTapDisabledByUserInput) {
        if (g_tap) CGEventTapEnable(g_tap, true);
        return event;
    }

    /* 自己发出去的按键，直接放行，避免自己触发自己 */
    int64_t ud = CGEventGetIntegerValueField(event, kCGEventSourceUserData);
    if ((uint32_t)ud == KS_MAGIC) return event;

    unsigned code = (unsigned)CGEventGetIntegerValueField(event, kCGEventKeyCode);
    CGEventFlags fl = CGEventGetFlags(event);

    /* 只关心普通按键与修饰键 */
    if (type == kCGEventFlagsChanged) {
        g_ctrl  = (fl & kCGEventFlagMaskControl)   != 0;
        g_alt   = (fl & kCGEventFlagMaskAlternate) != 0;
        g_shift = (fl & kCGEventFlagMaskShift)     != 0;
        g_cmd   = (fl & kCGEventFlagMaskCommand)   != 0;
        /* 修饰键的「按下/松开」靠 flags 变化推断：这里只更新状态，不吞 */
        if (g_swallowedKey && !g_enabled) g_swallowedKey = 0;
        return event;
    }

    bool isDown = (type == kCGEventKeyDown);

    /* --- 松开事件 --- */
    if (!isDown) {
        if (g_swallowedKey == code) {
            if (g_holdActive) {
                HoldEndAsync(g_holdChord);
                g_holdActive = false;
            }
            g_swallowedKey = 0;
            return NULL;                 /* 吞掉 */
        }
        return event;
    }

    if (!g_enabled) return event;

    unsigned mods = FlagsToMods(fl);

    /* --- 语音热键 --- */
    if (g_cfg.voiceEnabled && g_cfg.voiceKey.Valid() &&
        code == g_cfg.voiceKey.vk && mods == g_cfg.voiceKey.mods) {
        g_swallowedKey = code;
        if (g_cfg.vtrigger == VT_HOLD && g_cfg.provider == VP_CUSTOM) {
            g_holdChord = VoiceChord(NULL);
            g_holdActive = true;
            HoldStartAsync(g_holdChord);
        } else {
            /* 系统听写是「连按两下」的开关型手势，「按住」就退化成点一下 */
            DoVoiceToggleAsync();
        }
        return NULL;
    }

    /* --- 替换规则 --- */
    for (size_t i = 0; i < g_cfg.rules.size(); i++) {
        const Rule& r = g_cfg.rules[i];
        if (!r.enabled) continue;
        if (r.src.vk != code || r.src.mods != mods) continue;
        g_swallowedKey = code;
        FireRuleAsync(r);
        return NULL;
    }

    return event;
}

/* --------------------------------------------------------- 菜单栏小程序 */

@interface KSAppDelegate : NSObject <NSApplicationDelegate>
@property (nonatomic, strong) NSStatusItem* item;
@property (nonatomic, strong) NSMenuItem* toggleItem;
@end

@implementation KSAppDelegate

- (void)buildMenu {
    NSMenu* m = [[NSMenu alloc] init];
    [m addItemWithTitle:@"快捷键更换助手 v2.1 (macOS)" action:nil keyEquivalent:@""];
    [m addItem:[NSMenuItem separatorItem]];

    self.toggleItem = [[NSMenuItem alloc] initWithTitle:@"暂停所有替换"
                                                action:@selector(toggleEnabled:)
                                         keyEquivalent:@""];
    self.toggleItem.target = self;
    [m addItem:self.toggleItem];

    NSMenuItem* open = [[NSMenuItem alloc] initWithTitle:@"打开配置文件"
                                                 action:@selector(openConfig:)
                                          keyEquivalent:@""];
    open.target = self;
    [m addItem:open];

    NSMenuItem* rel = [[NSMenuItem alloc] initWithTitle:@"重新载入配置"
                                                action:@selector(reloadConfig:)
                                         keyEquivalent:@""];
    rel.target = self;
    [m addItem:rel];

    [m addItem:[NSMenuItem separatorItem]];
    NSMenuItem* q = [[NSMenuItem alloc] initWithTitle:@"退出"
                                              action:@selector(terminate:)
                                       keyEquivalent:@"q"];
    q.target = NSApp;
    [m addItem:q];

    self.item.menu = m;
}

- (void)applicationDidFinishLaunching:(NSNotification*)n {
    (void)n;
    [NSApp setActivationPolicy:NSApplicationActivationPolicyAccessory];

    self.item = [[NSStatusBar systemStatusBar] statusItemWithLength:NSVariableStatusItemLength];
    self.item.button.title = @"⇄";

    /* 申请辅助功能权限：没有它，CGEventTap 收不到任何按键 */
    NSDictionary* opts = @{ (__bridge NSString*)kAXTrustedCheckOptionPrompt: @YES };
    BOOL trusted = AXIsProcessTrustedWithOptions((__bridge CFDictionaryRef)opts);
    if (!trusted) {
        NSLog(@"需要在「系统设置 → 隐私与安全性 → 辅助功能」里勾上本程序，然后重新启动。");
    }

    /* 配置文件放在程序同目录 */
    NSString* exePath = [[NSBundle mainBundle] executablePath];
    if (!exePath) exePath = [[NSProcessInfo processInfo] arguments][0];
    NSString* dir = [exePath stringByDeletingLastPathComponent];
    std::string cfgPath = std::string([[dir stringByAppendingPathComponent:@"KeySwap.ini"] UTF8String]);
    ConfigLoad(cfgPath, g_cfg);

    [self buildMenu];
    [self installTap];
}

- (void)installTap {
    CGEventMask mask = CGEventMaskBit(kCGEventKeyDown) |
                       CGEventMaskBit(kCGEventKeyUp) |
                       CGEventMaskBit(kCGEventFlagsChanged);
    g_tap = CGEventTapCreate(kCGSessionEventTap, kCGHeadInsertEventTap,
                             kCGEventTapOptionDefault, mask, TapCallback, NULL);
    if (!g_tap) {
        NSLog(@"CGEventTap 创建失败：请确认已授予「辅助功能」权限，并重启本程序。");
        return;
    }
    g_src = CFMachPortCreateRunLoopSource(kCFAllocatorDefault, g_tap, 0);
    CFRunLoopAddSource(CFRunLoopGetCurrent(), g_src, kCFRunLoopCommonModes);
    CGEventTapEnable(g_tap, true);
    NSLog(@"KeySwap 已启动：%lu 条规则生效中", (unsigned long)g_cfg.rules.size());
}

- (void)toggleEnabled:(id)sender {
    (void)sender;
    g_enabled = !g_enabled;
    self.toggleItem.title = g_enabled ? @"暂停所有替换" : @"恢复所有替换";
}

- (void)openConfig:(id)sender {
    (void)sender;
    NSString* exePath = [[NSBundle mainBundle] executablePath];
    NSString* dir = [exePath stringByDeletingLastPathComponent];
    NSString* p = [dir stringByAppendingPathComponent:@"KeySwap.ini"];
    [[NSWorkspace sharedWorkspace] openFile:p];
}

- (void)reloadConfig:(id)sender {
    (void)sender;
    NSString* exePath = [[NSBundle mainBundle] executablePath];
    NSString* dir = [exePath stringByDeletingLastPathComponent];
    std::string cfgPath = std::string([[dir stringByAppendingPathComponent:@"KeySwap.ini"] UTF8String]);
    ConfigLoad(cfgPath, g_cfg);
    NSLog(@"配置已重新载入：%lu 条规则", (unsigned long)g_cfg.rules.size());
}

@end

int main(int argc, const char* argv[]) {
    (void)argc; (void)argv;
    @autoreleasepool {
        NSApplication* app = [NSApplication sharedApplication];
        KSAppDelegate* d = [[KSAppDelegate alloc] init];
        app.delegate = d;
        [app run];
    }
    return 0;
}

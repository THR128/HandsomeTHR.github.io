// main.cpp - TaskbarTemps
// A tiny CPU/GPU readout docked in the right part of the Windows taskbar.
// Two stacked text rows, no frame, no background plate.
// CPU: usage + frequency (PDH).  GPU: temperature + usage + power (NVML).

#define _WIN32_WINNT 0x0A00
#define WINVER 0x0A00
#ifndef UNICODE
#define UNICODE
#endif
#ifndef _UNICODE
#define _UNICODE
#endif

#include <windows.h>
#include <shellapi.h>
#include <gdiplus.h>

#include <cmath>
#include <cstdio>
#include <cwchar>
#include <string>
#include <vector>

#include "sensors.h"

using namespace Gdiplus;

// ---------------------------------------------------------------------------
// constants / globals
// ---------------------------------------------------------------------------
namespace {

const wchar_t* kAppName = L"TaskbarTemps";
const wchar_t* kClassName = L"TaskbarTemps.Window";
const wchar_t* kMutexName = L"Local\\TaskbarTemps.SingleInstance";
const wchar_t* kRunValueName = L"TaskbarTemps";
const UINT kTimerId = 1;

enum CommandId {
    IDM_INTERVAL_500 = 100,
    IDM_INTERVAL_1000,
    IDM_INTERVAL_2000,
    IDM_INTERVAL_5000,
    IDM_PIN,
    IDM_AUTOSTART,
    IDM_ABOUT,
    IDM_EXIT,
};

struct Config {
    int refreshMs = 1000;
    bool pinned = false;
};

HWND g_hwnd = nullptr;
Config g_cfg;
std::wstring g_configPath;
Sensors g_sensors;
bool g_hover = false;
bool g_pinned = false;
bool g_showing = false;
bool g_lightTaskbar = false;
bool g_forceTheme = false;
ULONGLONG g_lastThemeSample = 0;
UINT g_dpi = 96;
UINT g_fontDpi = 0;
Font* g_fontLabel = nullptr;
Font* g_fontValue = nullptr;
Font* g_fontExtra = nullptr;

// ---------------------------------------------------------------------------
// DPI / shell helpers (resolved dynamically so no manifest is needed)
// ---------------------------------------------------------------------------
typedef BOOL(WINAPI* PFN_SetProcessDpiAwarenessContext)(HANDLE);
typedef UINT(WINAPI* PFN_GetDpiForWindow)(HWND);
typedef HRESULT(WINAPI* PFN_SHQueryUserNotificationState)(int*);

PFN_GetDpiForWindow g_pfnGetDpiForWindow = nullptr;
PFN_SHQueryUserNotificationState g_pfnQueryNotificationState = nullptr;

void LoadDynamicApis()
{
    HMODULE user32 = GetModuleHandleW(L"user32.dll");
    if (user32) {
        g_pfnGetDpiForWindow =
            reinterpret_cast<PFN_GetDpiForWindow>(GetProcAddress(user32, "GetDpiForWindow"));
        auto setCtx = reinterpret_cast<PFN_SetProcessDpiAwarenessContext>(
            GetProcAddress(user32, "SetProcessDpiAwarenessContext"));
        if (setCtx) {
            // DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2
            setCtx(reinterpret_cast<HANDLE>(static_cast<INT_PTR>(-4)));
        }
    }
    HMODULE shcore = LoadLibraryW(L"shcore.dll");
    if (shcore) {
        typedef HRESULT(WINAPI * PFN_SetProcessDpiAwareness)(int);
        auto setAwareness = reinterpret_cast<PFN_SetProcessDpiAwareness>(
            GetProcAddress(shcore, "SetProcessDpiAwareness"));
        if (setAwareness) setAwareness(2);  // PROCESS_PER_MONITOR_DPI_AWARE
    }
    HMODULE shell32 = GetModuleHandleW(L"shell32.dll");
    if (shell32) {
        g_pfnQueryNotificationState = reinterpret_cast<PFN_SHQueryUserNotificationState>(
            GetProcAddress(shell32, "SHQueryUserNotificationState"));
    }
}

UINT WindowDpi(HWND hwnd)
{
    if (g_pfnGetDpiForWindow) {
        UINT dpi = g_pfnGetDpiForWindow(hwnd);
        if (dpi) return dpi;
    }
    HDC dc = GetDC(hwnd);
    UINT dpi = dc ? static_cast<UINT>(GetDeviceCaps(dc, LOGPIXELSX)) : 96;
    if (dc) ReleaseDC(hwnd, dc);
    return dpi ? dpi : 96;
}

// ---------------------------------------------------------------------------
// small helpers
// ---------------------------------------------------------------------------
std::wstring Fmt(const wchar_t* fmt, double value)
{
    wchar_t buf[64] = {};
    swprintf(buf, 64, fmt, value);
    return buf;
}

std::wstring FmtInt(const wchar_t* fmt, int value)
{
    wchar_t buf[64] = {};
    swprintf(buf, 64, fmt, value);
    return buf;
}

std::wstring ExeDirectory()
{
    wchar_t exe[MAX_PATH] = {};
    GetModuleFileNameW(nullptr, exe, MAX_PATH);
    std::wstring dir(exe);
    const size_t slash = dir.find_last_of(L"\\/");
    if (slash != std::wstring::npos) dir.resize(slash);
    return dir;
}

// ---------------------------------------------------------------------------
// config file: prefer a portable ini next to the exe, fall back to %APPDATA%
// ---------------------------------------------------------------------------
std::wstring g_cachedConfigPath;

bool CanWriteIni(const std::wstring& path)
{
    if (!WritePrivateProfileStringW(L"probe", L"ok", L"1", path.c_str())) return false;
    WritePrivateProfileStringW(L"probe", nullptr, nullptr, path.c_str());  // drop probe section
    return true;
}

std::wstring ConfigPath()
{
    if (!g_cachedConfigPath.empty()) return g_cachedConfigPath;

    const std::wstring portable = ExeDirectory() + L"\\TaskbarTemps.ini";
    if (CanWriteIni(portable)) {
        g_cachedConfigPath = portable;
        return g_cachedConfigPath;
    }

    wchar_t appdata[MAX_PATH] = {};
    DWORD len = GetEnvironmentVariableW(L"APPDATA", appdata, MAX_PATH);
    if (len > 0 && len < MAX_PATH) {
        std::wstring dir = std::wstring(appdata) + L"\\TaskbarTemps";
        CreateDirectoryW(dir.c_str(), nullptr);
        const std::wstring roaming = dir + L"\\settings.ini";
        if (CanWriteIni(roaming)) {
            g_cachedConfigPath = roaming;
            return g_cachedConfigPath;
        }
    }

    g_cachedConfigPath = portable;  // best effort; may simply not persist
    return g_cachedConfigPath;
}

void LoadConfig()
{
    g_configPath = ConfigPath();
    const wchar_t* path = g_configPath.c_str();

    g_cfg.refreshMs = static_cast<int>(GetPrivateProfileIntW(L"view", L"refreshMs", 1000, path));
    if (g_cfg.refreshMs < 250) g_cfg.refreshMs = 250;
    if (g_cfg.refreshMs > 10000) g_cfg.refreshMs = 10000;
    g_cfg.pinned = GetPrivateProfileIntW(L"view", L"pinned", 0, path) != 0;
}

void SaveConfig()
{
    const wchar_t* path = g_configPath.c_str();
    if (!path || !path[0]) g_configPath = ConfigPath();
    path = g_configPath.c_str();

    wchar_t buf[32] = {};
    swprintf(buf, 32, L"%d", g_cfg.refreshMs);
    WritePrivateProfileStringW(L"view", L"refreshMs", buf, path);
    WritePrivateProfileStringW(L"view", L"pinned", g_cfg.pinned ? L"1" : L"0", path);
}

// ---------------------------------------------------------------------------
// autostart (HKCU\...\Run)
// ---------------------------------------------------------------------------
const wchar_t* kRunKey = L"Software\\Microsoft\\Windows\\CurrentVersion\\Run";

bool AutostartEnabled()
{
    HKEY key = nullptr;
    bool enabled = false;
    if (RegOpenKeyExW(HKEY_CURRENT_USER, kRunKey, 0, KEY_READ, &key) == ERROR_SUCCESS) {
        wchar_t value[MAX_PATH * 2] = {};
        DWORD size = sizeof(value);
        DWORD type = 0;
        if (RegQueryValueExW(key, kRunValueName, nullptr, &type, reinterpret_cast<LPBYTE>(value),
                             &size) == ERROR_SUCCESS &&
            type == REG_SZ) {
            enabled = value[0] != 0;
        }
        RegCloseKey(key);
    }
    return enabled;
}

void SetAutostart(bool enabled)
{
    HKEY key = nullptr;
    if (RegCreateKeyExW(HKEY_CURRENT_USER, kRunKey, 0, nullptr, 0, KEY_SET_VALUE, nullptr, &key,
                        nullptr) != ERROR_SUCCESS) {
        return;
    }
    if (enabled) {
        wchar_t exe[MAX_PATH] = {};
        GetModuleFileNameW(nullptr, exe, MAX_PATH);
        std::wstring command = L"\"" + std::wstring(exe) + L"\"";
        RegSetValueExW(key, kRunValueName, 0, REG_SZ,
                       reinterpret_cast<const BYTE*>(command.c_str()),
                       static_cast<DWORD>((command.size() + 1) * sizeof(wchar_t)));
    } else {
        RegDeleteValueW(key, kRunValueName);
    }
    RegCloseKey(key);
}

// ---------------------------------------------------------------------------
// taskbar geometry
// ---------------------------------------------------------------------------
struct TaskbarInfo {
    bool ok = false;
    RECT bar = {};
    UINT edge = ABE_BOTTOM;
    RECT notify = {};
    bool notifyOk = false;
};

TaskbarInfo QueryTaskbar()
{
    TaskbarInfo info;
    HWND tray = FindWindowW(L"Shell_TrayWnd", nullptr);
    if (!tray) return info;

    RECT windowRect = {};
    if (!GetWindowRect(tray, &windowRect)) return info;

    info.bar = windowRect;
    info.edge = ABE_BOTTOM;

    APPBARDATA abd = {};
    abd.cbSize = sizeof(abd);
    if (SHAppBarMessage(ABM_GETTASKBARPOS, &abd)) info.edge = abd.uEdge;

    HMONITOR mon = MonitorFromRect(&windowRect, MONITOR_DEFAULTTONEAREST);
    MONITORINFO mi = { sizeof(mi) };
    if (GetMonitorInfoW(mon, &mi)) {
        // Taskbar hidden or fully off-screen => nothing to dock against.
        if (windowRect.top >= mi.rcMonitor.bottom || windowRect.bottom <= mi.rcMonitor.top) {
            return info;
        }
    }

    HWND notify = FindWindowExW(tray, nullptr, L"TrayNotifyWnd", nullptr);
    if (notify && GetWindowRect(notify, &info.notify)) {
        info.notifyOk = info.notify.right > info.notify.left;
    }

    info.ok = true;
    return info;
}

bool FullscreenActive()
{
    if (g_pfnQueryNotificationState) {
        int state = 0;
        if (SUCCEEDED(g_pfnQueryNotificationState(&state))) {
            // QUNS_BUSY / QUNS_RUNNING_D3D_FULL_SCREEN / QUNS_PRESENTATION_MODE / QUNS_APP
            if (state == 2 || state == 3 || state == 4 || state == 7) return true;
        }
    }

    HWND foreground = GetForegroundWindow();
    if (!foreground) return false;
    wchar_t cls[64] = {};
    GetClassNameW(foreground, cls, 64);
    if (wcscmp(cls, L"Shell_TrayWnd") == 0 || wcscmp(cls, L"Progman") == 0 ||
        wcscmp(cls, L"WorkerW") == 0 || wcscmp(cls, L"Shell_SecondaryTrayWnd") == 0) {
        return false;
    }
    RECT rect = {};
    if (!GetWindowRect(foreground, &rect)) return false;
    HMONITOR mon = MonitorFromWindow(foreground, MONITOR_DEFAULTTONEAREST);
    MONITORINFO mi = { sizeof(mi) };
    if (!GetMonitorInfoW(mon, &mi)) return false;
    return rect.left <= mi.rcMonitor.left && rect.top <= mi.rcMonitor.top &&
           rect.right >= mi.rcMonitor.right && rect.bottom >= mi.rcMonitor.bottom;
}

POINT ComputePosition(int width, int height, const TaskbarInfo& info)
{
    RECT monitor = info.bar;
    HMONITOR mon = MonitorFromRect(&info.bar, MONITOR_DEFAULTTONEAREST);
    MONITORINFO mi = { sizeof(mi) };
    if (GetMonitorInfoW(mon, &mi)) monitor = mi.rcMonitor;

    const int gap = static_cast<int>(12.0f * g_dpi / 96.0f);
    const int barWidth = info.bar.right - info.bar.left;
    const int barHeight = info.bar.bottom - info.bar.top;

    POINT pt = { 0, 0 };
    if (info.edge == ABE_BOTTOM || info.edge == ABE_TOP) {
        int rightLimit = info.bar.right;
        if (info.notifyOk && info.notify.left > info.bar.left + 100) rightLimit = info.notify.left;
        pt.x = rightLimit - gap - width;
        pt.y = info.bar.top + (barHeight - height) / 2;
    } else {
        pt.x = info.bar.left + (barWidth - width) / 2;
        pt.y = info.bar.bottom - gap - height;
    }

    if (pt.x < monitor.left) pt.x = monitor.left;
    if (pt.x + width > monitor.right) pt.x = monitor.right - width;
    if (pt.y < monitor.top) pt.y = monitor.top;
    if (pt.y + height > monitor.bottom) pt.y = monitor.bottom - height;
    return pt;
}

// ---------------------------------------------------------------------------
// theme
// ---------------------------------------------------------------------------
void DetectTaskbarTheme()
{
    HKEY key = nullptr;
    g_lightTaskbar = false;
    if (RegOpenKeyExW(HKEY_CURRENT_USER,
                      L"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Themes\\Personalize", 0,
                      KEY_READ, &key) == ERROR_SUCCESS) {
        DWORD value = 0, size = sizeof(value), type = 0;
        if (RegQueryValueExW(key, L"SystemUsesLightTheme", nullptr, &type,
                             reinterpret_cast<LPBYTE>(&value), &size) == ERROR_SUCCESS) {
            g_lightTaskbar = value != 0;
        }
        RegCloseKey(key);
    }
}

// Sample the real taskbar pixels right where the widget docks and decide whether
// light or dark text has more contrast. This covers custom accent colours,
// translucent taskbars and wallpaper bleed-through, not just light/dark mode.
void SampleTaskbarTheme(const TaskbarInfo& info)
{
    if (g_forceTheme || !info.ok) return;

    const int rightLimit =
        (info.notifyOk && info.notify.left > info.bar.left + 100) ? info.notify.left : info.bar.right;
    const int xStart = rightLimit - 220;
    const int xEnd = rightLimit - 14;
    const int yPoints[2] = { info.bar.top + 2, info.bar.bottom - 3 };

    HDC screen = GetDC(nullptr);
    if (!screen) return;

    double linearSum = 0.0;
    int count = 0;
    for (int i = 0; i < 2; ++i) {
        const int y = yPoints[i];
        if (y <= info.bar.top || y >= info.bar.bottom) continue;
        for (int x = xStart; x <= xEnd; x += 14) {
            const COLORREF color = GetPixel(screen, x, y);
            if (color == CLR_INVALID) continue;
            // sRGB -> linear light, so the decision matches perceived brightness.
            auto toLinear = [](int c) {
                double v = c / 255.0;
                return v <= 0.03928 ? v / 12.92 : std::pow((v + 0.055) / 1.055, 2.4);
            };
            linearSum += 0.2126 * toLinear(GetRValue(color)) +
                         0.7152 * toLinear(GetGValue(color)) +
                         0.0722 * toLinear(GetBValue(color));
            ++count;
        }
    }
    ReleaseDC(nullptr, screen);
    if (count < 4) return;

    const double luminance = linearSum / count;  // 0.0 (black) .. 1.0 (white)
    // WCAG contrast against black wins once luminance > ~0.179.
    g_lightTaskbar = luminance > 0.179;
}

struct Palette {
    Color label;
    Color value;
    Color extra;
    Color shadow;
};Palette CurrentPalette()
{
    if (g_lightTaskbar) {
        return Palette{ Color(0xFF, 0x5F, 0x64, 0x6B), Color(0xFF, 0x1A, 0x1C, 0x20),
                        Color(0xFF, 0x45, 0x4A, 0x52), Color(0x66, 0xFF, 0xFF, 0xFF) };
    }
    return Palette{ Color(0xFF, 0x8D, 0x96, 0xA3), Color(0xFF, 0xF1, 0xF4, 0xF8),
                    Color(0xFF, 0xAD, 0xB6, 0xC2), Color(0x78, 0x00, 0x00, 0x00) };
}

Color TempColor(int tempC)
{
    if (g_lightTaskbar) {
        if (tempC < 0) return Color(0xFF, 0x5F, 0x64, 0x6B);
        if (tempC < 60) return Color(0xFF, 0x1E, 0x7F, 0x3B);
        if (tempC < 72) return Color(0xFF, 0x8A, 0x6A, 0x00);
        if (tempC < 82) return Color(0xFF, 0xB0, 0x52, 0x0A);
        return Color(0xFF, 0xC0, 0x25, 0x25);
    }
    if (tempC < 0) return Color(0xFF, 0x8D, 0x96, 0xA3);
    if (tempC < 60) return Color(0xFF, 0x7F, 0xD4, 0x8C);
    if (tempC < 72) return Color(0xFF, 0xE8, 0xC4, 0x4D);
    if (tempC < 82) return Color(0xFF, 0xF0, 0x9A, 0x3E);
    return Color(0xFF, 0xEC, 0x5F, 0x5F);
}

// ---------------------------------------------------------------------------
// fonts
// ---------------------------------------------------------------------------
Font* MakeFont(const wchar_t* family, float px, int style, const wchar_t* fallbackFamily,
               int fallbackStyle)
{
    Font* font = new Font(family, px, style, UnitPixel);
    if (font->GetLastStatus() != Ok) {
        delete font;
        font = new Font(fallbackFamily, px, fallbackStyle, UnitPixel);
    }
    return font;
}

void EnsureFonts(UINT dpi)
{
    if (g_fontDpi == dpi && g_fontLabel) return;
    delete g_fontLabel;
    delete g_fontValue;
    delete g_fontExtra;
    g_fontLabel = nullptr;
    g_fontValue = nullptr;
    g_fontExtra = nullptr;

    const float s = static_cast<float>(dpi) / 96.0f;
    g_fontLabel = MakeFont(L"Segoe UI", 12.0f * s, FontStyleRegular, L"Microsoft YaHei UI",
                           FontStyleRegular);
    g_fontValue = MakeFont(L"Segoe UI Semibold", 12.0f * s, FontStyleRegular, L"Segoe UI",
                           FontStyleBold);
    g_fontExtra = MakeFont(L"Segoe UI", 12.0f * s, FontStyleRegular, L"Microsoft YaHei UI",
                           FontStyleRegular);
    g_fontDpi = dpi;
}

// ---------------------------------------------------------------------------
// drawing primitives
// ---------------------------------------------------------------------------
struct Run {
    std::wstring text;
    Font* font = nullptr;
    Color color = Color(0, 0, 0, 0);
    float gap = 0.0f;
    float x = 0.0f;
    float w = 0.0f;
    float h = 0.0f;
};

struct Row {
    std::vector<Run> runs;
    float width = 0.0f;
    float height = 0.0f;
};

float MeasureRun(Graphics& g, Font& font, const std::wstring& text, float* outHeight)
{
    RectF box;
    StringFormat fmt(StringFormatFlagsNoWrap | StringFormatFlagsNoFitBlackBox |
                     StringFormatFlagsMeasureTrailingSpaces);
    fmt.SetTrimming(StringTrimmingNone);
    g.MeasureString(text.c_str(), -1, &font, PointF(0.0f, 0.0f), &fmt, &box);
    if (outHeight) *outHeight = box.Height;
    return box.Width;
}

void DrawRun(Graphics& g, const Run& run, float x, float y, Color shadowColor)
{
    StringFormat fmt(StringFormatFlagsNoWrap | StringFormatFlagsNoFitBlackBox |
                     StringFormatFlagsMeasureTrailingSpaces);
    fmt.SetTrimming(StringTrimmingNone);
    if (shadowColor.GetA() > 0) {
        SolidBrush shadowBrush(shadowColor);
        g.DrawString(run.text.c_str(), -1, run.font, PointF(x + 1.0f, y + 1.0f), &fmt,
                     &shadowBrush);
    }
    SolidBrush brush(run.color);
    g.DrawString(run.text.c_str(), -1, run.font, PointF(x, y), &fmt, &brush);
}

// ---------------------------------------------------------------------------
// overlay painting
// ---------------------------------------------------------------------------
void RenderOverlay(const TaskbarInfo& info)
{
    const CpuReading& cpu = g_sensors.cpu();
    const GpuReading& gpu = g_sensors.gpu();
    const bool expanded = g_hover || g_pinned;
    const float s = static_cast<float>(g_dpi) / 96.0f;

    EnsureFonts(g_dpi);
    const Palette palette = CurrentPalette();

    const float labelGap = 7.0f * s;
    const float extraGap = 6.0f * s;

    Row cpuRow;
    cpuRow.runs.push_back(
        Run{ L"CPU", g_fontLabel, palette.label, 0.0f, 0, 0, 0 });
    cpuRow.runs.push_back(Run{ cpu.usagePct < 0.0 ? L"--" : Fmt(L"%.0f%%", cpu.usagePct),
                               g_fontValue, palette.value, labelGap, 0, 0, 0 });
    if (expanded && cpu.freqGHz > 0.0) {
        cpuRow.runs.push_back(
            Run{ Fmt(L"%.2f GHz", cpu.freqGHz), g_fontExtra, palette.extra, extraGap, 0, 0, 0 });
    }

    Row gpuRow;
    gpuRow.runs.push_back(Run{ L"GPU", g_fontLabel, palette.label, 0.0f, 0, 0, 0 });
    const bool gpuOk = gpu.ok && gpu.tempC >= 0;
    gpuRow.runs.push_back(Run{ gpuOk ? FmtInt(L"%d°C", gpu.tempC) : std::wstring(L"--"),
                               g_fontValue, gpuOk ? TempColor(gpu.tempC) : palette.label, labelGap,
                               0, 0, 0 });
    if (expanded && gpu.ok) {
        if (gpu.utilPct >= 0) {
            gpuRow.runs.push_back(
                Run{ FmtInt(L"%d%%", gpu.utilPct), g_fontExtra, palette.extra, extraGap, 0, 0, 0 });
        }
        if (gpu.powerMw > 0) {
            gpuRow.runs.push_back(
                Run{ FmtInt(L"%dW", static_cast<int>(std::lround(gpu.powerMw / 1000.0))),
                     g_fontExtra, palette.extra, extraGap, 0, 0, 0 });
        }
    }

    std::vector<Row*> rows = { &cpuRow, &gpuRow };

    HDC screen = GetDC(nullptr);
    if (!screen) return;
    HDC measureDc = CreateCompatibleDC(screen);
    {
        Graphics gm(measureDc);
        gm.SetTextRenderingHint(TextRenderingHintAntiAliasGridFit);
        gm.SetPixelOffsetMode(PixelOffsetModeHalf);
        for (Row* row : rows) {
            float cursor = 0.0f;
            for (auto& run : row->runs) {
                run.w = MeasureRun(gm, *run.font, run.text, &run.h);
                cursor += run.gap;
                run.x = cursor;
                cursor += run.w;
                if (run.h > row->height) row->height = run.h;
            }
            row->width = cursor;
        }
    }

    const float lineGap = 1.0f * s;
    const float contentWidth = (cpuRow.width > gpuRow.width ? cpuRow.width : gpuRow.width);
    const float contentHeight = cpuRow.height + lineGap + gpuRow.height;

    // The window is a hair larger than the glyphs: it gives the drop shadow room and
    // creates a hit-testable surface (alpha 1 pixels are invisible but catch the mouse).
    const int padX = 2;
    const int padY = 2;
    const int width = static_cast<int>(std::ceil(contentWidth)) + padX * 2 + 1;
    const int height = static_cast<int>(std::ceil(contentHeight)) + padY * 2 + 1;
    if (width <= 0 || height <= 0) {
        DeleteDC(measureDc);
        ReleaseDC(nullptr, screen);
        return;
    }

    BITMAPINFO bmi = {};
    bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
    bmi.bmiHeader.biWidth = width;
    bmi.bmiHeader.biHeight = -height;
    bmi.bmiHeader.biPlanes = 1;
    bmi.bmiHeader.biBitCount = 32;
    bmi.bmiHeader.biCompression = BI_RGB;

    void* bits = nullptr;
    HBITMAP dib = CreateDIBSection(screen, &bmi, DIB_RGB_COLORS, &bits, nullptr, 0);
    if (!dib || !bits) {
        DeleteDC(measureDc);
        ReleaseDC(nullptr, screen);
        return;
    }
    HDC memDc = CreateCompatibleDC(screen);
    HGDIOBJ oldBitmap = SelectObject(memDc, dib);
    ZeroMemory(bits, static_cast<size_t>(width) * height * 4);

    {
        Bitmap canvas(width, height, width * 4, PixelFormat32bppARGB,
                      static_cast<BYTE*>(bits));
        Graphics g(&canvas);
        g.SetSmoothingMode(SmoothingModeAntiAlias);
        g.SetTextRenderingHint(TextRenderingHintAntiAliasGridFit);
        g.SetPixelOffsetMode(PixelOffsetModeHalf);
        g.SetCompositingMode(CompositingModeSourceOver);

        float y = static_cast<float>(padY);
        for (Row* row : rows) {
            for (const auto& run : row->runs) {
                DrawRun(g, run, static_cast<float>(padX) + run.x,
                        y + (row->height - run.h) / 2.0f, palette.shadow);
            }
            y += row->height + lineGap;
        }
    }

    // Straight alpha -> premultiplied alpha. Fully transparent pixels become
    // alpha=1 so the whole block still accepts mouse input.
    BYTE* pixels = static_cast<BYTE*>(bits);
    const size_t count = static_cast<size_t>(width) * height;
    for (size_t i = 0; i < count; ++i) {
        BYTE alpha = pixels[i * 4 + 3];
        if (alpha == 0) {
            pixels[i * 4 + 0] = 0;
            pixels[i * 4 + 1] = 0;
            pixels[i * 4 + 2] = 0;
            pixels[i * 4 + 3] = 1;
            continue;
        }
        if (alpha == 255) continue;
        pixels[i * 4 + 0] = static_cast<BYTE>((pixels[i * 4 + 0] * alpha) / 255);
        pixels[i * 4 + 1] = static_cast<BYTE>((pixels[i * 4 + 1] * alpha) / 255);
        pixels[i * 4 + 2] = static_cast<BYTE>((pixels[i * 4 + 2] * alpha) / 255);
    }

    POINT destination = ComputePosition(width, height, info);
    SIZE size = { width, height };
    POINT source = { 0, 0 };
    BLENDFUNCTION blend = { AC_SRC_OVER, 0, 255, AC_SRC_ALPHA };
    UpdateLayeredWindow(g_hwnd, screen, &destination, &size, memDc, &source, 0, &blend,
                        ULW_ALPHA);

    SelectObject(memDc, oldBitmap);
    DeleteObject(dib);
    DeleteDC(memDc);
    DeleteDC(measureDc);
    ReleaseDC(nullptr, screen);

    if (!g_showing) {
        ShowWindow(g_hwnd, SW_SHOWNOACTIVATE);
        g_showing = true;
    }
    SetWindowPos(g_hwnd, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
}

// ---------------------------------------------------------------------------
// refresh loop
// ---------------------------------------------------------------------------
void Refresh()
{
    g_sensors.sample();

    TaskbarInfo info = QueryTaskbar();
    const bool shouldShow = info.ok && !FullscreenActive();
    if (!shouldShow) {
        if (g_showing) {
            ShowWindow(g_hwnd, SW_HIDE);
            g_showing = false;
        }
        return;
    }

    // Re-sample the taskbar colours every few seconds so accent / wallpaper /
    // theme changes are picked up without any user action.
    const ULONGLONG now = GetTickCount64();
    if (g_lastThemeSample == 0 || now - g_lastThemeSample > 4000) {
        SampleTaskbarTheme(info);
        g_lastThemeSample = now;
    }

    RenderOverlay(info);
}

void SetRefreshInterval(int ms)
{
    g_cfg.refreshMs = ms;
    SaveConfig();
    if (g_hwnd) SetTimer(g_hwnd, kTimerId, static_cast<UINT>(ms), nullptr);
    Refresh();
}

// ---------------------------------------------------------------------------
// menu / dialogs
// ---------------------------------------------------------------------------
void ShowAbout()
{
    const wchar_t* text =
        L"任务栏 CPU / GPU 小工具\n\n"
        L"CPU：使用率 + 频率（Windows 性能计数器）\n"
        L"GPU：温度 + 占用率 + 功耗（NVIDIA NVML 驱动接口）\n\n"
        L"为什么 CPU 不显示温度：\n"
        L"这台机器的 ACPI 温区（MSAcpi_ThermalZoneTemperature）返回的是固定假值，"
        L"满载 30 秒也纹丝不动；12 代 Intel 的真实封装温度只能靠内核级 MSR 驱动读取。"
        L"本工具不安装任何驱动，所以 CPU 一栏显示占用率和频率。\n\n"
        L"操作：\n"
        L"鼠标悬停 → 展开频率 / 占用率 / 功耗\n"
        L"左键 → 固定或取消固定详细信息\n"
        L"右键 → 设置菜单\n\n"
        L"设置文件：%ls";
    wchar_t buffer[1400] = {};
    swprintf(buffer, 1400, text, g_configPath.c_str());
    MessageBoxW(g_hwnd, buffer, L"关于 TaskbarTemps", MB_OK | MB_ICONINFORMATION);
    g_hover = false;
    Refresh();
}

void ShowContextMenu()
{
    HMENU root = CreatePopupMenu();
    HMENU interval = CreatePopupMenu();

    struct Item {
        int ms;
        const wchar_t* label;
        int id;
    };
    const Item items[] = {
        { 500, L"0.5 秒", IDM_INTERVAL_500 },
        { 1000, L"1 秒", IDM_INTERVAL_1000 },
        { 2000, L"2 秒", IDM_INTERVAL_2000 },
        { 5000, L"5 秒", IDM_INTERVAL_5000 },
    };
    for (const auto& item : items) {
        AppendMenuW(interval, MF_STRING | (g_cfg.refreshMs == item.ms ? MF_CHECKED : 0), item.id,
                    item.label);
    }
    AppendMenuW(root, MF_POPUP, reinterpret_cast<UINT_PTR>(interval), L"刷新间隔");
    AppendMenuW(root, MF_STRING | (g_pinned ? MF_CHECKED : 0), IDM_PIN, L"固定详细信息");
    AppendMenuW(root, MF_SEPARATOR, 0, nullptr);
    AppendMenuW(root, MF_STRING | (AutostartEnabled() ? MF_CHECKED : 0), IDM_AUTOSTART,
                L"开机自启");
    AppendMenuW(root, MF_STRING, IDM_ABOUT, L"说明");
    AppendMenuW(root, MF_SEPARATOR, 0, nullptr);
    AppendMenuW(root, MF_STRING, IDM_EXIT, L"退出");

    POINT pt = {};
    GetCursorPos(&pt);
    SetForegroundWindow(g_hwnd);
    TrackPopupMenu(root, TPM_RIGHTBUTTON | TPM_LEFTALIGN | TPM_TOPALIGN, pt.x, pt.y, 0, g_hwnd,
                   nullptr);
    PostMessageW(g_hwnd, WM_NULL, 0, 0);
    DestroyMenu(root);

    g_hover = false;
    Refresh();
}

// ---------------------------------------------------------------------------
// window procedure
// ---------------------------------------------------------------------------
LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    switch (msg) {
        case WM_TIMER:
            if (wParam == kTimerId) Refresh();
            return 0;

        case WM_COMMAND:
            switch (LOWORD(wParam)) {
                case IDM_INTERVAL_500: SetRefreshInterval(500); return 0;
                case IDM_INTERVAL_1000: SetRefreshInterval(1000); return 0;
                case IDM_INTERVAL_2000: SetRefreshInterval(2000); return 0;
                case IDM_INTERVAL_5000: SetRefreshInterval(5000); return 0;
                case IDM_PIN:
                    g_pinned = !g_pinned;
                    g_cfg.pinned = g_pinned;
                    SaveConfig();
                    Refresh();
                    return 0;
                case IDM_AUTOSTART:
                    SetAutostart(!AutostartEnabled());
                    Refresh();
                    return 0;
                case IDM_ABOUT: ShowAbout(); return 0;
                case IDM_EXIT: DestroyWindow(hwnd); return 0;
                default: return 0;
            }

        case WM_MOUSEMOVE:
            if (!g_hover) {
                g_hover = true;
                TRACKMOUSEEVENT track = { sizeof(track) };
                track.dwFlags = TME_LEAVE;
                track.hwndTrack = hwnd;
                TrackMouseEvent(&track);
                Refresh();
            }
            return 0;

        case WM_MOUSELEAVE:
            if (g_hover) {
                g_hover = false;
                Refresh();
            }
            return 0;

        case WM_LBUTTONUP:
            g_pinned = !g_pinned;
            g_cfg.pinned = g_pinned;
            SaveConfig();
            Refresh();
            return 0;

        case WM_RBUTTONUP:
            ShowContextMenu();
            return 0;

        case WM_DPICHANGED:
        case WM_DISPLAYCHANGE:
            g_dpi = WindowDpi(hwnd);
            Refresh();
            return 0;

        case WM_SETTINGCHANGE:
            // Theme / work area changes: re-detect now, re-sample on next tick.
            if (lParam &&
                wcscmp(reinterpret_cast<const wchar_t*>(lParam), L"ImmersiveColorSet") == 0) {
                DetectTaskbarTheme();
            }
            g_lastThemeSample = 0;
            g_dpi = WindowDpi(hwnd);
            Refresh();
            return 0;

        case WM_DESTROY:
            KillTimer(hwnd, kTimerId);
            PostQuitMessage(0);
            return 0;
    }
    return DefWindowProcW(hwnd, msg, wParam, lParam);
}

}  // namespace

// ---------------------------------------------------------------------------
// entry point
// ---------------------------------------------------------------------------
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE, LPSTR, int)
{
    HANDLE mutex = CreateMutexW(nullptr, FALSE, kMutexName);
    if (mutex && GetLastError() == ERROR_ALREADY_EXISTS) {
        return 0;  // already running
    }

    LoadDynamicApis();

    GdiplusStartupInput startupInput;
    ULONG_PTR token = 0;
    if (GdiplusStartup(&token, &startupInput, nullptr) != Ok) return 0;

    LoadConfig();
    g_pinned = g_cfg.pinned;
    DetectTaskbarTheme();

    // Test hook: TASKBARTEMPS_THEME=light|dark forces a palette (skips sampling).
    wchar_t forcedTheme[16] = {};
    if (GetEnvironmentVariableW(L"TASKBARTEMPS_THEME", forcedTheme, 16) > 0) {
        if (forcedTheme[0] == L'l' || forcedTheme[0] == L'L') {
            g_lightTaskbar = true;
            g_forceTheme = true;
        } else if (forcedTheme[0] == L'd' || forcedTheme[0] == L'D') {
            g_lightTaskbar = false;
            g_forceTheme = true;
        }
    }

    g_sensors.init();

    WNDCLASSEXW wc = { sizeof(wc) };
    wc.lpfnWndProc = WndProc;
    wc.hInstance = hInstance;
    wc.hCursor = LoadCursorW(nullptr, IDC_ARROW);
    wc.lpszClassName = kClassName;
    RegisterClassExW(&wc);

    g_hwnd = CreateWindowExW(WS_EX_LAYERED | WS_EX_TOPMOST | WS_EX_TOOLWINDOW |
                                 WS_EX_NOACTIVATE,
                             kClassName, kAppName, WS_POPUP, 0, 0, 120, 40, nullptr, nullptr,
                             hInstance, nullptr);
    if (!g_hwnd) {
        g_sensors.shutdown();
        GdiplusShutdown(token);
        return 0;
    }

    g_dpi = WindowDpi(g_hwnd);
    EnsureFonts(g_dpi);
    Refresh();
    SetTimer(g_hwnd, kTimerId, static_cast<UINT>(g_cfg.refreshMs), nullptr);

    MSG msg;
    while (GetMessageW(&msg, nullptr, 0, 0) > 0) {
        TranslateMessage(&msg);
        DispatchMessageW(&msg);
    }

    if (IsWindow(g_hwnd)) DestroyWindow(g_hwnd);
    g_sensors.shutdown();
    delete g_fontLabel;
    delete g_fontValue;
    delete g_fontExtra;
    g_fontLabel = g_fontValue = g_fontExtra = nullptr;
    GdiplusShutdown(token);
    if (mutex) CloseHandle(mutex);
    return 0;
}

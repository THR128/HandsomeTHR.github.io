@echo off
rem Build TaskbarTemps with the Dev-C++ (TDM-GCC) toolchain.
setlocal

set "GXX=C:\Program Files (x86)\Embarcadero\Dev-Cpp\TDM-GCC-64\bin\g++.exe"
if not exist "%GXX%" set "GXX=g++"

if not exist build mkdir build
if not exist dist mkdir dist

"%GXX%" -O2 -std=c++17 -mwindows -static -static-libgcc -static-libstdc++ ^
    -finput-charset=UTF-8 -fexec-charset=UTF-8 ^
    -o dist\TaskbarTemps.exe ^
    src\main.cpp src\sensors.cpp ^
    -lgdiplus -lpdh -lshell32 -ladvapi32 -lole32 -luuid -luser32 -lgdi32

if errorlevel 1 (
    echo BUILD FAILED
    exit /b 1
)
echo BUILD OK: dist\TaskbarTemps.exe

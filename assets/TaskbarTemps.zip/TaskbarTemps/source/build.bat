@echo off
rem Build TaskbarTemps with the Dev-C++ (TDM-GCC) toolchain.
setlocal

set "TDM=C:\Program Files (x86)\Embarcadero\Dev-Cpp\TDM-GCC-64"
set "GXX=%TDM%\bin\g++.exe"
if not exist "%GXX%" set "GXX=g++"

if not exist build mkdir build
if not exist dist mkdir dist

rem windres cannot handle spaces in the compiler path, so go through a junction.
if not exist "build\tdmgcc" mklink /J "build\tdmgcc" "%TDM%" >nul 2>&1
set "WINDRES=build\tdmgcc\bin\windres.exe"
if not exist "%WINDRES%" set "WINDRES=windres"

rem --- resources: icon + manifest + version info (also keeps AV heuristics calm)
"%WINDRES%" -I src\res -i src\res\resource.rc -O coff -o build\resource.o
if errorlevel 1 (
    echo RESOURCE BUILD FAILED
    exit /b 1
)

rem --- compile + link into build\ first ---
rem Some antivirus (360) keeps a block rule for the exact path dist\TaskbarTemps.exe,
rem which makes ld fail with a bogus "No space left on device". Linking to another
rem name and copying afterwards sidesteps that rule.
"%GXX%" -O2 -std=c++17 -mwindows -static -static-libgcc -static-libstdc++ -finput-charset=UTF-8 -fexec-charset=UTF-8 -o build\TaskbarTemps.exe src\main.cpp src\sensors.cpp build\resource.o -lgdiplus -lpdh -lshell32 -ladvapi32 -lole32 -luuid -luser32 -lgdi32
if errorlevel 1 (
    echo BUILD FAILED
    exit /b 1
)

copy /Y build\TaskbarTemps.exe dist\TaskbarTemps.exe >nul
if errorlevel 1 (
    echo COPY TO dist FAILED - probably blocked by antivirus, check the trust list
    exit /b 1
)
echo BUILD OK: dist\TaskbarTemps.exe

# TaskbarTemps · 任务栏 CPU / GPU 小工具

贴在 Windows 11 任务栏右侧（时钟左边）的两行实时监控，**纯文字、没有底板和边框**，不占任务栏按钮、不显示在 Alt+Tab 里。

```
CPU  34%   4.05 GHz      ← 平时只显示前两个，鼠标悬停才展开
GPU  49°C   8%   26W
```

## 显示内容

| 项目 | 数据源 | 说明 |
| --- | --- | --- |
| CPU 使用率 | Windows 性能计数器 `% Processor Utility` | 每 1 秒采样 |
| CPU 频率 | `% Processor Performance` × 基准频率 | 悬停时显示 |
| GPU 温度 | NVIDIA NVML（nvml.dll） | NVIDIA 显卡真实核心温度，按温度变色 |
| GPU 占用率、功耗 | NVML | 悬停时显示 |

### 为什么 CPU 不显示温度

这台机器的 ACPI 温区（`MSAcpi_ThermalZoneTemperature`）返回的是**固定假值**：本机实测烤机 30 秒纹丝不动（一直 27.9 °C）。12 代 Intel 的真实封装温度（MSR 0x1A2）只能通过内核级驱动读取，而本工具**不安装任何驱动**，所以 CPU 一栏显示使用率和频率，GPU 用驱动自带的 NVML 读真实温度。

## 操作

- **鼠标悬停**：展开频率 / 占用率 / 功耗
- **左键**：固定或取消固定详细信息（常驻展开）
- **右键**：菜单
  - 刷新间隔：0.5 / 1 / 2 / 5 秒
  - 固定详细信息
  - 开机自启（勾选后写入 `HKCU\...\Run`）
  - 说明 / 退出

## 位置与外观

- 自动贴在主任务栏最右侧、时钟和托盘图标的左边，随任务栏高度居中。
- 任务栏自动隐藏、全屏程序（游戏/视频）前台时自动隐藏，回到桌面又出现。
- **自动采样任务栏真实底色**：每 4 秒取任务栏像素算亮度，按 WCAG 对比度自动切浅色/深色文字；深色、浅色、自定义彩色任务栏、半透明露壁纸都能适配，换颜色后自动跟上。
- 高 DPI（125%/150%）自动缩放。
- 单个 exe 覆盖 Windows 7/10/11（本机 Win11 实测），不依赖运行库。

## 配置文件

优先写在 exe 同目录的 `TaskbarTemps.ini`（便携）；该目录不可写时回落到 `%APPDATA%\TaskbarTemps\settings.ini`。

```ini
[view]
refreshMs=1000
pinned=0
```

## 编译

用你机器上的 Embarcadero Dev-C++ 自带编译器（TDM-GCC 9.2，`C:\Program Files (x86)\Embarcadero\Dev-Cpp\TDM-GCC-64\bin\g++.exe`）：

```bat
build.bat
```

产物：`dist\TaskbarTemps.exe`（静态链接，单个 exe ~1.1 MB，无额外运行库依赖）。

## 目录

```
TaskbarTemps/
  src/main.cpp         窗口、GDI+ 绘制、任务栏贴合、菜单、配置
  src/sensors.h/.cpp   CPU（PDH）与 GPU（NVML）采样
  build.bat            编译脚本
  dist/TaskbarTemps.exe  成品
  tools/               开发时用的传感器探针（可删）
  shots/               开发过程截图（可删）
```

## 已知限制

- 只支持 NVIDIA 显卡温度（NVML）；A/N 卡的 CPU 温度同理需要内核驱动。
- 多显示器下只吸附主任务栏。
- 任务栏图标特别多时，文字可能盖在图标上方；可把窗口往左挪（改代码里的 `rightLimit`）或收起一些图标。

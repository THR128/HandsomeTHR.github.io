// sensors.h - CPU / GPU telemetry for TaskbarTemps
#pragma once

#ifndef _WIN32_WINNT
#define _WIN32_WINNT 0x0A00
#endif
#ifndef WINVER
#define WINVER 0x0A00
#endif

#include <windows.h>
#include <pdh.h>
#include <pdhmsg.h>

struct CpuReading {
    double usagePct = -1.0;   // -1 = unknown yet
    double freqGHz = -1.0;    // current core clock, GHz
};

struct GpuReading {
    bool ok = false;
    wchar_t name[96] = {};
    int tempC = -1;
    int utilPct = -1;
    int memUtilPct = -1;
    unsigned powerMw = 0;
    unsigned clockMHz = 0;
    unsigned long long memUsedBytes = 0;
    unsigned long long memTotalBytes = 0;
};

class Sensors {
public:
    bool init();
    void sample();
    void shutdown();

    const CpuReading& cpu() const { return cpu_; }
    const GpuReading& gpu() const { return gpu_; }

private:
    void initCpu();
    void initGpu();
    void sampleCpu();
    void sampleGpu();

    // --- CPU: PDH performance counters
    PDH_HQUERY query_ = nullptr;
    PDH_HCOUNTER counterUtility_ = nullptr;
    PDH_HCOUNTER counterPerf_ = nullptr;
    double baseMHz_ = 2500.0;
    bool pdhOk_ = false;
    ULONGLONG prevIdle_ = 0;
    ULONGLONG prevKernel_ = 0;
    ULONGLONG prevUser_ = 0;
    CpuReading cpu_;

    // --- GPU: NVIDIA NVML
    HMODULE nvml_ = nullptr;
    void* device_ = nullptr;
    bool nvmlOk_ = false;
    GpuReading gpu_;
};

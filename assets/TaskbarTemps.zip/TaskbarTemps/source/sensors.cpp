// sensors.cpp - CPU via PDH counters, GPU via NVIDIA NVML.
#include "sensors.h"

#include <cstdio>
#include <cwchar>

// ---------------------------------------------------------------------------
// NVML (libnvidia-ml) minimal bindings - loaded dynamically from nvml.dll
// ---------------------------------------------------------------------------
typedef int nvmlReturn_t;
typedef void* nvmlDevice_t;

struct nvmlUtilization_t {
    unsigned int gpu;     // percent
    unsigned int memory;  // percent
};

struct nvmlMemory_t {
    unsigned long long total;
    unsigned long long free;
    unsigned long long used;
};

typedef nvmlReturn_t (*PFN_nvmlInit)();
typedef nvmlReturn_t (*PFN_nvmlShutdown)();
typedef nvmlReturn_t (*PFN_nvmlGetHandle)(unsigned, nvmlDevice_t*);
typedef nvmlReturn_t (*PFN_nvmlGetTemperature)(nvmlDevice_t, int, unsigned*);
typedef nvmlReturn_t (*PFN_nvmlGetUtilization)(nvmlDevice_t, nvmlUtilization_t*);
typedef nvmlReturn_t (*PFN_nvmlGetPower)(nvmlDevice_t, unsigned*);
typedef nvmlReturn_t (*PFN_nvmlGetMemory)(nvmlDevice_t, nvmlMemory_t*);
typedef nvmlReturn_t (*PFN_nvmlGetName)(nvmlDevice_t, char*, unsigned);
typedef nvmlReturn_t (*PFN_nvmlGetClock)(nvmlDevice_t, int, unsigned*);

namespace {

PFN_nvmlInit g_nvmlInit = nullptr;
PFN_nvmlShutdown g_nvmlShutdown = nullptr;
PFN_nvmlGetHandle g_nvmlGetHandle = nullptr;
PFN_nvmlGetTemperature g_nvmlGetTemperature = nullptr;
PFN_nvmlGetUtilization g_nvmlGetUtilization = nullptr;
PFN_nvmlGetPower g_nvmlGetPower = nullptr;
PFN_nvmlGetMemory g_nvmlGetMemory = nullptr;
PFN_nvmlGetName g_nvmlGetName = nullptr;
PFN_nvmlGetClock g_nvmlGetClock = nullptr;

template <typename T>
T loadProc(HMODULE mod, const char* name)
{
    return reinterpret_cast<T>(GetProcAddress(mod, name));
}

double clamp01to100(double v)
{
    if (v < 0.0) return 0.0;
    if (v > 100.0) return 100.0;
    return v;
}

}  // namespace

// ---------------------------------------------------------------------------
bool Sensors::init()
{
    initCpu();
    initGpu();
    return pdhOk_ || nvmlOk_;
}

void Sensors::shutdown()
{
    if (query_) {
        PdhCloseQuery(query_);
        query_ = nullptr;
    }
    if (nvml_) {
        if (g_nvmlShutdown) g_nvmlShutdown();
        FreeLibrary(nvml_);
        nvml_ = nullptr;
    }
}

// ---------------------------------------------------------------------------
// CPU
// ---------------------------------------------------------------------------
void Sensors::initCpu()
{
    HKEY key = nullptr;
    DWORD mhz = 0, size = sizeof(mhz), type = 0;
    if (RegOpenKeyExW(HKEY_LOCAL_MACHINE,
                      L"HARDWARE\\DESCRIPTION\\System\\CentralProcessor\\0", 0, KEY_READ,
                      &key) == ERROR_SUCCESS) {
        if (RegQueryValueExW(key, L"~MHz", nullptr, &type, reinterpret_cast<LPBYTE>(&mhz),
                             &size) == ERROR_SUCCESS &&
            mhz > 0) {
            baseMHz_ = static_cast<double>(mhz);
        }
        RegCloseKey(key);
    }

    if (PdhOpenQueryW(nullptr, 0, &query_) == ERROR_SUCCESS) {
        PDH_STATUS a = PdhAddEnglishCounterW(
            query_, L"\\Processor Information(_Total)\\% Processor Utility", 0, &counterUtility_);
        if (a != ERROR_SUCCESS) counterUtility_ = nullptr;

        PDH_STATUS b = PdhAddEnglishCounterW(
            query_, L"\\Processor Information(_Total)\\% Processor Performance", 0, &counterPerf_);
        if (b != ERROR_SUCCESS) counterPerf_ = nullptr;

        pdhOk_ = (counterUtility_ != nullptr || counterPerf_ != nullptr);
        if (pdhOk_) {
            PdhCollectQueryData(query_);  // prime
        } else {
            PdhCloseQuery(query_);
            query_ = nullptr;
        }
    }

    // Prime the GetSystemTimes fallback baseline.
    FILETIME idle, kernel, user;
    if (GetSystemTimes(&idle, &kernel, &user)) {
        prevIdle_ = (static_cast<ULONGLONG>(idle.dwHighDateTime) << 32) | idle.dwLowDateTime;
        prevKernel_ = (static_cast<ULONGLONG>(kernel.dwHighDateTime) << 32) | kernel.dwLowDateTime;
        prevUser_ = (static_cast<ULONGLONG>(user.dwHighDateTime) << 32) | user.dwLowDateTime;
    }
}

void Sensors::sampleCpu()
{
    if (pdhOk_ && query_) {
        if (PdhCollectQueryData(query_) == ERROR_SUCCESS) {
            if (counterUtility_) {
                PDH_FMT_COUNTERVALUE v;
                if (PdhGetFormattedCounterValue(counterUtility_, PDH_FMT_DOUBLE, nullptr, &v) ==
                        ERROR_SUCCESS &&
                    v.CStatus == PDH_CSTATUS_VALID_DATA) {
                    cpu_.usagePct = clamp01to100(v.doubleValue);
                }
            }
            if (counterPerf_) {
                PDH_FMT_COUNTERVALUE v;
                if (PdhGetFormattedCounterValue(counterPerf_, PDH_FMT_DOUBLE, nullptr, &v) ==
                        ERROR_SUCCESS &&
                    v.CStatus == PDH_CSTATUS_VALID_DATA) {
                    double mhz = baseMHz_ * v.doubleValue / 100.0;
                    cpu_.freqGHz = mhz / 1000.0;
                }
            }
            return;
        }
    }

    // Fallback: total busy time from GetSystemTimes.
    FILETIME idle, kernel, user;
    if (!GetSystemTimes(&idle, &kernel, &user)) return;
    ULONGLONG i = (static_cast<ULONGLONG>(idle.dwHighDateTime) << 32) | idle.dwLowDateTime;
    ULONGLONG k = (static_cast<ULONGLONG>(kernel.dwHighDateTime) << 32) | kernel.dwLowDateTime;
    ULONGLONG u = (static_cast<ULONGLONG>(user.dwHighDateTime) << 32) | user.dwLowDateTime;
    if (prevKernel_ || prevUser_) {
        ULONGLONG di = i - prevIdle_;
        ULONGLONG dk = k - prevKernel_;
        ULONGLONG du = u - prevUser_;
        ULONGLONG total = dk + du;
        if (total > 0) {
            double busy = static_cast<double>(total) - static_cast<double>(di);
            cpu_.usagePct = clamp01to100(busy * 100.0 / static_cast<double>(total));
        }
    }
    prevIdle_ = i;
    prevKernel_ = k;
    prevUser_ = u;
}

// ---------------------------------------------------------------------------
// GPU
// ---------------------------------------------------------------------------
void Sensors::initGpu()
{
    nvml_ = LoadLibraryW(L"nvml.dll");
    if (!nvml_) {
        // Fall back to the path some older drivers use.
        nvml_ = LoadLibraryW(L"C:\\Program Files\\NVIDIA Corporation\\NVSMI\\nvml.dll");
    }
    if (!nvml_) return;

    g_nvmlInit = loadProc<PFN_nvmlInit>(nvml_, "nvmlInit_v2");
    if (!g_nvmlInit) g_nvmlInit = loadProc<PFN_nvmlInit>(nvml_, "nvmlInit");
    g_nvmlShutdown = loadProc<PFN_nvmlShutdown>(nvml_, "nvmlShutdown");
    g_nvmlGetHandle = loadProc<PFN_nvmlGetHandle>(nvml_, "nvmlDeviceGetHandleByIndex_v2");
    if (!g_nvmlGetHandle) g_nvmlGetHandle = loadProc<PFN_nvmlGetHandle>(nvml_, "nvmlDeviceGetHandleByIndex");
    g_nvmlGetTemperature = loadProc<PFN_nvmlGetTemperature>(nvml_, "nvmlDeviceGetTemperature");
    g_nvmlGetUtilization = loadProc<PFN_nvmlGetUtilization>(nvml_, "nvmlDeviceGetUtilizationRates");
    g_nvmlGetPower = loadProc<PFN_nvmlGetPower>(nvml_, "nvmlDeviceGetPowerUsage");
    g_nvmlGetMemory = loadProc<PFN_nvmlGetMemory>(nvml_, "nvmlDeviceGetMemoryInfo");
    g_nvmlGetName = loadProc<PFN_nvmlGetName>(nvml_, "nvmlDeviceGetName");
    g_nvmlGetClock = loadProc<PFN_nvmlGetClock>(nvml_, "nvmlDeviceGetClockInfo");

    if (!g_nvmlInit || !g_nvmlGetHandle) return;
    if (g_nvmlInit() != 0) return;
    if (g_nvmlGetHandle(0, &device_) != 0 || !device_) return;

    nvmlOk_ = true;
    gpu_.ok = true;

    if (g_nvmlGetName) {
        char name[96] = {};
        if (g_nvmlGetName(device_, name, sizeof(name)) == 0) {
            MultiByteToWideChar(CP_ACP, 0, name, -1, gpu_.name, 96);
        }
    }
    if (!gpu_.name[0]) wcscpy(gpu_.name, L"NVIDIA GPU");
}

void Sensors::sampleGpu()
{
    if (!nvmlOk_ || !device_) return;

    if (g_nvmlGetTemperature) {
        unsigned t = 0;
        if (g_nvmlGetTemperature(device_, 0, &t) == 0) gpu_.tempC = static_cast<int>(t);
    }
    if (g_nvmlGetUtilization) {
        nvmlUtilization_t u = {};
        if (g_nvmlGetUtilization(device_, &u) == 0) {
            gpu_.utilPct = static_cast<int>(u.gpu);
            gpu_.memUtilPct = static_cast<int>(u.memory);
        }
    }
    if (g_nvmlGetPower) {
        unsigned p = 0;
        if (g_nvmlGetPower(device_, &p) == 0) gpu_.powerMw = p;
    }
    if (g_nvmlGetMemory) {
        nvmlMemory_t m = {};
        if (g_nvmlGetMemory(device_, &m) == 0) {
            gpu_.memUsedBytes = m.used;
            gpu_.memTotalBytes = m.total;
        }
    }
    if (g_nvmlGetClock) {
        unsigned c = 0;
        if (g_nvmlGetClock(device_, 1, &c) == 0) gpu_.clockMHz = c;  // 1 = NVML_CLOCK_SM
    }
}

void Sensors::sample()
{
    sampleCpu();
    sampleGpu();
}
